-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2026 at 07:35 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smartcashi_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_2fa_backup_codes`
--

CREATE TABLE `admin_2fa_backup_codes` (
  `code_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `used` tinyint(1) DEFAULT 0,
  `used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admin_2fa_tokens`
--

CREATE TABLE `admin_2fa_tokens` (
  `token_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(6) NOT NULL,
  `token_type` enum('email','totp','sms','backup') DEFAULT 'email',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  `used` tinyint(1) DEFAULT 0,
  `used_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admin_activity_logs`
--

CREATE TABLE `admin_activity_logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `action_category` enum('user','security','system','content','settings','data','backup','report') NOT NULL DEFAULT 'system',
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `risk_level` enum('low','medium','high','critical') DEFAULT 'low',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_activity_logs`
--

INSERT INTO `admin_activity_logs` (`log_id`, `user_id`, `action`, `action_category`, `entity_type`, `entity_id`, `old_value`, `new_value`, `ip_address`, `user_agent`, `risk_level`, `created_at`) VALUES
(1, 48, 'admin_login', 'security', 'user', 48, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 05:57:55'),
(2, 48, 'admin_login', 'security', 'user', 48, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 06:01:30'),
(3, 48, 'admin_login', 'security', 'user', 48, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 06:04:39'),
(4, 48, 'admin_login', 'security', 'user', 48, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 06:06:30'),
(5, 48, 'admin_login', 'security', 'user', 48, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 06:08:06'),
(6, 48, 'admin_login', 'security', 'user', 48, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 06:19:49'),
(7, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', 'low', '2025-12-30 08:14:10'),
(8, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', 'low', '2025-12-30 08:48:52'),
(9, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', 'low', '2025-12-30 08:51:50'),
(10, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', 'low', '2025-12-30 08:52:01'),
(11, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', 'low', '2025-12-30 08:52:12'),
(12, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', 'low', '2025-12-30 09:13:38'),
(13, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', 'low', '2025-12-30 09:24:33'),
(14, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', 'low', '2025-12-30 09:33:35'),
(15, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', 'low', '2025-12-30 09:35:55'),
(16, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', 'low', '2025-12-30 09:39:54'),
(17, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', 'low', '2025-12-30 10:02:33'),
(18, 49, 'admin_logout', 'security', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', 'low', '2025-12-30 10:04:28'),
(19, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 10:06:07'),
(20, 49, 'generate_report', 'report', 'report', NULL, NULL, '{\"type\":\"user_summary\",\"format\":\"pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 10:35:51'),
(21, 49, 'generate_report', 'report', 'report', NULL, NULL, '{\"type\":\"security_audit\",\"format\":\"pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 10:36:13'),
(22, 49, 'update_user', 'user', 'user', 49, '{\"user_id\":\"49\",\"email\":\"admin@smartcashi.com\",\"phone\":\"01700000000\",\"password_hash\":\"$2y$10$xBCPU\\/lz302alc3LrmAzkOm2GRFZxG1jPmbiECj2av5Ki2aI0SZQC\",\"first_name\":\"Admin\",\"last_name\":\"Demo\",\"profile_img_url\":\"uploads\\/profiles\\/admin-default.jpg\",\"role\":\"admin\",\"is_active\":\"1\",\"is_verified\":\"1\",\"last_login\":\"2025-12-30 16:06:07\",\"created_at\":\"2025-12-30 14:12:31\",\"updated_at\":\"2025-12-30 16:06:07\"}', '{\"action\":\"update_user\",\"csrf_token\":\"ae8f17c1b4e59e41fd37396c2778a3935050c5ed32e6e9207f8c3ba6ef22e596\",\"device_fingerprint\":\"TW96aWxsYS81LjAgKFdpbmRvd3MgTlQg\",\"first_name\":\"Admin\",\"last_name\":\"Demo\",\"email\":\"admin@smartcashi.com\",\"phone\":\"01700000000\",\"role\":\"admin\",\"is_active\":\"1\",\"is_verified\":\"1\",\"user_id\":\"49\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 10:57:53'),
(23, 49, 'update_user', 'user', 'user', 49, '{\"user_id\":\"49\",\"email\":\"admin@smartcashi.com\",\"phone\":\"01700000000\",\"password_hash\":\"$2y$10$xBCPU\\/lz302alc3LrmAzkOm2GRFZxG1jPmbiECj2av5Ki2aI0SZQC\",\"first_name\":\"Admin\",\"last_name\":\"Demo\",\"profile_img_url\":\"uploads\\/profiles\\/admin-default.jpg\",\"role\":\"admin\",\"is_active\":\"1\",\"is_verified\":\"1\",\"last_login\":\"2025-12-30 16:06:07\",\"created_at\":\"2025-12-30 14:12:31\",\"updated_at\":\"2025-12-30 16:06:07\"}', '{\"action\":\"update_user\",\"csrf_token\":\"ae8f17c1b4e59e41fd37396c2778a3935050c5ed32e6e9207f8c3ba6ef22e596\",\"device_fingerprint\":\"TW96aWxsYS81LjAgKFdpbmRvd3MgTlQg\",\"first_name\":\"Admin\",\"last_name\":\"Demo\",\"email\":\"admin@smartcashi.com\",\"phone\":\"01700000000\",\"role\":\"admin\",\"is_active\":\"1\",\"is_verified\":\"1\",\"user_id\":\"49\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 10:57:53'),
(24, 49, 'update_user', 'user', 'user', 49, '{\"user_id\":\"49\",\"email\":\"admin@smartcashi.com\",\"phone\":\"01700000000\",\"password_hash\":\"$2y$10$xBCPU\\/lz302alc3LrmAzkOm2GRFZxG1jPmbiECj2av5Ki2aI0SZQC\",\"first_name\":\"Admin\",\"last_name\":\"Demo\",\"profile_img_url\":\"uploads\\/profiles\\/admin-default.jpg\",\"role\":\"admin\",\"is_active\":\"1\",\"is_verified\":\"1\",\"last_login\":\"2025-12-30 16:06:07\",\"created_at\":\"2025-12-30 14:12:31\",\"updated_at\":\"2025-12-30 16:06:07\"}', '{\"action\":\"update_user\",\"csrf_token\":\"ae8f17c1b4e59e41fd37396c2778a3935050c5ed32e6e9207f8c3ba6ef22e596\",\"device_fingerprint\":\"TW96aWxsYS81LjAgKFdpbmRvd3MgTlQg\",\"first_name\":\"Admin\",\"last_name\":\"Demo\",\"email\":\"admin@smartcashi.com\",\"phone\":\"01700000000\",\"role\":\"admin\",\"is_active\":\"1\",\"is_verified\":\"1\",\"user_id\":\"49\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 10:57:53'),
(25, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 11:08:42'),
(26, 49, 'create_user', 'user', 'user', 50, NULL, '{\"email\":\"mohatmimhaque1234@gmail.com\",\"first_name\":\"Mohatamim\",\"role\":\"farmer\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 11:09:26'),
(27, 49, 'update_user', 'user', 'user', 50, '{\"user_id\":\"50\",\"email\":\"mohatmimhaque1234@gmail.com\",\"phone\":\"1518749114\",\"password_hash\":\"$2y$10$O0t61irPjsYeIa9bdyzVTOkdTTCYgPidwxUgguoAWmqJ52O1l8r.y\",\"first_name\":\"Mohatamim\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/default-avatar.jpg\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"1\",\"last_login\":null,\"created_at\":\"2025-12-30 17:09:26\",\"updated_at\":\"2025-12-30 17:09:26\"}', '{\"user_id\":\"50\",\"first_name\":\"Mohatamim\",\"last_name\":\"\",\"email\":\"mohatmimhaque1234@gmail.com\",\"phone\":\"1518749114\",\"role\":\"farmer\",\"is_active\":\"1\",\"password\":\"\",\"action\":\"update_user\",\"csrf_token\":\"836651f7a53d32f844aaf5456a564a697231f8409d619d48dba59eadde79d9ef\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 11:15:01'),
(28, 49, 'update_user', 'user', 'user', 50, '{\"user_id\":\"50\",\"email\":\"mohatmimhaque1234@gmail.com\",\"phone\":\"1518749114\",\"password_hash\":\"$2y$10$O0t61irPjsYeIa9bdyzVTOkdTTCYgPidwxUgguoAWmqJ52O1l8r.y\",\"first_name\":\"Mohatamim\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/default-avatar.jpg\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"1\",\"last_login\":null,\"created_at\":\"2025-12-30 17:09:26\",\"updated_at\":\"2025-12-30 17:09:26\"}', '{\"action\":\"update_user\",\"csrf_token\":\"836651f7a53d32f844aaf5456a564a697231f8409d619d48dba59eadde79d9ef\",\"device_fingerprint\":\"TW96aWxsYS81LjAgKFdpbmRvd3MgTlQg\",\"first_name\":\"Mohatamim\",\"last_name\":\"\",\"email\":\"mohatmimhaque1234@gmail.com\",\"phone\":\"1518749114\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"0\",\"user_id\":\"50\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 11:15:01'),
(29, 49, 'update_user', 'user', 'user', 50, '{\"user_id\":\"50\",\"email\":\"mohatmimhaque1234@gmail.com\",\"phone\":\"1518749114\",\"password_hash\":\"$2y$10$O0t61irPjsYeIa9bdyzVTOkdTTCYgPidwxUgguoAWmqJ52O1l8r.y\",\"first_name\":\"Mohatamim\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/default-avatar.jpg\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"0\",\"last_login\":null,\"created_at\":\"2025-12-30 17:09:26\",\"updated_at\":\"2025-12-30 17:15:01\"}', '{\"action\":\"update_user\",\"csrf_token\":\"836651f7a53d32f844aaf5456a564a697231f8409d619d48dba59eadde79d9ef\",\"device_fingerprint\":\"TW96aWxsYS81LjAgKFdpbmRvd3MgTlQg\",\"first_name\":\"Mohatamim\",\"last_name\":\"\",\"email\":\"mohatmimhaque1234@gmail.com\",\"phone\":\"1518749114\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"0\",\"user_id\":\"50\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 11:15:01'),
(30, 49, 'update_user', 'user', 'user', 50, '{\"user_id\":\"50\",\"email\":\"mohatmimhaque1234@gmail.com\",\"phone\":\"1518749114\",\"password_hash\":\"$2y$10$O0t61irPjsYeIa9bdyzVTOkdTTCYgPidwxUgguoAWmqJ52O1l8r.y\",\"first_name\":\"Mohatamim\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/default-avatar.jpg\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"0\",\"last_login\":null,\"created_at\":\"2025-12-30 17:09:26\",\"updated_at\":\"2025-12-30 17:15:01\"}', '{\"action\":\"update_user\",\"csrf_token\":\"836651f7a53d32f844aaf5456a564a697231f8409d619d48dba59eadde79d9ef\",\"device_fingerprint\":\"TW96aWxsYS81LjAgKFdpbmRvd3MgTlQg\",\"first_name\":\"Mohatamim\",\"last_name\":\"\",\"email\":\"mohatmimhaque1234@gmail.com\",\"phone\":\"1518749114\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"0\",\"user_id\":\"50\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 11:15:01'),
(31, 49, 'create_user', 'user', 'user', 57, NULL, '{\"email\":\"mohatamim1@gmail.com\",\"first_name\":\"Mohatamim\",\"role\":\"farmer\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 11:15:32'),
(32, 49, 'create_user', 'user', 'user', 58, NULL, '{\"email\":\"mohatamim123455@gmail.com\",\"first_name\":\"Mohatamim\",\"role\":\"farmer\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 11:16:32'),
(33, 49, 'ban_user', 'user', 'user', 58, NULL, '{\"type\":\"temporary\",\"reason\":\"nn n\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'high', '2025-12-30 11:17:10'),
(34, 49, 'ban_user', 'user', 'user', 58, NULL, '{\"type\":\"temporary\",\"reason\":\"nn n\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'high', '2025-12-30 11:17:10'),
(35, 49, 'ban_user', 'user', 'user', 58, NULL, '{\"type\":\"temporary\",\"reason\":\"nn n\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'high', '2025-12-30 11:17:10'),
(36, 49, 'delete_user', 'user', 'user', 58, '{\"user_id\":\"58\",\"email\":\"mohatamim123455@gmail.com\",\"phone\":\"01518956255\",\"password_hash\":\"$2y$10$lKHN\\/mG1Gsqwya4RicSLWunfbuER7LykVb7PF\\/kzgfZqW\\/6K3ZBP.\",\"first_name\":\"Mohatamim\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/default-avatar.jpg\",\"role\":\"farmer\",\"is_active\":\"0\",\"is_verified\":\"0\",\"last_login\":null,\"created_at\":\"2025-12-30 17:16:32\",\"updated_at\":\"2025-12-30 17:17:10\"}', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'high', '2025-12-30 11:17:54'),
(37, 49, 'delete_user', 'user', 'user', 47, '{\"user_id\":\"47\",\"email\":\"mecika9949@dubokutv.com\",\"phone\":\"01518946255\",\"password_hash\":\"$2y$10$X8WwmDfJtOlTcG8DSu57humKB5IIqMXx9MwCUAI8f0aJcsbkH5jYu\",\"first_name\":\"Mohatamim\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/profile_47_1767050471.JPG\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"1\",\"last_login\":\"2025-12-30 05:07:39\",\"created_at\":\"2025-12-29 22:27:41\",\"updated_at\":\"2025-12-30 05:21:11\"}', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'high', '2025-12-30 11:26:13'),
(38, 49, 'delete_user', 'user', 'user', 57, '{\"user_id\":\"57\",\"email\":\"mohatamim1@gmail.com\",\"phone\":\"5454544545\",\"password_hash\":\"$2y$10$TMcOckPoSbRX5pWNsPMnDeS3nGdgv9AuvRg6abr3pfNmfT\\/DwPy3y\",\"first_name\":\"Mohatamim\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/default-avatar.jpg\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"0\",\"last_login\":null,\"created_at\":\"2025-12-30 17:15:32\",\"updated_at\":\"2025-12-30 17:15:32\"}', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'high', '2025-12-30 11:26:34'),
(39, 49, 'export_users', 'user', 'export', NULL, NULL, '3 users exported', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 11:27:41'),
(40, 49, 'export_users', 'user', 'export', NULL, NULL, '3 users exported', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 11:30:05'),
(41, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 12:08:18'),
(42, 49, 'create_user', 'user', 'user', 59, NULL, '{\"email\":\"dfdfddfd@fdfd.com\",\"first_name\":\"vdddf\",\"role\":\"farmer\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 12:14:14'),
(43, 49, 'update_user', 'user', 'user', 59, '{\"user_id\":\"59\",\"email\":\"dfdfddfd@fdfd.com\",\"phone\":\"4545445454\",\"password_hash\":\"$2y$10$9\\/pibDWsaIpYMSNRxiXFLeCEOrdE.yPgV3A1EtT5k97xgekNGRu\\/u\",\"first_name\":\"vdddf\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/default-avatar.jpg\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"0\",\"last_login\":null,\"created_at\":\"2025-12-30 18:14:14\",\"updated_at\":\"2025-12-30 18:14:14\"}', '{\"action\":\"update_user\",\"csrf_token\":\"174331bbde8310710e2cdb654f6b7dfe34b48e6f291f51853a0d1ef2caa61197\",\"device_fingerprint\":\"TW96aWxsYS81LjAgKFdpbmRvd3MgTlQg\",\"first_name\":\"vdddf\",\"last_name\":\"\",\"email\":\"dfdfddfd@fdfd.com\",\"phone\":\"4545445454\",\"role\":\"farmer\",\"is_active\":\"0\",\"is_verified\":\"1\",\"user_id\":\"59\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 12:23:24'),
(44, 49, 'create_user', 'user', 'user', 60, NULL, '{\"email\":\"dfdfd@gmail.com\",\"first_name\":\"Mohatamim\",\"role\":\"farmer\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 12:36:18'),
(45, 49, 'update_user', 'user', 'user', 60, '{\"user_id\":\"60\",\"email\":\"dfdfd@gmail.com\",\"phone\":\"54543543545454\",\"password_hash\":\"$2y$10$80AaFvlDWvqigYb\\/cS0Sg.zgQIUrcTtxCWYhKyEoAgNmBPCiMDxOy\",\"first_name\":\"Mohatamim\",\"last_name\":\"dfdfsfsss\",\"profile_img_url\":\"uploads\\/profiles\\/default-avatar.jpg\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"0\",\"last_login\":null,\"created_at\":\"2025-12-30 18:36:18\",\"updated_at\":\"2025-12-30 18:36:18\"}', '{\"action\":\"update_user\",\"csrf_token\":\"174331bbde8310710e2cdb654f6b7dfe34b48e6f291f51853a0d1ef2caa61197\",\"user_id\":\"60\",\"first_name\":\"Mohatamim\",\"last_name\":\"dfdfsfsss\",\"email\":\"dfdfd@gmail.com\",\"phone\":\"54543543545454\",\"role\":\"farmer\",\"is_active\":\"0\",\"is_verified\":\"1\",\"password\":\"\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 12:36:56'),
(46, 49, 'update_user', 'user', 'user', 60, '{\"user_id\":\"60\",\"email\":\"dfdfd@gmail.com\",\"phone\":\"54543543545454\",\"password_hash\":\"$2y$10$80AaFvlDWvqigYb\\/cS0Sg.zgQIUrcTtxCWYhKyEoAgNmBPCiMDxOy\",\"first_name\":\"Mohatamim\",\"last_name\":\"dfdfsfsss\",\"profile_img_url\":\"uploads\\/profiles\\/default-avatar.jpg\",\"role\":\"farmer\",\"is_active\":\"0\",\"is_verified\":\"1\",\"last_login\":null,\"created_at\":\"2025-12-30 18:36:18\",\"updated_at\":\"2025-12-30 18:36:56\"}', '{\"action\":\"update_user\",\"csrf_token\":\"174331bbde8310710e2cdb654f6b7dfe34b48e6f291f51853a0d1ef2caa61197\",\"user_id\":\"60\",\"first_name\":\"Mohatamim\",\"last_name\":\"dfdfsfsss\",\"email\":\"dfdfd@gmail.com\",\"phone\":\"54543543545454\",\"role\":\"farmer\",\"is_active\":\"0\",\"is_verified\":\"1\",\"password\":\"\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 12:36:56'),
(47, 49, 'update_user', 'user', 'user', 59, '{\"user_id\":\"59\",\"email\":\"dfdfddfd@fdfd.com\",\"phone\":\"4545445454\",\"password_hash\":\"$2y$10$9\\/pibDWsaIpYMSNRxiXFLeCEOrdE.yPgV3A1EtT5k97xgekNGRu\\/u\",\"first_name\":\"vdddf\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/default-avatar.jpg\",\"role\":\"farmer\",\"is_active\":\"0\",\"is_verified\":\"1\",\"last_login\":null,\"created_at\":\"2025-12-30 18:14:14\",\"updated_at\":\"2025-12-30 18:23:24\"}', '{\"action\":\"update_user\",\"csrf_token\":\"174331bbde8310710e2cdb654f6b7dfe34b48e6f291f51853a0d1ef2caa61197\",\"user_id\":\"59\",\"first_name\":\"vdddf\",\"last_name\":\"\",\"email\":\"dfdfddfd@fdfd.com\",\"phone\":\"4545445454\",\"role\":\"officer\",\"is_active\":\"0\",\"is_verified\":\"1\",\"password\":\"\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 12:38:01'),
(48, 49, 'update_user', 'user', 'user', 59, '{\"user_id\":\"59\",\"email\":\"dfdfddfd@fdfd.com\",\"phone\":\"4545445454\",\"password_hash\":\"$2y$10$9\\/pibDWsaIpYMSNRxiXFLeCEOrdE.yPgV3A1EtT5k97xgekNGRu\\/u\",\"first_name\":\"vdddf\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/default-avatar.jpg\",\"role\":\"officer\",\"is_active\":\"0\",\"is_verified\":\"1\",\"last_login\":null,\"created_at\":\"2025-12-30 18:14:14\",\"updated_at\":\"2025-12-30 18:38:01\"}', '{\"action\":\"update_user\",\"csrf_token\":\"174331bbde8310710e2cdb654f6b7dfe34b48e6f291f51853a0d1ef2caa61197\",\"user_id\":\"59\",\"first_name\":\"vdddf\",\"last_name\":\"\",\"email\":\"dfdfddfd@fdfd.com\",\"phone\":\"4545445454\",\"role\":\"officer\",\"is_active\":\"0\",\"is_verified\":\"1\",\"password\":\"\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 12:38:01'),
(49, 49, 'add_ip_rule', 'security', 'ip_rule', NULL, NULL, '{\"ip\":\"192.168.0.1\",\"type\":\"blacklist\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 12:51:50'),
(50, 49, 'delete_ip_rule', 'security', 'ip_rule', 14, '{\"rule_id\":\"14\",\"ip_address\":\"192.168.0.1\",\"ip_range_start\":null,\"ip_range_end\":null,\"rule_type\":\"blacklist\",\"country_code\":null,\"reason\":\"\",\"auto_created\":\"0\",\"created_by\":null,\"created_at\":\"2025-12-30 18:51:50\",\"expires_at\":null}', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 12:55:30'),
(51, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 13:15:02'),
(52, 49, 'add_ip_rule', 'security', 'ip_rule', NULL, NULL, '{\"ip\":\"192.168.1.1\",\"type\":\"blacklist\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 13:31:21'),
(53, 49, 'delete_ip_rule', 'security', 'ip_rule', 15, '{\"rule_id\":\"15\",\"ip_address\":\"192.168.1.1\",\"ip_range_start\":null,\"ip_range_end\":null,\"rule_type\":\"blacklist\",\"country_code\":null,\"reason\":\"\",\"auto_created\":\"0\",\"created_by\":null,\"created_at\":\"2025-12-30 19:31:21\",\"expires_at\":null}', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 13:31:31'),
(54, 49, 'add_ip_rule', 'security', 'ip_rule', NULL, NULL, '{\"ip\":\"::1\",\"type\":\"blacklist\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 13:31:41'),
(55, 49, 'delete_ip_rule', 'security', 'ip_rule', 16, '{\"rule_id\":\"16\",\"ip_address\":\"::1\",\"ip_range_start\":null,\"ip_range_end\":null,\"rule_type\":\"blacklist\",\"country_code\":null,\"reason\":\"Blocked due to suspicious activity\",\"auto_created\":\"0\",\"created_by\":null,\"created_at\":\"2025-12-30 19:31:41\",\"expires_at\":null}', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 13:31:48'),
(56, 49, 'disable_task', '', 'task', 1, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 14:03:55'),
(57, 49, 'enable_task', '', 'task', 1, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 14:03:57'),
(58, 49, 'disable_task', '', 'task', 3, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 14:12:26'),
(59, 49, 'run_task', '', 'task', 5, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 14:14:00'),
(60, 49, 'disable_task', '', 'task', 5, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 14:14:05'),
(61, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 14:15:38'),
(62, 49, 'trigger_backup', 'backup', 'backup', 1, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'high', '2025-12-30 14:18:54'),
(63, 49, 'trigger_backup', 'backup', 'backup', 1, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'high', '2025-12-30 14:19:27'),
(64, 49, 'generate_report', 'report', 'report', NULL, NULL, '{\"type\":\"content_analytics\",\"format\":\"pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 14:20:55'),
(65, 49, 'delete_report', 'report', 'report', 1, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 14:21:33'),
(66, 49, 'delete_report', 'report', 'report', 2, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 14:21:36'),
(67, 49, 'delete_report', 'report', 'report', 3, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 14:21:40'),
(68, 49, 'trigger_backup', 'backup', 'backup', 1, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'high', '2025-12-30 14:22:00'),
(69, 49, 'create_backup', 'system', 'backup', NULL, NULL, 'full', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 14:23:22'),
(70, 49, 'generate_report', 'report', 'report', NULL, NULL, '{\"type\":\"user_summary\",\"format\":\"pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 14:32:28'),
(71, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'low', '2025-12-30 17:20:10'),
(72, 49, 'delete_user', 'user', 'user', 61, '{\"user_id\":\"61\",\"email\":\"naxoce1308@cameltok.com\",\"phone\":\"656565655454\",\"password_hash\":\"$2y$10$HwlbTyCv2Y4ZSk2BVLzb1eftnBZyJIbvPiof9G1wAPsRGL5zGPMjG\",\"first_name\":\"cv cvddd\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/profile_61_1767108114.JPG\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"1\",\"last_login\":null,\"created_at\":\"2025-12-30 21:21:10\",\"updated_at\":\"2025-12-30 21:21:54\"}', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'high', '2025-12-30 17:21:02'),
(73, 49, 'delete_user', 'user', 'user', 60, '{\"user_id\":\"60\",\"email\":\"dfdfd@gmail.com\",\"phone\":\"54543543545454\",\"password_hash\":\"$2y$10$80AaFvlDWvqigYb\\/cS0Sg.zgQIUrcTtxCWYhKyEoAgNmBPCiMDxOy\",\"first_name\":\"Mohatamim\",\"last_name\":\"dfdfsfsss\",\"profile_img_url\":\"uploads\\/profiles\\/default-avatar.jpg\",\"role\":\"farmer\",\"is_active\":\"0\",\"is_verified\":\"1\",\"last_login\":null,\"created_at\":\"2025-12-30 18:36:18\",\"updated_at\":\"2025-12-30 18:36:56\"}', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'high', '2025-12-30 17:21:05'),
(74, 49, 'update_user', 'user', 'user', 59, '{\"user_id\":\"59\",\"email\":\"dfdfddfd@fdfd.com\",\"phone\":\"4545445454\",\"password_hash\":\"$2y$10$9\\/pibDWsaIpYMSNRxiXFLeCEOrdE.yPgV3A1EtT5k97xgekNGRu\\/u\",\"first_name\":\"vdddf\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/default-avatar.jpg\",\"role\":\"officer\",\"is_active\":\"0\",\"is_verified\":\"1\",\"last_login\":null,\"created_at\":\"2025-12-30 18:14:14\",\"updated_at\":\"2025-12-30 18:38:01\"}', '{\"action\":\"update_user\",\"csrf_token\":\"24aad8141fa4c94f2ea77d8f8608c77487a6f1f21fd27763160dd2bf5a25be4d\",\"user_id\":\"59\",\"first_name\":\"vdddf\",\"last_name\":\"\",\"email\":\"dfdfddfd@fdfd.com\",\"phone\":\"4545445454\",\"role\":\"officer\",\"is_active\":\"1\",\"is_verified\":\"1\",\"password\":\"\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 17:21:30'),
(75, 49, 'update_user', 'user', 'user', 59, '{\"user_id\":\"59\",\"email\":\"dfdfddfd@fdfd.com\",\"phone\":\"4545445454\",\"password_hash\":\"$2y$10$9\\/pibDWsaIpYMSNRxiXFLeCEOrdE.yPgV3A1EtT5k97xgekNGRu\\/u\",\"first_name\":\"vdddf\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/default-avatar.jpg\",\"role\":\"officer\",\"is_active\":\"1\",\"is_verified\":\"1\",\"last_login\":null,\"created_at\":\"2025-12-30 18:14:14\",\"updated_at\":\"2025-12-30 23:21:30\"}', '{\"action\":\"update_user\",\"csrf_token\":\"24aad8141fa4c94f2ea77d8f8608c77487a6f1f21fd27763160dd2bf5a25be4d\",\"user_id\":\"59\",\"first_name\":\"vdddf\",\"last_name\":\"\",\"email\":\"dfdfddfd@fdfd.com\",\"phone\":\"4545445454\",\"role\":\"officer\",\"is_active\":\"1\",\"is_verified\":\"1\",\"password\":\"\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 17:21:30'),
(76, 49, 'update_user', 'user', 'user', 46, '{\"user_id\":\"46\",\"email\":\"mohatamim1234@gmail.com\",\"phone\":\"01609036435\",\"password_hash\":\"$2y$10$E6VY9PEQLHLcZtJ8p3zx9.1KXtk2XO0EEtxF2SMtnD7nl8KbRV8pK\",\"first_name\":\"Mohatamim\",\"last_name\":\"Jame\",\"profile_img_url\":\"uploads\\/profiles\\/profile_46_1767024301.JPG\",\"role\":\"admin\",\"is_active\":\"1\",\"is_verified\":\"1\",\"last_login\":\"2025-12-30 12:57:15\",\"created_at\":\"2025-12-29 20:09:36\",\"updated_at\":\"2025-12-30 14:04:15\"}', '{\"action\":\"update_user\",\"csrf_token\":\"24aad8141fa4c94f2ea77d8f8608c77487a6f1f21fd27763160dd2bf5a25be4d\",\"user_id\":\"46\",\"first_name\":\"Mohatamim\",\"last_name\":\"Haque\",\"email\":\"mohatamim1234@gmail.com\",\"phone\":\"01609036435\",\"role\":\"admin\",\"is_active\":\"1\",\"is_verified\":\"1\",\"password\":\"\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 17:21:58'),
(77, 49, 'update_user', 'user', 'user', 46, '{\"user_id\":\"46\",\"email\":\"mohatamim1234@gmail.com\",\"phone\":\"01609036435\",\"password_hash\":\"$2y$10$E6VY9PEQLHLcZtJ8p3zx9.1KXtk2XO0EEtxF2SMtnD7nl8KbRV8pK\",\"first_name\":\"Mohatamim\",\"last_name\":\"Haque\",\"profile_img_url\":\"uploads\\/profiles\\/profile_46_1767024301.JPG\",\"role\":\"admin\",\"is_active\":\"1\",\"is_verified\":\"1\",\"last_login\":\"2025-12-30 12:57:15\",\"created_at\":\"2025-12-29 20:09:36\",\"updated_at\":\"2025-12-30 23:21:58\"}', '{\"action\":\"update_user\",\"csrf_token\":\"24aad8141fa4c94f2ea77d8f8608c77487a6f1f21fd27763160dd2bf5a25be4d\",\"user_id\":\"46\",\"first_name\":\"Mohatamim\",\"last_name\":\"Haque\",\"email\":\"mohatamim1234@gmail.com\",\"phone\":\"01609036435\",\"role\":\"admin\",\"is_active\":\"1\",\"is_verified\":\"1\",\"password\":\"\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'medium', '2025-12-30 17:21:58'),
(78, 49, 'Updated profile', 'user', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', 'low', '2026-01-11 15:09:38'),
(79, 49, 'Updated profile', 'user', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', 'low', '2026-01-11 15:10:46'),
(80, 49, 'delete_user', 'user', 'user', 68, '{\"user_id\":\"68\",\"email\":\"adminY@smartcashi.com\",\"phone\":\"34554545454454\",\"password_hash\":\"$2y$10$ChuOAvAuaPYQi04jUgmbQe7VbP5c5dr.F6vM7AMKHLCAx6eonBhOi\",\"first_name\":\"wdfefeefe\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/profile_68_1768202025.jpeg\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"1\",\"last_login\":null,\"created_at\":\"2026-01-12 13:12:42\",\"updated_at\":\"2026-01-12 13:13:45\"}', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', 'high', '2026-01-15 10:47:34'),
(81, 49, 'delete_user', 'user', 'user', 46, '{\"user_id\":\"46\",\"email\":\"mohatamim1234@gmail.com\",\"phone\":\"01609036435\",\"password_hash\":\"$2y$12$aoQZrbK9jhA1BPfMfWhUHuEg5GK\\/TAoCATkeg2hTKT8MMHmUGRNCK\",\"first_name\":\"Mohatamim\",\"last_name\":\"Haque\",\"profile_img_url\":\"uploads\\/profiles\\/profile_46_1768116185.jpg\",\"role\":\"officer\",\"is_active\":\"1\",\"is_verified\":\"1\",\"last_login\":\"2026-01-12 16:08:16\",\"created_at\":\"2025-12-29 20:09:36\",\"updated_at\":\"2026-01-12 16:08:16\"}', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', 'high', '2026-01-15 10:47:51'),
(82, 49, 'delete_user', 'user', 'user', 67, '{\"user_id\":\"67\",\"email\":\"adminX@smartcashi.com\",\"phone\":\"473546747646\",\"password_hash\":\"$2y$10$OTLF3k9bWqEdTYhT8e5DFe0.RGEoV1isajz.DM8V4Y4\\/PgdsYrB9u\",\"first_name\":\"fdfdfd\",\"last_name\":\"\",\"profile_img_url\":\"\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"0\",\"last_login\":null,\"created_at\":\"2026-01-12 13:11:30\",\"updated_at\":\"2026-01-12 13:11:30\"}', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', 'high', '2026-01-15 10:48:04'),
(83, 49, 'delete_user', 'user', 'user', 66, '{\"user_id\":\"66\",\"email\":\"xcxcx@dhbdhfd.com\",\"phone\":\"43433435444\",\"password_hash\":\"$2y$10$tKvtoTzOn\\/0VTD5\\/eMITUunpbb9J3WsVrrRsx5XsIww4lMs6V38Gq\",\"first_name\":\"bxbvcv\",\"last_name\":\"\",\"profile_img_url\":\"\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"0\",\"last_login\":null,\"created_at\":\"2026-01-12 13:08:35\",\"updated_at\":\"2026-01-12 13:08:35\"}', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', 'high', '2026-01-15 10:48:09'),
(84, 49, 'delete_user', 'user', 'user', 65, '{\"user_id\":\"65\",\"email\":\"dfmndndfn@gmail.com\",\"phone\":\"545453345353\",\"password_hash\":\"$2y$10$cEDaPKo.uNvvxa0fFjYx\\/uyTYI7u9EJ\\/8YsukU2FaVk46btLGA6q2\",\"first_name\":\"nbdnbefd\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/profile_65_1768130081.png\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"1\",\"last_login\":null,\"created_at\":\"2026-01-11 17:13:39\",\"updated_at\":\"2026-01-11 17:14:41\"}', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', 'high', '2026-01-15 10:48:14'),
(85, 49, 'delete_user', 'user', 'user', 59, '{\"user_id\":\"59\",\"email\":\"dfdfddfd@fdfd.com\",\"phone\":\"4545445454\",\"password_hash\":\"$2y$12$aoQZrbK9jhA1BPfMfWhUHuEg5GK\\/TAoCATkeg2hTKT8MMHmUGRNCK\",\"first_name\":\"xxxxxx\",\"last_name\":\"\",\"profile_img_url\":\"uploads\\/profiles\\/default-avatar.jpg\",\"role\":\"farmer\",\"is_active\":\"1\",\"is_verified\":\"1\",\"last_login\":null,\"created_at\":\"2025-12-30 18:14:14\",\"updated_at\":\"2026-01-11 15:53:51\"}', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', 'high', '2026-01-15 10:48:21'),
(86, 49, 'admin_login', 'security', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', 'low', '2026-01-15 12:17:15'),
(87, 49, 'Updated profile', 'user', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', 'low', '2026-01-15 17:35:53'),
(88, 49, 'Updated profile', 'user', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', 'low', '2026-01-15 17:36:37'),
(89, 49, 'Updated profile', 'user', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', 'low', '2026-01-15 17:53:49'),
(90, 49, 'Updated profile', 'user', 'user', 49, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', 'low', '2026-01-15 17:54:35'),
(91, 49, 'export_users', 'user', 'export', NULL, NULL, '10 users exported', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0', 'low', '2026-05-16 05:08:22'),
(92, 49, 'export_users', 'user', 'export', NULL, NULL, '10 users exported', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0', 'low', '2026-05-16 10:21:09'),
(93, 49, 'export_users', 'user', 'export', NULL, NULL, '10 users exported', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0', 'low', '2026-05-16 10:21:12'),
(94, 49, 'export_users', 'user', 'export', NULL, NULL, '10 users exported', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0', 'low', '2026-05-16 10:21:12'),
(95, 49, 'export_users', 'user', 'export', NULL, NULL, '10 users exported', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0', 'low', '2026-05-16 10:21:13'),
(96, 49, 'export_users', 'user', 'export', NULL, NULL, '10 users exported', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'low', '2026-05-16 15:15:41'),
(97, 49, 'export_users', 'user', 'export', NULL, NULL, '10 users exported', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'low', '2026-05-16 15:37:35');

-- --------------------------------------------------------

--
-- Table structure for table `admin_ip_rules`
--

CREATE TABLE `admin_ip_rules` (
  `rule_id` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `ip_range_start` varchar(45) DEFAULT NULL,
  `ip_range_end` varchar(45) DEFAULT NULL,
  `rule_type` enum('whitelist','blacklist','geoblock') NOT NULL,
  `country_code` varchar(2) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `auto_created` tinyint(1) DEFAULT 0,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admin_login_attempts`
--

CREATE TABLE `admin_login_attempts` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `attempted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `success` tinyint(1) DEFAULT 0,
  `failure_reason` varchar(100) DEFAULT NULL,
  `geo_country` varchar(100) DEFAULT NULL,
  `geo_city` varchar(100) DEFAULT NULL,
  `user_agent` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_login_attempts`
--

INSERT INTO `admin_login_attempts` (`id`, `ip_address`, `email`, `attempted_at`, `success`, `failure_reason`, `geo_country`, `geo_city`, `user_agent`) VALUES
(1, '::1', 'mohatamim1234@gmail.com', '2025-12-30 05:48:14', 0, 'Invalid password', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(2, '::1', 'mohatamimhaque1234@gmail.com', '2025-12-30 05:51:46', 0, 'User not found or not admin', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(3, '::1', 'mohatamim1234@gmail.com', '2025-12-30 05:52:08', 0, 'Invalid password', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(4, '::1', 'admin@smartcashi.com', '2025-12-30 05:57:55', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(5, '::1', 'admin@smartcashi.com', '2025-12-30 06:01:30', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(6, '::1', 'admin@smartcashi.com', '2025-12-30 06:04:39', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(7, '::1', 'admin@smartcashi.com', '2025-12-30 06:06:30', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(8, '::1', 'admin@smartcashi.com', '2025-12-30 06:08:06', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(9, '::1', 'admin@smartcashi.com', '2025-12-30 06:19:49', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(10, '127.0.0.1', 'admin@smartcashi.com', '2025-12-30 08:14:10', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0'),
(11, '127.0.0.1', 'admin@smartcashi.com', '2025-12-30 08:48:52', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0'),
(12, '127.0.0.1', 'admin@smartcashi.com', '2025-12-30 08:51:50', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0'),
(13, '127.0.0.1', 'admin@smartcashi.com', '2025-12-30 08:52:01', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0'),
(14, '127.0.0.1', 'admin@smartcashi.com', '2025-12-30 08:52:12', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0'),
(15, '127.0.0.1', 'admin@smartcashi.com', '2025-12-30 09:13:38', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0'),
(16, '127.0.0.1', 'admin@smartcashi.com', '2025-12-30 09:24:33', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0'),
(17, '127.0.0.1', 'admin@smartcashi.com', '2025-12-30 09:33:35', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0'),
(18, '127.0.0.1', 'admin@smartcashi.com', '2025-12-30 09:35:55', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0'),
(19, '127.0.0.1', 'admin@smartcashi.com', '2025-12-30 09:39:54', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0'),
(20, '127.0.0.1', 'admin@smartcashi.com', '2025-12-30 10:02:33', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0'),
(21, '::1', 'admin@smartcashi.com', '2025-12-30 10:06:07', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(22, '::1', 'admin@smartcashi.com', '2025-12-30 10:13:27', 0, 'Invalid password', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(23, '::1', 'admin@smartcashi.com', '2025-12-30 11:08:42', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(24, '::1', 'admin@smartcashi.com', '2025-12-30 12:08:18', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(25, '::1', 'admin@smartcashi.com', '2025-12-30 13:15:02', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(26, '::1', 'admin@smartcashi.com', '2025-12-30 14:15:38', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(27, '::1', 'admin@smartcashi.com', '2025-12-30 17:20:10', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
(28, '127.0.0.1', 'admin@smartcashi.com', '2026-01-15 12:17:15', 1, NULL, NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0');

-- --------------------------------------------------------

--
-- Table structure for table `admin_notifications`
--

CREATE TABLE `admin_notifications` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `notification_type` enum('security','system','report','user','backup','error','warning','info','success') NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text DEFAULT NULL,
  `type` enum('info','success','warning','error') NOT NULL DEFAULT 'info',
  `created_by` int(11) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `action_url` varchar(255) DEFAULT NULL,
  `action_text` varchar(100) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` timestamp NULL DEFAULT NULL,
  `is_email_sent` tinyint(1) DEFAULT 0,
  `email_sent_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admin_profiles`
--

CREATE TABLE `admin_profiles` (
  `profile_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `access_level` enum('super_admin','admin','moderator') DEFAULT 'admin',
  `responsibilities` text DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admin_sessions`
--

CREATE TABLE `admin_sessions` (
  `session_id` varchar(128) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `device_fingerprint` varchar(64) DEFAULT NULL,
  `device_info` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`device_info`)),
  `geo_location` varchar(255) DEFAULT NULL,
  `login_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `terminated_reason` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_sessions`
--

INSERT INTO `admin_sessions` (`session_id`, `user_id`, `ip_address`, `user_agent`, `device_fingerprint`, `device_info`, `geo_location`, `login_at`, `last_activity`, `expires_at`, `is_active`, `terminated_reason`) VALUES
('1cc9f5a3834fc0f6a7e199ee1eb6f7f9ea139752f86e2ea0a4b92ace61ff8860', 49, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', '000000007a846d6c', NULL, NULL, '2026-01-15 12:17:15', '2026-01-15 12:17:15', '2026-01-15 07:47:15', 1, NULL),
('1cdebb290796e3a10568827b850883dc9a372675b48725095f6f4a41e02f497c', 49, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '000000003359246a', NULL, NULL, '2025-12-30 09:33:35', '2025-12-30 09:33:35', '2025-12-30 05:03:35', 1, NULL),
('2bf507c3a42f1ee8f55324492e274a8c8ed6d8fd8206e4e23a192d9f2b145ade', 49, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '000000003359246a', NULL, NULL, '2025-12-30 09:24:33', '2025-12-30 09:24:33', '2025-12-30 04:54:33', 1, NULL),
('2dafdb133e695605bfd9e9066d84ac8e76f68b28958e029bb759374170ea06f4', 49, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '000000003359246a', NULL, NULL, '2025-12-30 08:52:12', '2025-12-30 08:52:12', '2025-12-30 04:22:12', 1, NULL),
('37f215f1c3895262e6e24672792fde99899e808513654d2be20cd0d09765687f', 49, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '00000000329b62ec', NULL, NULL, '2025-12-30 17:20:10', '2025-12-30 17:20:10', '2025-12-30 12:50:10', 1, NULL),
('40e8b8590e4899630c65f1906d9947a016bad243b06e697819cca21704a0e085', 49, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '000000003359246a', NULL, NULL, '2025-12-30 08:51:50', '2025-12-30 08:51:50', '2025-12-30 04:21:50', 1, NULL),
('4e151270467bbc086a4103b7ed18ab5145a22918fdf124371249c0228d668c60', 49, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '00000000329b62ec', NULL, NULL, '2025-12-30 10:06:07', '2025-12-30 10:06:07', '2025-12-30 05:36:07', 1, NULL),
('73c13de3146613b160ab51c756ae03c1d1aa66de09aa6502dfc77ce1d5c326c3', 49, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '000000003359246a', NULL, NULL, '2025-12-30 09:39:53', '2025-12-30 09:39:53', '2025-12-30 05:09:53', 1, NULL),
('936c3d91cc08956f66bf18005be53859c06b3d1880451b45137e17c1adf44315', 49, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '000000003359246a', NULL, NULL, '2025-12-30 08:14:10', '2025-12-30 08:14:10', '2025-12-30 03:44:10', 1, NULL),
('951f340ee6570b0fbdb390f617259b972efffe9fc137b38ed1d61191d41d6505', 49, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '000000003359246a', NULL, NULL, '2025-12-30 09:35:55', '2025-12-30 09:35:55', '2025-12-30 05:05:55', 1, NULL),
('b242ed036c4b332c155b1acf5369148a534656ea853c57ab21af038b2e5b31f1', 49, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '000000003359246a', NULL, NULL, '2025-12-30 08:52:01', '2025-12-30 08:52:01', '2025-12-30 04:22:01', 1, NULL),
('ce84e76daf2bf3cf40dad3ca8320acaaf8ec2e828cd794f536962633ed16c50d', 49, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '00000000329b62ec', NULL, NULL, '2025-12-30 14:15:38', '2025-12-30 14:15:38', '2025-12-30 09:45:38', 1, NULL),
('cea69fcf736f376f1ec062edf8b31e1fc43e7d7e0b3e80b8702eb027303e5485', 49, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '000000003359246a', NULL, NULL, '2025-12-30 10:02:33', '2025-12-30 10:04:28', '2025-12-30 05:32:33', 0, 'user_logout'),
('dc63831c76c681a9fbe7a0ee61f061ea80a47e81eadd907a302d9b3bda8b9e38', 49, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '000000003359246a', NULL, NULL, '2025-12-30 09:13:38', '2025-12-30 09:13:38', '2025-12-30 04:43:38', 1, NULL),
('e6fa0ed68159f33e6de1fa04df1771cf6a42b9d73b1f501483b80fa46c6d0dda', 49, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '00000000329b62ec', NULL, NULL, '2025-12-30 12:08:18', '2025-12-30 12:08:18', '2025-12-30 07:38:18', 1, NULL),
('f16e3653c6a47fc95d933287748a2926f86871be5fe56abbafa9dccb8b1c3861', 49, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '00000000329b62ec', NULL, NULL, '2025-12-30 13:15:02', '2025-12-30 13:15:02', '2025-12-30 08:45:02', 1, NULL),
('f6f39b1f073cd04f7340f7e2fbadb08cb5f26315775d209f9169e9de37fa4a16', 49, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '000000003359246a', NULL, NULL, '2025-12-30 08:48:52', '2025-12-30 08:48:52', '2025-12-30 04:18:52', 1, NULL),
('fa715270513cb34324b950adbb0445ac25848a04fe94080cf9a99f680f26de1e', 49, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '00000000329b62ec', NULL, NULL, '2025-12-30 11:08:42', '2025-12-30 11:08:42', '2025-12-30 06:38:42', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_settings`
--

CREATE TABLE `admin_settings` (
  `setting_id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('string','number','boolean','json','encrypted') DEFAULT 'string',
  `setting_group` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_sensitive` tinyint(1) DEFAULT 0,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_settings`
--

INSERT INTO `admin_settings` (`setting_id`, `setting_key`, `setting_value`, `setting_type`, `setting_group`, `description`, `is_sensitive`, `updated_by`, `updated_at`) VALUES
(1, 'session_timeout', '1800', 'number', 'security', 'Admin session timeout in seconds', 0, NULL, '2025-12-30 05:45:11'),
(2, 'max_login_attempts', '5', 'number', 'security', 'Maximum failed login attempts before lockout', 0, NULL, '2025-12-30 05:45:11'),
(3, 'lockout_duration', '900', 'number', 'security', 'Lockout duration in seconds after max failed attempts', 0, NULL, '2025-12-30 05:45:11'),
(4, 'require_2fa', '0', 'boolean', 'security', 'Require 2FA for all admin users', 0, NULL, '2025-12-30 05:45:11'),
(5, 'password_min_length', '8', 'number', 'security', 'Minimum password length', 0, NULL, '2025-12-30 05:45:11'),
(6, 'password_require_uppercase', '1', 'boolean', 'security', 'Require uppercase in password', 0, NULL, '2025-12-30 05:45:11'),
(7, 'password_require_lowercase', '1', 'boolean', 'security', 'Require lowercase in password', 0, NULL, '2025-12-30 05:45:11'),
(8, 'password_require_number', '1', 'boolean', 'security', 'Require number in password', 0, NULL, '2025-12-30 05:45:11'),
(9, 'password_require_special', '0', 'boolean', 'security', 'Require special character in password', 0, NULL, '2025-12-30 05:45:11'),
(10, 'password_expiry_days', '0', 'number', 'security', 'Password expiry in days (0 = never)', 0, NULL, '2025-12-30 05:45:11'),
(11, 'password_history_count', '5', 'number', 'security', 'Number of previous passwords to remember', 0, NULL, '2025-12-30 05:45:11'),
(12, 'enable_geo_blocking', '0', 'boolean', 'security', 'Enable geo-location based blocking', 0, NULL, '2025-12-30 05:45:11'),
(13, 'allowed_countries', '[]', 'json', 'security', 'List of allowed country codes for admin access', 0, NULL, '2025-12-30 05:45:11'),
(14, 'enable_ip_whitelist', '0', 'boolean', 'security', 'Enable IP whitelist for admin access', 0, NULL, '2025-12-30 05:45:11'),
(15, 'enable_honeypot', '1', 'boolean', 'security', 'Enable honeypot trap fields', 0, NULL, '2025-12-30 05:45:11'),
(16, 'enable_device_fingerprint', '1', 'boolean', 'security', 'Enable device fingerprinting', 0, NULL, '2025-12-30 05:45:11'),
(17, 'trusted_device_expiry_days', '30', 'number', 'security', 'Trusted device expiry in days', 0, NULL, '2025-12-30 05:45:11'),
(18, 'maintenance_mode', '0', 'boolean', 'system', 'Enable maintenance mode', 0, 49, '2026-05-15 23:54:30'),
(19, 'maintenance_message', 'System is under maintenance. Please try again later.', 'string', 'system', 'Maintenance mode message', 0, 49, '2026-05-15 23:54:30'),
(20, 'backup_retention_days', '30', 'number', 'backup', 'Number of days to retain backups', 0, NULL, '2025-12-30 05:45:11'),
(21, 'auto_backup_enabled', '1', 'boolean', 'backup', 'Enable automatic daily backups', 0, NULL, '2025-12-30 05:45:11'),
(22, 'rate_limit_requests', '100', 'number', 'security', 'Maximum requests per minute', 0, NULL, '2025-12-30 05:45:11'),
(23, 'rate_limit_window', '60', 'number', 'security', 'Rate limit window in seconds', 0, NULL, '2025-12-30 05:45:11'),
(24, 'ai_provider', 'groq', 'string', 'ai', NULL, 0, 49, '2026-05-17 16:38:28'),
(25, 'ai_model', 'llama-3.3-70b-versatile', 'string', 'ai', NULL, 0, 49, '2026-05-17 16:38:28'),
(26, 'ai_temperature', '0.7', 'string', 'ai', NULL, 0, 49, '2026-05-17 16:38:28'),
(27, 'ai_max_tokens', '1024', 'string', 'ai', NULL, 0, 49, '2026-05-17 16:38:28'),
(28, 'ai_system_prompt', '', 'string', 'ai', NULL, 0, 49, '2026-05-17 16:38:28'),
(29, 'maintenance_allowed_ips', '', 'string', 'maintenance', NULL, 0, 49, '2026-05-15 23:54:30'),
(30, 'ai_api_key_groq', 'xxxxxxxxxx', 'string', 'ai', NULL, 1, 49, '2026-05-17 16:38:28');

-- --------------------------------------------------------

--
-- Table structure for table `admin_trusted_devices`
--

CREATE TABLE `admin_trusted_devices` (
  `device_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `device_fingerprint` varchar(64) NOT NULL,
  `device_name` varchar(100) DEFAULT NULL,
  `browser` varchar(100) DEFAULT NULL,
  `browser_version` varchar(50) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `os_version` varchar(50) DEFAULT NULL,
  `device_type` enum('desktop','mobile','tablet','unknown') DEFAULT 'unknown',
  `last_used` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_ip` varchar(45) DEFAULT NULL,
  `is_trusted` tinyint(1) DEFAULT 1,
  `trust_expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_trusted_devices`
--

INSERT INTO `admin_trusted_devices` (`device_id`, `user_id`, `device_fingerprint`, `device_name`, `browser`, `browser_version`, `os`, `os_version`, `device_type`, `last_used`, `last_ip`, `is_trusted`, `trust_expires_at`, `created_at`) VALUES
(1, 49, '00000000329b62ec', 'Chrome on Windows', 'Chrome', NULL, 'Windows', NULL, 'unknown', '2025-12-30 17:20:10', '::1', 1, '2026-01-29 10:06:07', '2025-12-30 10:06:07');

-- --------------------------------------------------------

--
-- Table structure for table `advisories`
--

CREATE TABLE `advisories` (
  `advisory_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `advisory_type` enum('general','weather','seasonal','pest_control','irrigation','market') DEFAULT 'general',
  `target_crops` varchar(255) DEFAULT NULL,
  `target_region` varchar(100) DEFAULT NULL,
  `priority` enum('low','medium','high') DEFAULT 'medium',
  `valid_from` date DEFAULT NULL,
  `valid_to` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `views` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `agent_conversations`
--

CREATE TABLE `agent_conversations` (
  `id` int(11) NOT NULL,
  `conversation_id` varchar(64) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT 'New Chat',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `summary` text DEFAULT NULL,
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `is_archived` tinyint(1) NOT NULL DEFAULT 0,
  `share_token` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `agent_conversations`
--

INSERT INTO `agent_conversations` (`id`, `conversation_id`, `user_id`, `title`, `created_at`, `updated_at`, `summary`, `is_pinned`, `is_archived`, `share_token`) VALUES
(6, '253ba0e2ee6cefe4f9bdea3451cc2d22', 64, 'New Chat', '2026-05-15 23:58:35', '2026-05-15 23:58:35', NULL, 0, 0, NULL),
(7, '35d55edcf814d4ad7967c98ff570b7ba', 64, 'Greeting & Introduction', '2026-05-16 00:17:49', '2026-05-16 04:31:43', NULL, 0, 0, NULL),
(8, '25b8e657e77e4a932bdc684e27eeb122', 64, 'ধানের হলুদ পাতার সম', '2026-05-16 04:31:00', '2026-05-16 04:31:14', NULL, 0, 0, NULL),
(9, '2126a4bb42fbd544804b6dcd6fda0193', 64, 'Optimal Fertilization for Bangladeshi Vegetable Gardens', '2026-05-16 04:32:42', '2026-05-16 04:32:46', NULL, 0, 0, NULL),
(10, '7fe595d47427e4c919c0e3dd892ef1f9', 76, 'Optimizing Fertilizer for Bangladeshi Vegetable Gardens', '2026-05-16 04:44:10', '2026-05-16 04:44:14', NULL, 0, 0, NULL),
(11, 'e62ebb1d16ef9d7aeead9a4d677f29b7', 64, 'সপ্তাহের সবজি লাগান', '2026-05-16 15:10:08', '2026-05-16 15:10:12', NULL, 0, 0, NULL),
(12, 'de9c401b4210fc96727e3346a916f0a5', 64, 'সপ্তাহের সবজি উদ্দ', '2026-05-16 19:49:17', '2026-05-16 19:55:22', NULL, 0, 0, NULL),
(13, '67a634ff3466ffc874821d37f166efb1', 64, 'Organic Pest Control Methods Explained', '2026-05-16 19:59:01', '2026-05-16 19:59:05', NULL, 0, 0, NULL),
(14, 'dab188e6f4f6eb36ed4c76fa382df377', 64, 'Optimal Fertilization for Bangladeshi Vegetable Gardens', '2026-05-16 19:59:19', '2026-05-16 19:59:33', NULL, 0, 0, NULL),
(15, '40e65a8ccc504a05f42bb519cdae159e', 64, 'Optimal Fertilization for Bangladeshi Vegetable Gardens', '2026-05-16 20:01:31', '2026-05-16 20:01:34', NULL, 0, 0, NULL),
(16, 'c688bc823694b8af5dc75c5066d02e92', 64, 'Optimal Fertilizer Planning for Bangladesh Gardens', '2026-05-16 20:26:06', '2026-05-16 20:28:16', NULL, 0, 0, NULL),
(17, '1f48d1a67a7579b9bd934ecc8d8caabd', 64, 'Analyzing Crop Damage and Potential Causes', '2026-05-16 20:44:03', '2026-05-16 20:44:06', NULL, 0, 0, NULL),
(18, 'cdbc7dafaecf1f70e45e0e1dd6df4626', 64, 'Crop Disease Identification Needed Immediately', '2026-05-16 20:59:25', '2026-05-16 20:59:27', NULL, 0, 0, NULL),
(19, 'd3b6aabfc451f267b03796321fa9859b', 64, 'ধান গাছে হলুদ পাতা', '2026-05-16 21:09:18', '2026-05-16 21:14:14', NULL, 0, 0, NULL),
(39, 'bcf8b5806342a7dcc463ee13797ed0f9', 64, 'New Chat', '2026-05-17 15:43:12', '2026-05-17 16:05:14', NULL, 0, 1, NULL),
(54, '83988129ef7ac1b34111576f0c84bed3', 64, 'বোরো ধানের জন্য সার প', '2026-05-17 17:15:44', '2026-05-17 17:21:41', NULL, 0, 1, '74031d8cf44650cae5c2edd0da77a391'),
(55, '3ad9b26b0fd0e15be1c4ddfbd438ab6b', 64, 'Crop Disease Identification Needed Immediately', '2026-05-17 17:20:48', '2026-05-17 17:22:32', NULL, 0, 0, '023fe8501416dbefd04ad6906099ea82');

-- --------------------------------------------------------

--
-- Table structure for table `agent_messages`
--

CREATE TABLE `agent_messages` (
  `id` int(11) NOT NULL,
  `conversation_id` varchar(64) NOT NULL,
  `role` enum('user','assistant') NOT NULL,
  `content` text NOT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `feedback` tinyint(1) DEFAULT NULL COMMENT '1=thumbs_up -1=thumbs_down'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `agent_messages`
--

INSERT INTO `agent_messages` (`id`, `conversation_id`, `role`, `content`, `images`, `created_at`, `feedback`) VALUES
(1, '25b8e657e77e4a932bdc684e27eeb122', 'user', 'আমার ধান গাছে হলুদ পাতা দেখা দিচ্ছে, কী করবো?', NULL, '2026-05-16 04:31:02', NULL),
(2, '25b8e657e77e4a932bdc684e27eeb122', 'assistant', '<p>হলুদ পাতা দেখা দিলে ধান গাছের নাইট্রোজেন এবং আয়রন এর অভাব হতে পারে। <strong>নাইট্রোজেন এর অভাব</strong> হলে পাতা হলুদ হয়ে যায় এবং গাছের বৃদ্ধি কমে যায়। <strong>আয়রন এর অভাব</strong> হলে পাতা হলুদ হয়ে যায় এবং গাছের বৃদ্ধি কমে যায়। </p><p>এই সমস্যা সমাধানের জন্য আপনি নিম্নলিখিত বিষয়গুলো করতে পারেন:</p><p><em> <strong>নাইট্রোজেন এর অভাব</strong>: আপনি ১০ কেজি ইউরিয়া প্রতি বিঘা মাটিতে প্রয়োগ করতে পারেন।<br></em> <strong>আয়রন এর অভাব</strong>: আপনি ফেরাস সালফেট (FeSO4) ১ কেজি প্রতি বিঘা মাটিতে প্রয়োগ করতে পারেন।</p><p>এছাড়াও, আপনি মাটি পরীক্ষা করে দেখতে পারেন যে আপনার মাটিতে কোন ধরনের পুষ্টির অভাব আছে। এটি আপনাকে সঠিক সিদ্ধান্ত নিতে সাহায্য করবে।</p><p>আশা করি এই তথ্যগুলো আপনার জন্য উপযোগী হবে। 🌾</p>', NULL, '2026-05-16 04:31:02', NULL),
(3, '25b8e657e77e4a932bdc684e27eeb122', 'user', 'আমার ধান গাছে হলুদ পাতা দেখা দিচ্ছে, কী করবো?', NULL, '2026-05-16 04:31:14', NULL),
(4, '25b8e657e77e4a932bdc684e27eeb122', 'assistant', '<p>আপনার ধান গাছে হলুদ পাতা দেখা দিলে আপনি কয়েকটি বিষয় পরীক্ষা করতে পারেন:</p><p><em>   <strong>নাইট্রোজেন এর অভাব</strong>: আপনি ১০ কেজি ইউরিয়া প্রতি বিঘা মাটিতে প্রয়োগ করতে পারেন।<br></em>   <strong>আয়রন এর অভাব</strong>: আপনি ফেরাস সালফেট (FeSO4) ১ কেজি প্রতি বিঘা মাটিতে প্রয়োগ করতে পারেন।<br><em>   <strong>পানির অভাব</strong>: আপনি ধান গাছে পর্যাপ্ত পানি সরবরাহ করতে পারেন।<br></em>   <strong>মাটি পরীক্ষা</strong>: আপনি মাটি পরীক্ষা করে দেখতে পারেন যে আপনার মাটিতে কোন ধরনের পুষ্টির অভাব আছে।</p><p>এই সমস্যা সমাধানের জন্য আপনি অভিজ্ঞ কৃষক বা কৃষি বিশেষজ্ঞের সাথে পরামর্শ করতে পারেন। আশা করি এই তথ্যগুলো আপনার জন্য উপযোগী হবে। 🌾</p>', NULL, '2026-05-16 04:31:14', NULL),
(5, '35d55edcf814d4ad7967c98ff570b7ba', 'user', 'hello', NULL, '2026-05-16 04:31:43', NULL),
(6, '35d55edcf814d4ad7967c98ff570b7ba', 'assistant', '<p><strong>Chashi Bhai</strong> — Your Expert Agriculture AI Assistant</p><p>Hello! I\'m Chashi Bhai, your AI farming expert for Bangladesh.</p><p><strong>How can I help you today?</strong><br>• Crop management and cultivation<br>• Soil health and fertilizer advice<br>• Pest and disease control<br>• Weather and irrigation planning<br>• Market prices and selling strategies<br>• Government subsidies and schemes</p><p>Feel free to ask me anything about farming!</p>', NULL, '2026-05-16 04:31:43', NULL),
(7, '2126a4bb42fbd544804b6dcd6fda0193', 'user', 'Best fertilizer schedule for vegetable garden in Bangladesh', NULL, '2026-05-16 04:32:45', NULL),
(8, '2126a4bb42fbd544804b6dcd6fda0193', 'assistant', '<p><strong>সবজি বাগানের জন্য সেরা সার সময়সূচি (Best Fertilizer Schedule for Vegetable Garden)</strong></p><p>বাংলাদেশে সবজি চাষের জন্য সার প্রয়োগের সময়সূচি নিম্নরূপ:</p><p><em> <strong>বাসাল ডোজ (Basal Dose)</strong>: চারা রোপণের সময় ২-৩ টন গোবর সার বা ১-২ টন ভেরিকম্পোস্ট প্রয়োগ করুন।<br></em> <strong>ইউরিয়া (Urea)</strong>: ১/৩ অংশ বাসাল ডোজ হিসেবে, ১/৩ অংশ ১৫-২০ দিন পরে এবং ১/৩ অংশ ৩০-৪০ দিন পরে প্রয়োগ করুন।<br><em> <strong>টিএসপি (TSP)</strong>: ১৫-২০ দিন পরে ১৫০-২০০ কেজি/বিঘা হারে প্রয়োগ করুন।<br></em> <strong>এমওপি (MOP)</strong>: ৩০-৪০ দিন পরে ১০০-১৫০ কেজি/বিঘা হারে প্রয়োগ করুন।<br><em> <strong>জিংক সালফেট (Zinc Sulfate)</strong>: ২০-২৫ দিন পরে ২-৩ কেজি/বিঘা হারে প্রয়োগ করুন।</p><p><strong>সবজি প্রকার অনুযায়ী সার প্রয়োগের সুপারিশ</strong></p><p></em> টমেটো, বেগুন, মরিচ: ইউরিয়া ১৫০ কেজি/বিঘা, টিএসপি ২০০ কেজি/বিঘা, এমওপি ১০০ কেজি/বিঘা<br><em> কলা, বাঁধাকপি: ইউরিয়া ১০০ কেজি/বিঘা, টিএসপি ১৫০ কেজি/বিঘা, এমওপি ৫০ কেজি/বিঘা<br></em> আলু, মূলা: ইউরিয়া ১০০ কেজি/বিঘা, টিএসপি ১০০ কেজি/বিঘা, এমওপি ৫০ কেজি/বিঘা</p><p><strong>সাবধানতা</strong></p><p>*</p>', NULL, '2026-05-16 04:32:45', NULL),
(9, '7fe595d47427e4c919c0e3dd892ef1f9', 'user', 'Best fertilizer schedule for vegetable garden in Bangladesh', NULL, '2026-05-16 04:44:14', NULL),
(10, '7fe595d47427e4c919c0e3dd892ef1f9', 'assistant', '<p><strong>সবজি বাগানের জন্য সেরা সার সময়সূচি</strong></p><p>বাংলাদেশে সবজি বাগানের জন্য সার সময়সূচি নিম্নরূপ:</p><p><em> <strong>বসন্তকাল (মার্চ-জুন)</strong>:<br> + টমেটো, বেগুন, মরিচ: প্রতি সপ্তাহে ১০০ গ্রাম ইউরিয়া + ৫০ গ্রাম টিএসপি + ৫০ গ্রাম এমওপি<br> + কাঁচা মরিচ, লাউ, ঝিঙ্গা: প্রতি সপ্তাহে ৫০ গ্রাম ইউরিয়া + ২৫ গ্রাম টিএসপি + ২৫ গ্রাম এমওপি<br></em> <strong>গ্রীষ্মকাল (জুন-সেপ্টেম্বর)</strong>:<br> + সবজি গাছে প্রতি সপ্তাহে ১৫০ গ্রাম ইউরিয়া + ৭৫ গ্রাম টিএসপি + ৭৫ গ্রাম এমওপি<br><em> <strong>শীতকাল (অক্টোবর-ফেব্রুয়ারি)</strong>:<br> + টমেটো, বেগুন, মরিচ: প্রতি সপ্তাহে ১০০ গ্রাম ইউরিয়া + ৫০ গ্রাম টিএসপি + ৫০ গ্রাম এমওপি<br> + কাঁচা মরিচ, লাউ, ঝিঙ্গা: প্রতি সপ্তাহে ৫০ গ্রাম ইউরিয়া + ২৫ গ্রাম টিএসপি + ২৫ গ্রাম এমওপি</p><p><strong>সাবধানতা</strong>:<br></em> সার প্রয়োগের আগে মাটি পরীক্ষা করে নিন<br><em> সার প্রয়োগের সময় মাটির আর্দ্রতা বিবেচনা করুন<br></em> অতিরিক্ত সার প্রয়োগ এড়িয়ে চলুন</p><p>**সবজি বাগানের জন্য সার সময়সূচি অনুসরণ করে, আপনি ভালো ফলন পেতে পারেন এবং আপনার সবজি বাগানকে</p>', NULL, '2026-05-16 04:44:14', NULL),
(11, 'e62ebb1d16ef9d7aeead9a4d677f29b7', 'user', 'এই সপ্তাহে কোন সবজি লাগানো ভালো?', NULL, '2026-05-16 15:10:11', NULL),
(12, 'e62ebb1d16ef9d7aeead9a4d677f29b7', 'assistant', '<p><strong>এই সপ্তাহে সবজি লাগানোর সময় হয়েছে!</strong> 🌱</p><p>ধান কাটার পর এই সময়টা সবজি চাষের জন্য খুবই উপযুক্ত। এই সময় মূল্যবান সবজি যেমন <strong>টমেটো</strong>, <strong>বেগুন</strong>, <strong>মরিচ</strong>, <strong>কাঁচা মরিচ</strong> লাগানো যায়। </p><p>এছাড়াও, <strong>সয়াবিন</strong>, <strong>মটর</strong>, <strong>লাউ</strong>, <strong>কুমড়া</strong> এই সময় লাগানো যায়। </p><p><strong>লাগানোর সময়:</strong></p><p><em> টমেটো: ১৫-২০ দিনের চারা লাগানো যায়<br></em> বেগুন: ১৫-২০ দিনের চারা লাগানো যায়<br><em> মরিচ: ১০-১৫ দিনের চারা লাগানো যায়</p><p><strong>মনে রাখবেন:</strong></p><p></em> সবজি লাগানোর আগে জমিটি ভালো করে তৈরি করুন<br><em> সবজির জন্য প্রয়োজনীয় সার দিন<br></em> পানি দেওয়ার সময় সতর্ক থাকুন, অতিরিক্ত পানি দিলে সবজি মারা যেতে পারে</p><p>আশা করি, এই তথ্যগুলো আপনার সবজি চাষে সাহায্য করবে! 🌼</p>', NULL, '2026-05-16 15:10:11', NULL),
(13, 'de9c401b4210fc96727e3346a916f0a5', 'user', 'এই সপ্তাহে কোন সবজি লাগানো ভালো?', NULL, '2026-05-16 19:49:21', NULL),
(14, 'de9c401b4210fc96727e3346a916f0a5', 'assistant', '<p><strong>সবজি লাগানোর সেরা সময়!</strong> 🌱</p><p>এই সপ্তাহে ঢাকা, বাংলাদেশে, আপনি নিম্নলিখিত সবজি লাগাতে পারেন:</p><p><em> <strong>টমেটো</strong>: এটি একটি জনপ্রিয় সবজি যা বাংলাদেশের আবহাওয়ায় ভালো জন্মায়। টমেটো লাগানোর জন্য সেরা সময় হল নভেম্বর থেকে ফেব্রুয়ারি।<br></em> <strong>ব্রিনজাল</strong>: এটি আরেকটি জনপ্রিয় সবজি যা বাংলাদেশের আবহাওয়ায় ভালো জন্মায়। ব্রিনজাল লাগানোর জন্য সেরা সময় হল নভেম্বর থেকে ফেব্রুয়ারি।<br><em> <strong>কলা</strong>: এটি একটি সবজি যা বাংলাদেশের আবহাওয়ায় ভালো জন্মায়। কলা লাগানোর জন্য সেরা সময় হল নভেম্বর থেকে ফেব্রুয়ারি।</p><p><strong>লাগানোর পরামর্শ:</strong></p><p></em> সবজি লাগানোর আগে, মাটি পরীক্ষা করুন এবং যদি প্রয়োজন হয় তবে সার দিন।<br><em> সবজি লাগানোর জন্য সেরা সময় হল সকালে বা সন্ধ্যায়।<br></em> সবজি লাগানোর পর, মাটি ভিজিয়ে রাখুন এবং যদি প্রয়োজন হয় তবে কীটনাশক ব্যবহার করুন।</p><p>আশা করি এই তথ্যগুলি আপনার সবজি চাষে সাহায্য করবে! 🌼</p>', NULL, '2026-05-16 19:49:21', NULL),
(15, 'de9c401b4210fc96727e3346a916f0a5', 'user', 'এই সময়ে টমেটো লাগানোর প্রক্রিয়া কী?', NULL, '2026-05-16 19:49:33', NULL),
(16, 'de9c401b4210fc96727e3346a916f0a5', 'assistant', '<p>টমেটো লাগানোর জন্য নিম্নলিখিত প্রক্রিয়া অনুসরণ করুন:</p><p><strong>প্রস্তুতি:</strong></p><p><li><strong>মাটি পরীক্ষা করুন</strong>: মাটির পিএইচ পরীক্ষা করুন এবং প্রয়োজন অনুযায়ী সার দিন।</li><br><li><strong>বীজ নির্বাচন করুন</strong>: উচ্চ ফলনশীল এবং রোগ প্রতিরোধী টমেটো বীজ নির্বাচন করুন।</li><br><li><strong>বীজ উদ্ভিদন</strong>: বীজগুলিকে 1-2 সেমি গভীরতায় মাটিতে রোপণ করুন এবং পানি দিন।</li></p><p><strong>রোপণ:</strong></p><p><li><strong>রোপণের সময়</strong>: টমেটো রোপণের জন্য সেরা সময় হল নভেম্বর থেকে ফেব্রুয়ারি।</li><br><li><strong>রোপণের দূরত্ব</strong>: টমেটো গাছগুলিকে 60-90 সেমি দূরত্বে রোপণ করুন।</li><br><li><strong>রোপণের গভীরতা</strong>: টমেটো গাছগুলিকে 10-15 সেমি গভীরতায় রোপণ করুন।</li></p><p><strong>যত্ন:</strong></p><p><li><strong>পানি দেওয়া</strong>: টমেটো গাছগুলিকে নিয়মিত পানি দিন।</li><br><li><strong>সার দেওয়া</strong>: টমেটো গাছগুলিকে প্রয়োজন অনুযায়ী সার দিন।</li><br><li><strong>কীটনাশক ব্যবহার</strong>: টমেটো গাছগুলিকে কীটনাশক ব্যবহার করে রক্ষা করুন।</li></p><p>আশা করি এই তথ্যগুলি আপনার টমেটো চাষে সাহায্য করবে! 🌼</p>', NULL, '2026-05-16 19:49:33', NULL),
(17, 'de9c401b4210fc96727e3346a916f0a5', 'user', 'টমেটো লাগানোর পর কীভাবে মাটিকে কম্বাইনে না নিয়ে রাখবে?', NULL, '2026-05-16 19:49:53', NULL),
(18, 'de9c401b4210fc96727e3346a916f0a5', 'assistant', '<p>টমেটো লাগানোর পর মাটিকে কম্বাইনে না নিয়ে রাখার জন্য নিম্নলিখিত পদ্ধতিগুলি অনুসরণ করুন:</p><p><em> <strong>মালচিং</strong>: মালচিং হল একটি পদ্ধতি যেখানে মাটির উপরে একটি পাতলা স্তর সাবমেটেরিয়াল রাখা হয়। এটি মাটিকে শুষ্ক হতে বাধা দেয় এবং মাটির তাপমাত্রা নিয়ন্ত্রণ করে।<br></em> <strong>কভার ক্রপ</strong>: কভার ক্রপ হল একটি পদ্ধতি যেখানে মাটির উপরে একটি ফসল লাগানো হয় যা মাটিকে ঢেকে রাখে। এটি মাটিকে শুষ্ক হতে বাধা দেয় এবং মাটির তাপমাত্রা নিয়ন্ত্রণ করে।<br><em> <strong>মাটির গঠন</strong>: মাটির গঠন উন্নত করার জন্য জৈব পদার্থ যেমন গোবর, কম্পোস্ট বা গ্রিন ম্যানিউর ব্যবহার করা যেতে পারে। এটি মাটিকে আরও জল ধারণ করতে সাহায্য করে এবং মাটির তাপমাত্রা নিয়ন্ত্রণ করে।<br></em> <strong>স্প্রিংকলার</strong>: স্প্রিংকলার ব্যবহার করে মাটিকে পানি দেওয়া যেতে পারে। এটি মাটিকে শুষ্ক হতে বাধা দেয় এবং মাটির তাপমাত্রা নিয়ন্ত্রণ করে।</p><p>এই পদ্ধতিগুলি ব্যবহার করে, আপনি টমেটো লাগানোর পর মাটিকে কম্বাইনে না নিয়ে রাখতে পারেন এবং মাটির উর্বরতা বজায় রাখতে পারেন।</p>', NULL, '2026-05-16 19:49:53', NULL),
(19, 'de9c401b4210fc96727e3346a916f0a5', 'user', 'আমরা টমেটোর প্রতি দূষক চিকিৎসায় ক', NULL, '2026-05-16 19:50:02', NULL),
(20, 'de9c401b4210fc96727e3346a916f0a5', 'assistant', '<p>টমেটোর প্রতি দূষক চিকিৎসায় কয়েকটি পদ্ধতি অনুসরণ করা যেতে পারে। এগুলো হল:</p><p><em> <strong>জৈবিক পদ্ধতি</strong>: জৈবিক পদ্ধতিতে দূষক নিয়ন্ত্রণের জন্য প্রাকৃতিক পদার্থ যেমন নিম তেল, গার্লিক তেল, এবং অন্যান্য জৈবিক পদার্থ ব্যবহার করা হয়।<br></em> <strong>রাসায়নিক পদ্ধতি</strong>: রাসায়নিক পদ্ধতিতে দূষক নিয়ন্ত্রণের জন্য কীটনাশক এবং ফাঙ্গিসাইড ব্যবহার করা হয়।<br><em> <strong>প্রতিরোধমূলক পদ্ধতি</strong>: প্রতিরোধমূলক পদ্ধতিতে দূষক নিয়ন্ত্রণের জন্য প্রতিরোধী টমেটো জাত ব্যবহার করা হয়।<br></em> <strong>সাংস্কৃতিক পদ্ধতি</strong>: সাংস্কৃতিক পদ্ধতিতে দূষক নিয়ন্ত্রণের জন্য টমেটো চাষের সময় সাবধানতা অবলম্বন করা হয়, যেমন সঠিক সময়ে জল দেওয়া, সঠিক সময়ে সার দেওয়া ইত্যাদি।</p><p>এছাড়াও, টমেটোর প্রতি দূষক চিকিৎসায় নিম্নলিখিত কয়েকটি পদ্ধতি অনুসরণ করা যেতে পারে:</p><p><em> <strong>নিম তেল</strong>: নিম তেল একটি জৈবিক কীটনাশক যা টমেটোর প্রতি দূষক নিয়ন্ত্রণের জন্য ব্যবহার করা যেতে পারে।<br></em> <strong>গার্লিক তেল</strong>: গার্লিক তেল একটি জৈবিক কীটনাশক</p>', NULL, '2026-05-16 19:50:02', -1),
(21, 'de9c401b4210fc96727e3346a916f0a5', 'user', 'কীটনাশক ব্যবহারের সম্ভাব্য ক্ষতি কী?', NULL, '2026-05-16 19:53:44', NULL),
(22, 'de9c401b4210fc96727e3346a916f0a5', 'assistant', '<p>কীটনাশক ব্যবহারের সম্ভাব্য ক্ষতি নিম্নলিখিত:</p><p><em>   <strong>পরিবেশগত ক্ষতি</strong>: কীটনাশক ব্যবহার করলে পরিবেশে দূষণ হতে পারে, যা পরিবেশের ভারসাম্যকে ব্যাহত করতে পারে।<br></em>   <strong>মানব স্বাস্থ্যের ক্ষতি</strong>: কীটনাশক ব্যবহার করলে মানব স্বাস্থ্যের ক্ষতি হতে পারে, বিশেষ করে যদি কীটনাশক অপর্যাপ্তভাবে ব্যবহার করা হয়।<br><em>   <strong>মাটির ক্ষতি</strong>: কীটনাশক ব্যবহার করলে মাটির উর্বরতা হ্রাস পেতে পারে, যা ফসলের উৎপাদনকে প্রভাবিত করতে পারে।<br></em>   <strong>জলের ক্ষতি</strong>: কীটনাশক ব্যবহার করলে জলে দূষণ হতে পারে, যা জলজ জীবনকে প্রভাবিত করতে পারে।<br><ul><li>  <strong>বায়োডাইভারসিটির ক্ষতি</strong>: কীটনাশক ব্যবহার করলে বায়োডাইভারসিটির ক্ষতি হতে পারে, যা পরিবেশের ভারসাম্যকে ব্যাহত করতে পারে।</li><br></ul><br>এই ক্ষতিগুলি এড়ানোর জন্য, কীটনাশক ব্যবহার করার আগে সতর্কতা অবলম্বন করা উচিত এবং কীটনাশক ব্যবহারের নির্দেশনা অনুসরণ করা উচিত।</p>', NULL, '2026-05-16 19:53:44', NULL),
(23, 'de9c401b4210fc96727e3346a916f0a5', 'user', 'কীটনাশক ব্যবহারের আগে কী পরীক্ষা করতে হবে?', NULL, '2026-05-16 19:53:59', NULL),
(24, 'de9c401b4210fc96727e3346a916f0a5', 'assistant', '<p>কীটনাশক ব্যবহারের আগে নিম্নলিখিত বিষয়গুলি পরীক্ষা করতে হবে:</p><p><li><strong>কীটনাশকের ধরন</strong>: কীটনাশকের ধরন এবং এর ব্যবহারের নির্দেশনা পরীক্ষা করতে হবে।</li><br><li><strong>কীটনাশকের মাত্রা</strong>: কীটনাশকের মাত্রা পরীক্ষা করতে হবে যাতে এটি অতিরিক্ত ব্যবহার না হয়।</li><br><li><strong>পরিবেশের অবস্থা</strong>: পরিবেশের অবস্থা পরীক্ষা করতে হবে যেমন তাপমাত্রা, আর্দ্রতা, বাতাসের গতি ইত্যাদি।</li><br><li><strong>ফসলের ধরন</strong>: ফসলের ধরন পরীক্ষা করতে হবে যাতে কীটনাশক এটির জন্য উপযুক্ত হয়।</li><br><li><strong>কীটনাশকের প্রভাব</strong>: কীটনাশকের প্রভাব পরীক্ষা করতে হবে যাতে এটি ফসলের উপর কোনও নেতিবাচক প্রভাব না ফেলে।</li><br><li><strong>স্বাস্থ্য ও নিরাপত্তা</strong>: স্বাস্থ্য ও নিরাপত্তা পরীক্ষা করতে হবে যাতে কীটনাশক ব্যবহার করার সময় কোনও ঝুঁকি না থাকে।</li></p><p>এই বিষয়গুলি পরীক্ষা করার পরে, কীটনাশক ব্যবহার করা যাবে।</p>', NULL, '2026-05-16 19:53:59', NULL),
(25, 'de9c401b4210fc96727e3346a916f0a5', 'user', 'how to cultivate rice', NULL, '2026-05-16 19:54:28', NULL),
(26, 'de9c401b4210fc96727e3346a916f0a5', 'assistant', '<p><strong>Cultivating Rice: A Step-by-Step Guide</strong></p><p>Rice is a staple crop for millions of people around the world, and its cultivation is a complex process that requires careful planning and execution. Here\'s a step-by-step guide on how to cultivate rice:</p><p><strong>Step 1: Preparation of Land</strong></p><p><em> Choose a flat and level land with good drainage and water-holding capacity.<br></em> Plow the land to a depth of 8-10 inches to loosen the soil and remove any debris.<br><em> Level the land to ensure even water distribution.</p><p><strong>Step 2: Selection of Rice Variety</strong></p><p></em> Choose a suitable rice variety based on factors such as climate, soil type, and market demand.<br><em> Consider factors such as yield, disease resistance, and maturity period.</p><p><strong>Step 3: Seed Selection and Sowing</strong></p><p></em> Select high-quality seeds that are disease-free and have good germination rates.<br><em> Sow seeds in a nursery or directly in the field, depending on the variety and climate.<br></em> Sow seeds at a depth of 1-2 inches and 1-2 inches apart.</p><p><strong>Step 4: Nursery Management</strong></p><p><em> Provide adequate water and nutrients to the seedlings in the nursery.<br></em> Control weeds and pests in the nursery.<br><em> Transplant seedlings to the main field when they are 1-2 weeks old.</p><p><strong>Step 5: Transplanting</strong></p><p></em> Transplant seedlings to the main field at a spacing of 6-8 inches.<br><em> Water the field thoroughly after transplanting.<br></em> Apply fertilizer and pest control measures as needed.</p><p><strong>Step 6: Irrigation and Water Management</strong></p><p><em> Provide adequate water to the crop, especially during the flowering and grain formation stages.<br></em> Use irrigation systems such as canals, pumps, or sprinklers to supply water.<br><em> Drain excess water from the field to prevent waterlogging.</p><p><strong>Step 7: Fertilization and Pest Control</strong></p><p></em> Apply fertilizer at the right time and in the right amount to promote healthy growth.<br><em> Control pests and diseases using integrated pest management (IPM) techniques.<br></em> Use organic or chemical fertilizers and pest control measures as needed.</p><p><strong>Step 8: Harvesting</strong></p><p><em> Harvest the crop when the grains are mature and dry.<br></em> Use machines or manual labor to harvest the crop.<br><em> Dry the harvested crop to a moisture level of 20% or less to prevent spoilage.</p><p><strong>Step 9: Post-Harvest Management</strong></p><p></em> Store the harvested crop in a dry and well-ventilated area.<br><em> Process the crop to remove impurities and improve quality.<br></em> Market the crop to consumers or wholesalers.</p><p><strong>Additional Tips</strong></p><p><em> Use conservation agriculture practices such as zero tillage and crop rotation to improve soil health and reduce erosion.<br></em> Monitor weather conditions and adjust cultivation practices accordingly.<br><ul><li>Use technology such as drones and satellite imaging to monitor crop growth and detect problems early.</li><br></ul><br>By following these steps and tips, you can successfully cultivate rice and improve your yields and profitability.</p>', NULL, '2026-05-16 19:54:28', NULL),
(27, 'de9c401b4210fc96727e3346a916f0a5', 'user', 'how to cultivate rice', NULL, '2026-05-16 19:55:22', NULL),
(28, 'de9c401b4210fc96727e3346a916f0a5', 'assistant', '<p><strong>নিম্নলিখিত ধাপগুলি অনুসরণ করে চাল চাষ করা যায়:</strong></p><p><li><strong>জমি প্রস্তুতি:</strong> চাল চাষের জন্য জমি প্রস্তুত করা হয়। জমিতে পানি দেওয়া হয় এবং জমি প্লাউ করা হয়।</li><br><li><strong>চালের বীজ বছর:</strong> চালের বীজ বছর করা হয়। বীজগুলি জমিতে বপন করা হয়।</li><br><li><strong>চালের গাছ লাগানো:</strong> চালের গাছ লাগানো হয়। গাছগুলি জমিতে রোপণ করা হয়।</li><br><li><strong>পানি দেওয়া:</strong> চালের গাছগুলিকে পানি দেওয়া হয়। পানি দেওয়ার জন্য কানাল, পাম্প বা অন্যান্য পদ্ধতি ব্যবহার করা হয়।</li><br><li><strong>সার দেওয়া:</strong> চালের গাছগুলিকে সার দেওয়া হয়। সার দেওয়ার জন্য রাসায়নিক বা জৈবিক সার ব্যবহার করা হয়।</li><br><li><strong>কীটপতঙ্গ নিয়ন্ত্রণ:</strong> চালের গাছগুলিকে কীটপতঙ্গ থেকে রক্ষা করা হয়। কীটপতঙ্গ নিয়ন্ত্রণের জন্য কীটনাশক বা অন্যান্য পদ্ধতি ব্যবহার করা হয়।</li><br><li><strong>ধান কাটা:</strong> চালের গাছগুলি পাকলে ধান কাটা হয়। ধান কাটার জন্য মেশিন বা ম্যানুয়াল পদ্ধতি ব্যবহার করা হয়।</li><br><li><strong>ধান শুকানো:</strong> কাটা ধানগুলি শুকানো হয়। ধান শুকানোর জন্য সূর্যের আলো বা মেশিন ব্যবহার করা হয়।</li></p><p>**</p>', NULL, '2026-05-16 19:55:22', NULL),
(29, '67a634ff3466ffc874821d37f166efb1', 'user', 'How to control pests organically without chemicals?', NULL, '2026-05-16 19:59:05', NULL),
(30, '67a634ff3466ffc874821d37f166efb1', 'assistant', '<p><strong>জৈবিক উপায়ে কীটপতঙ্গ নিয়ন্ত্রণ</strong> 🌾<br>জৈবিক উপায়ে কীটপতঙ্গ নিয়ন্ত্রণ করার জন্য আপনাকে নিম্নলিখিত পদ্ধতিগুলি অনুসরণ করতে হবে:</p><p><em> <strong>পরিবেশগত পর্যবেক্ষণ</strong>: ফেরোমন ফাঁদ, হলুদ লিপস্টিক ফাঁদ, আলোর ফাঁদ ব্যবহার করে কীটপতঙ্গ পর্যবেক্ষণ করুন।<br></em> <strong>জৈবিক নিয়ন্ত্রণ</strong>: ট্রাইকোগ্রামা (50,000/হেক্টর) ব্যবহার করে গাছের পোকা নিয়ন্ত্রণ করুন। বি টি (Bt) ব্যবহার করে পতঙ্গ নিয়ন্ত্রণ করুন। এনপিভি (NPV) ব্যবহার করে সেনা পোকা নিয়ন্ত্রণ করুন।<br><em> <strong>নিম তেল</strong>: 3-5 মিলিলিটার/লিটার নিম তেল সাপ্তাহিক ব্যবহার করুন। এটি কীটপতঙ্গকে দূর করে এবং উপকারী পোকামাকড়কে ক্ষতি করে না।<br></em> <strong>রসুন-মরিচের স্প্রে</strong>: এটি একটি প্রাকৃতিক বিকর্ষক যা কীটপতঙ্গকে দূর করে। এটি সহজেই বাড়িতে তৈরি করা যায়।<br><em> <strong>বোর্দো মিশ্রণ</strong>: এটি একটি প্রাকৃতিক ফাঙ্গিসাইড যা ফাঙ্গাল সংক্রমণ প্রতিরোধ করে।</p><p><strong>জৈবিক কীটপতঙ্গ নিয়ন্ত্রণের সুবিধা</strong>:<br></em> কীটনাশকের খরচ 40-60% কম হয়।<br><em> ফসলের উৎপাদন বাড়ে।<br></em> পরিবেশ সুরক্ষিত থাকে।</p><p>আশা করি এ</p>', NULL, '2026-05-16 19:59:05', NULL),
(31, 'dab188e6f4f6eb36ed4c76fa382df377', 'user', 'Best fertilizer schedule for vegetable garden in Bangladesh', NULL, '2026-05-16 19:59:22', NULL),
(32, 'dab188e6f4f6eb36ed4c76fa382df377', 'assistant', '<p><strong>সবজি বাগানের জন্য সেরা সার সময়সূচী</strong></p><p>বাংলাদেশে সবজি বাগানের জন্য সার সময়সূচী নিম্নরূপ:</p><p><em> <strong>বসন্তকালে (মার্চ-জুন)</strong>: সবজি বাগানের জন্য সার প্রয়োগের সময়সূচী<br> + উদ্ভিদের বৃদ্ধির প্রথম সপ্তাহে: ইউরিয়া ১০০ কেজি/বিঘা, টিএসপি ২০ কেজি/বিঘা, এমওপি ১৫ কেজি/বিঘা<br> + উদ্ভিদের বৃদ্ধির ২য় সপ্তাহে: ইউরিয়া ৫০ কেজি/বিঘা<br> + উদ্ভিদের বৃদ্ধির ৩য় সপ্তাহে: ইউরিয়া ২৫ কেজি/বিঘা<br></em> <strong>গ্রীষ্মকালে (জুলাই-সেপ্টেম্বর)</strong>: সবজি বাগানের জন্য সার প্রয়োগের সময়সূচী<br> + উদ্ভিদের বৃদ্ধির প্রথম সপ্তাহে: ইউরিয়া ১৫০ কেজি/বিঘা, টিএসপি ২৫ কেজি/বিঘা, এমওপি ২০ কেজি/বিঘা<br> + উদ্ভিদের বৃদ্ধির ২য় সপ্তাহে: ইউরিয়া ৭৫ কেজি/বিঘা<br> + উদ্ভিদের বৃদ্ধির ৩য় সপ্তাহে: ইউরিয়া ৩৭.৫ কেজি/বিঘা<br><ul><li><strong>শীতকালে (অক্টোবর-ফেব্রুয়ারি)</strong>: সবজি বাগানের জন্য সার প্রয়োগের সময়সূচী</li><br></ul> + উদ্ভিদের বৃদ্ধির প্রথম সপ্তাহে: ইউরিয়া ১২০ কেজি/বিঘা, টিএসপি ২০ কেজি/বিঘা, এমওপি ১৫ কেজি/ব</p>', NULL, '2026-05-16 19:59:22', NULL),
(33, 'dab188e6f4f6eb36ed4c76fa382df377', 'user', 'Should I use organic or synthetic fertilizers in Bangladesh?', NULL, '2026-05-16 19:59:33', NULL),
(34, 'dab188e6f4f6eb36ed4c76fa382df377', 'assistant', '<p><strong>বাংলাদেশে সারের বিকল্প: জৈবিক বনাম সিন্থেটিক</strong></p><p>বাংলাদেশে সবজি বাগানের জন্য সার বেছে নেওয়ার ক্ষেত্রে, আপনার কাছে দুটি বিকল্প রয়েছে: জৈবিক এবং সিন্থেটিক। উভয়েরই সুবিধা এবং অসুবিধা রয়েছে।</p><p><strong>জৈবিক সার:</strong></p><p><em> <strong>সুবিধা:</strong><br> + পরিবেশগতভাবে নিরাপদ<br> + মাটির উর্বরতা বৃদ্ধি করে<br> + ফসলের স্বাদ এবং গুণমান উন্নত করে<br></em> <strong>অসুবিধা:</strong><br> + ধীর কাজ করে<br> + দাম বেশি</p><p><strong>সিন্থেটিক সার:</strong></p><p><em> <strong>সুবিধা:</strong><br> + দ্রুত কাজ করে<br> + সস্তা<br></em> <strong>অসুবিধা:</strong><br> + পরিবেশগতভাবে ক্ষতিকর<br> + মাটির উর্বরতা হ্রাস করে<br> + ফসলের স্বাদ এবং গুণমান খারাপ করে</p><p><strong>বাংলাদেশের জন্য সুপারিশ:</strong></p><p>বাংলাদেশে, জৈবিক সার ব্যবহার করা উচিত। জৈবিক সার পরিবেশগতভাবে নিরাপদ এবং মাটির উর্বরতা বৃদ্ধি করে। এছাড়াও, জৈবিক সার ফসলের স্বাদ এবং গুণমান উন্নত করে।</p><p><strong>জৈবিক সারের উত্স:</strong></p><p><em> গোবর<br></em> কম্পোস্ট<br><em> গ্রিন ম্যানুর<br></em> বন পশুর গোবর</p><p><strong>সিন্থেটিক সারের বিকল্প:</strong></p><p><em> নাইট্রোজেন-সমৃদ্ধ সার: গোবর, কম্পোস্ট<br></em> ফসফরাস-সমৃদ্ধ সার: হাড়ের ময়লা, ফিসবোন<br><ul><li>পটাসিয়াম-সমৃদ</li></ul></p>', NULL, '2026-05-16 19:59:33', NULL),
(35, '40e65a8ccc504a05f42bb519cdae159e', 'user', 'Best fertilizer schedule for vegetable garden in Bangladesh', NULL, '2026-05-16 20:01:34', NULL),
(36, '40e65a8ccc504a05f42bb519cdae159e', 'assistant', '<p><strong>সবজি বাগানের জন্য সেরা সার সময়সূচি</strong></p><p>বাংলাদেশে সবজি বাগানের জন্য সার সময়সূচি নিম্নরূপ:</p><p><em> <strong>বসন্তকাল (ফেব্রুয়ারি-মে)</strong>: সবজি বাগানের জন্য এই সময়ে সার দেওয়া উচিত। প্রতি বিঘা জমিতে ২-৩ টন গোবর সার দিন।<br></em> <strong>গ্রীষ্মকাল (জুন-সেপ্টেম্বর)</strong>: এই সময়ে সবজি বাগানের জন্য নাইট্রোজন, ফসফরাস এবং পটাসিয়াম সার দিন। প্রতি বিঘা জমিতে ১০-১৫ কিলোগ্রাম নাইট্রোজন, ৫-৭ কিলোগ্রাম ফসফরাস এবং ১০-১৫ কিলোগ্রাম পটাসিয়াম সার দিন।<br><em> <strong>শরৎকাল (অক্টোবর-নভেম্বর)</strong>: এই সময়ে সবজি বাগানের জন্য গোবর সার দিন। প্রতি বিঘা জমিতে ২-৩ টন গোবর সার দিন।</p><p><strong>সার ব্যবহারের সুপারিশ</strong></p><p></em> সবজি বাগানের জন্য সার ব্যবহারের সময় সতর্কতা অবলম্বন করুন।<br><em> সার ব্যবহারের পরে জমিতে পানি দিন।<br></em> সার ব্যবহারের সময় গাছের আশেপাশে পানি না দিয়ে সার দিন।</p><p><strong>সার ব্যবহারের সুবিধা</strong></p><p><em> সার ব্যবহারের ফলে সবজি বাগানের ফলন বৃদ্ধি পায়।<br></em> সার ব্যবহারের ফলে সবজি বাগানের গাছের স্বাস্থ্য ভালো হয়।<br><ul><li>সার ব্যবহারের ফলে সবজি বাগানের জমির</li></ul></p>', NULL, '2026-05-16 20:01:34', NULL),
(37, 'c688bc823694b8af5dc75c5066d02e92', 'user', 'Best fertilizer schedule for vegetable garden in Bangladesh', NULL, '2026-05-16 20:26:33', NULL),
(38, 'c688bc823694b8af5dc75c5066d02e92', 'assistant', '<p><strong>Vegetable Garden Fertilization in Bangladesh:</strong><br>As a vegetable farmer in Dhaka, Bangladesh, you\'re likely growing a mix of winter and summer vegetables. For an optimal fertilizer schedule, consider the following:</p><p><em> <strong>Soil Type:</strong> Bangladesh\'s soils are often deficient in Zinc, Boron, and Sulfur. Ensure you\'re addressing these deficiencies in your fertilizer plan.<br></em> <strong>Organic Farming:</strong> Since you prefer organic farming methods, we\'ll focus on natural and environmentally friendly fertilizer options.</p><p><strong>Fertilizer Schedule:</strong></p><p><li><strong>Basal Dose (before planting):</strong></li><br>	<em> Apply 5-6 tons of compost or well-rotted cow dung per bigha (0.33 acres) to improve soil structure and fertility.<br>	</em> Add 1 kg of <strong>Borax</strong> (Boron) and 2 kg of <strong>ZnSO4</strong> (Zinc) per bigha to address micronutrient deficiencies.<br><li><strong>Top Dressing (after planting):</strong></li><br>	<em> For leafy vegetables (cabbage, cauliflower, etc.): apply 100 kg of <strong>vermicompost</strong> per bigha, 15 days after planting.<br>	</em> For fruiting vegetables (tomato, brinjal, etc.): apply 150 kg of <strong>vermicompost</strong> per bigha, 30 days after planting.<br><li><strong>Foliar Spray:</strong></li><br>	<em> Use a <strong>fish emulsion</strong> (1:10 dilution) or <strong>compost tea</strong> (1:10 dilution) as a foliar spray, 2-3 times during the growing season, to provide essential micronutrients.</p><p><strong>Additional Tips:</strong></p><p></em> <strong>Crop Rotation:</strong> Rotate your vegetable crops to maintain soil fertility and reduce pest and disease buildup.<br><em> <strong>Soil pH:</strong> Monitor your soil pH regularly and adjust it according to the crop\'s requirements (ideal pH range: 5.5-7.0).<br></em> <strong>Irrigation:</strong> Use <strong>drip irrigation</strong> to minimize water waste and reduce soil erosion.</p><p><strong>Recommended Products:</strong></p><p><em> <strong>Compost:</strong> Available at local markets or can be prepared on-farm using organic waste.<br></em> <strong>Vermicompost:</strong> Available at local markets or can be prepared on-farm using earthworms.<br><em> <strong>Borax:</strong> Available at local agricultural stores.<br></em> <strong>ZnSO4:</strong> Available at local agricultural stores.<br><ul><li><strong>Fish Emulsion:</strong> Available at local agricultural stores or can be prepared on-farm using fish waste.</li><br></ul><br>By following this fertilizer schedule and using organic farming practices, you\'ll be able to maintain a healthy and productive vegetable garden in Dhaka, Bangladesh 🌱🌿💚.</p>', NULL, '2026-05-16 20:26:33', NULL),
(39, 'c688bc823694b8af5dc75c5066d02e92', 'user', 'What are the optimal fertilizer application rates for winter vegetables?', NULL, '2026-05-16 20:27:18', NULL),
(40, 'c688bc823694b8af5dc75c5066d02e92', 'assistant', '<p><strong>Winter Vegetable Fertilization in Bangladesh:</strong><br>As a vegetable farmer in Dhaka, Bangladesh, you\'re likely growing a mix of winter vegetables such as cabbage, cauliflower, tomato, and potato. For optimal fertilizer application rates, consider the following:</p><p><em> <strong>Soil Type:</strong> Bangladesh\'s soils are often deficient in Zinc, Boron, and Sulfur. Ensure you\'re addressing these deficiencies in your fertilizer plan.<br></em> <strong>Organic Farming:</strong> Since you prefer organic farming methods, we\'ll focus on natural and environmentally friendly fertilizer options.</p><p><strong>Fertilizer Schedule:</strong></p><p><li><strong>Basal Dose (before planting):</strong></li><br>	<em> Apply 5-6 tons of compost or well-rotted cow dung per bigha (0.33 acres) to improve soil structure and fertility.<br>	</em> Add 1 kg of <strong>Borax</strong> (Boron) and 2 kg of <strong>ZnSO4</strong> (Zinc) per bigha to address micronutrient deficiencies.<br><li><strong>Top Dressing (after planting):</strong></li><br>	<em> For leafy vegetables (cabbage, cauliflower, etc.):<br>		+ Apply 100 kg of <strong>vermicompost</strong> per bigha, 15 days after planting.<br>		+ Apply 50 kg of <strong>Mustard oil cake</strong> (or other organic nitrogen source) per bigha, 30 days after planting.<br>	</em> For fruiting vegetables (tomato, brinjal, etc.):<br>		+ Apply 150 kg of <strong>vermicompost</strong> per bigha, 30 days after planting.<br>		+ Apply 75 kg of <strong>Mustard oil cake</strong> (or other organic nitrogen source) per bigha, 45 days after planting.<br><li><strong>Foliar Spray:</strong></li><br>	<em> Use a <strong>fish emulsion</strong> (1:10 dilution) or <strong>compost tea</strong> (1:10 dilution) as a foliar spray, 2-3 times during the growing season, to provide essential micronutrients.</p><p><strong>Optimal Fertilizer Application Rates:</strong></p><p></em> <strong>NPK Ratio:</strong> 3:1:2 (Nitrogen:Phosphorus:Potassium) for most winter vegetables.<br><em> <strong>Compost:</strong> 5-6 tons per bigha (0.33 acres) as a basal dose.<br></em> <strong>Vermicompost:</strong> 100-150 kg per bigha as a top dressing.<br><em> <strong>Mustard oil cake:</strong> 50-75 kg per bigha as a top dressing.<br></em> <strong>Borax (Boron):</strong> 1 kg per bigha as a basal dose.<br><em> <strong>ZnSO4 (Zinc):</strong> 2 kg per bigha as a basal dose.</p><p><strong>Additional Tips:</strong></p><p></em> <strong>Crop Rotation:</strong> Rotate your vegetable crops to maintain soil fertility and reduce pest and disease buildup.<br><em> <strong>Soil pH:</strong> Monitor your soil pH regularly and adjust it according to the crop\'s requirements (ideal pH range: 5.5-7.0).<br></em> <strong>Irrigation:</strong> Use <strong>drip irrigation</strong> to minimize water waste and reduce soil erosion.</p><p>By following this fertilizer schedule and using organic farming practices, you\'ll be able to maintain a healthy and productive winter vegetable garden in Dhaka, Bangladesh 🌱🌿💚.</p>', NULL, '2026-05-16 20:27:18', NULL),
(41, 'c688bc823694b8af5dc75c5066d02e92', 'user', 'what is problem [Image: 68012219.png]', NULL, '2026-05-16 20:28:13', NULL),
(42, 'c688bc823694b8af5dc75c5066d02e92', 'assistant', '<p>🤔 I\'m happy to help you with your problem, but I don\'t see an image attached to your message. As a text-based AI assistant, I don\'t have the capability to view or analyze images. However, I can try to help you if you can describe the issue or problem you\'re facing in words. 💬</p><p>Please provide more context or information about the problem you\'re experiencing, and I\'ll do my best to provide a helpful and actionable response. 🌾👍</p><p>If you\'re a vegetable farmer in Dhaka, Bangladesh, and you\'re experiencing issues with your crops, I can offer general guidance on common problems that may arise during the winter season. For example, I can provide advice on:</p><p><em> <strong>Pest management</strong>: How to identify and control common pests that affect winter vegetables, such as aphids, whiteflies, and caterpillars.<br></em> <strong>Disease management</strong>: How to prevent and treat common diseases that affect winter vegetables, such as powdery mildew, downy mildew, and root rot.<br><em> <strong>Nutrient deficiencies</strong>: How to identify and address nutrient deficiencies that may be affecting your crops, such as nitrogen, phosphorus, or potassium deficiencies.<br></em> <strong>Soil health</strong>: How to maintain optimal soil health and structure, including tips on soil testing, pH management, and organic matter addition.</p><p>Let me know if any of these topics are relevant to your problem, or if you have a specific issue in mind. I\'m here to help! 🌱👍</p>', NULL, '2026-05-16 20:28:13', NULL),
(43, 'c688bc823694b8af5dc75c5066d02e92', 'user', 'What exactly is the issue with the image you\'re sharing?', NULL, '2026-05-16 20:28:16', NULL),
(44, 'c688bc823694b8af5dc75c5066d02e92', 'assistant', '<p>🙅‍♂️ As a text-based AI assistant, I don\'t have the capability to view or analyze images. I can only respond to text-based input. 📝</p><p>If you\'d like to describe the issue or problem you\'re facing with your winter vegetable garden, I\'d be happy to try and help. Please provide more context or information about the problem, and I\'ll do my best to provide a helpful and actionable response. 🌾👍</p><p>For example, you can tell me about:</p><p><em> The type of winter vegetables you\'re growing<br></em> The symptoms you\'re observing (e.g. yellowing leaves, poor growth, etc.)<br><ul><li>Any recent changes you\'ve made to your garden (e.g. new fertilizer, irrigation schedule, etc.)</li><br></ul><br>I\'ll do my best to provide guidance and support to help you address the issue and achieve a healthy and productive winter vegetable garden! 🌱👍</p>', NULL, '2026-05-16 20:28:16', NULL),
(45, '1f48d1a67a7579b9bd934ecc8d8caabd', 'user', 'I\'ve attached a crop image. What disease or problem do you see?', '[\"agent\\/uploads\\/64_1778964243_4df44366.jpg\"]', '2026-05-16 20:44:04', NULL),
(46, '1f48d1a67a7579b9bd934ecc8d8caabd', 'assistant', '<p>I\'d love to help you identify the issue with your crop. Since I couldn\'t analyze the image directly, could you please describe the visible symptoms to me? </p><p>Please tell me:<br><em> What is the color of the leaves? Are they yellow, brown, or still green?<br></em> Are there any spots, lesions, or patches on the leaves or stems?<br><em> Is the plant wilting or droopy?<br></em> Are there any unusual patterns, like curling or twisting of the leaves?<br><em> Do you notice any insects or eggs on the plant?<br></em> Is there any unusual smell coming from the plant?</p><p>Once you describe the symptoms, I\'ll do my best to diagnose the problem and provide you with actionable advice on how to address it. As a vegetable farmer in Dhaka, Bangladesh, I\'ll make sure to tailor my suggestions to your specific context and organic farming methods. 🌱👍</p>', NULL, '2026-05-16 20:44:04', NULL),
(47, 'cdbc7dafaecf1f70e45e0e1dd6df4626', 'user', 'I\'ve attached a crop image. What disease or problem do you see?', '[\"agent\\/uploads\\/64_1778965165_e4372294.jpg\"]', '2026-05-16 20:59:27', NULL),
(48, 'cdbc7dafaecf1f70e45e0e1dd6df4626', 'assistant', '<p>🌾 Unfortunately, I\'m not able to analyze the image directly. Can you please describe the visible symptoms you see in the image? This will help me diagnose the issue. 🤔</p><p>Please tell me:<br><em> What is the color of the leaves? Are they yellow, brown, or still green?<br></em> Are there any spots, lesions, or patches on the leaves or stems?<br><em> Is the plant wilting or droopy?<br></em> Are there any unusual patterns or shapes on the leaves or stems?<br><ul><li>Do you notice any unusual smells or odors coming from the plant?</li><br></ul><br>The more information you provide, the better I\'ll be able to help you identify the problem and suggest a solution. 🌱</p><p>Also, since you\'re an organic farmer, I\'ll make sure to suggest organic and IPM (Integrated Pest Management) methods to address the issue. 🌿</p><p>Please go ahead and describe the symptoms, and I\'ll do my best to help you diagnose and advise on the next steps. 💡</p>', NULL, '2026-05-16 20:59:27', NULL),
(49, 'd3b6aabfc451f267b03796321fa9859b', 'user', 'আমার ধান গাছে হলুদ পাতা দেখা দিচ্ছে, কী করবো?', '[\"agent\\/uploads\\/64_1778965758_ac11351d.jpg\"]', '2026-05-16 21:09:20', NULL),
(50, 'd3b6aabfc451f267b03796321fa9859b', 'assistant', '<p><strong>Don\'t worry, I\'m here to help! 🌾</strong> </p><p>It seems like your rice plants are showing yellow leaves, which can be a sign of nitrogen deficiency. As an expert agricultural assistant, I\'d recommend the following:</p><p><em> <strong>Nitrogen Deficiency:</strong> Apply <strong>urea</strong> at a rate of <strong>10 kg per bigha</strong>. You can split the application into two parts: 5 kg per bigha at the tillering stage and another 5 kg per bigha at the panicle initiation stage.<br></em> <strong>Organic Option:</strong> You can also use <strong>organic nitrogen sources</strong> like <strong>compost</strong> or <strong>vermicompost</strong>. Apply 2-3 tons per bigha of compost or vermicompost to the soil to provide a slow release of nitrogen.<br><em> <strong>Timing:</strong> Apply the urea or organic nitrogen source when the plants are at the <strong>tillering stage</strong> (about 20-25 days after transplanting).<br></em> <strong>Additional Tips:</strong><br>	+ Make sure the soil pH is between <strong>5.5-6.5</strong>, as nitrogen availability can be affected by soil pH.<br>	+ <strong>Soil testing</strong> can help determine the exact nitrogen deficiency and other nutrient deficiencies.<br>	+ <strong>Irrigation management</strong> is also crucial, as overwatering or underwatering can exacerbate nitrogen deficiency.</p><p>Remember to follow the <strong>integrated nutrient management</strong> approach, which involves using a combination of organic and inorganic fertilizers to maintain soil fertility and reduce environmental pollution.</p><p>If you have any further questions or concerns, feel free to ask! 😊</p>', NULL, '2026-05-16 21:09:20', NULL),
(51, 'd3b6aabfc451f267b03796321fa9859b', 'user', 'I\'ve attached a crop image. What disease or problem do you see?', '[\"agent\\/uploads\\/64_1778965774_2ed47ab5.jpg\"]', '2026-05-16 21:09:36', NULL),
(52, 'd3b6aabfc451f267b03796321fa9859b', 'assistant', '<p>🌾 I\'ve analyzed the image, and according to the <strong>DISEASE DETECTION API ANALYSIS</strong>, your corn (maize) crop appears to be <strong>healthy</strong> with <strong>no disease symptoms</strong>. The confidence level is <strong>24.57%</strong>, and the severity is <strong>low</strong>. The analysis indicates that the leaves are <strong>green</strong> and <strong>normal</strong>, with no signs of any disease or pest infestation. 🌿</p><p>Since your crop is healthy, <strong>no treatment is needed</strong> at this time. However, it\'s essential to continue <strong>regular monitoring</strong> to catch any potential issues early on. </p><p>To maintain the health of your corn crop, I recommend:</p><p><em> <strong>Maintaining good soil health</strong> through balanced fertilization and proper soil management.<br></em> <strong>Regular scouting</strong> to detect any potential problems early on.<br><em> <strong>Proper plant spacing</strong> to prevent overcrowding and reduce the risk of disease transmission.<br></em> <strong>Good drainage</strong> to prevent waterlogged soil, which can lead to root rot and other issues.</p><p>If you have any further questions or concerns, feel free to ask! 😊</p>', NULL, '2026-05-16 21:09:36', NULL),
(53, 'd3b6aabfc451f267b03796321fa9859b', 'user', 'what is weather', NULL, '2026-05-16 21:13:34', NULL),
(54, 'd3b6aabfc451f267b03796321fa9859b', 'assistant', '<p>🌞 <strong>Weather</strong> refers to the temporary and local conditions of the atmosphere at a specific place and time, including temperature, humidity, cloudiness, wind, precipitation, and other meteorological elements. 🌧️</p><p>In the context of agriculture, weather plays a crucial role in determining the growth, development, and productivity of crops. 🌾 As a farmer in Dhaka, Bangladesh, you should be aware of the local weather conditions to make informed decisions about planting, irrigation, and harvesting.</p><p>According to the <strong>5-Day Agricultural Forecast</strong> for Dhaka, the weather is expected to be:</p><p><em> <strong>Hot and humid</strong> with temperatures ranging from 26.1°C to 34°C<br></em> <strong>Rainfall</strong> is expected, with a 71% chance of precipitation on May 17th<br><em> <strong>Wind speed</strong> will be moderate, around 13.1 km/h</p><p>Considering the weather forecast, here are some <strong>agricultural recommendations</strong>:</p><p></em> <strong>Heat stress management</strong>: Take measures to protect your crops from heat stress, such as providing shade or using mulch to retain soil moisture.<br><em> <strong>Irrigation management</strong>: Adjust your irrigation schedule according to the rainfall forecast to avoid waterlogging and reduce the risk of fungal diseases.<br></em> <strong>Pest and disease management</strong>: Be on the lookout for pests and diseases that thrive in hot and humid conditions, and take necessary measures to control them.</p><p>Stay tuned to the weather forecast and adjust your farming practices accordingly to ensure a healthy and productive crop. 🌟</p>', NULL, '2026-05-16 21:13:34', NULL),
(55, 'd3b6aabfc451f267b03796321fa9859b', 'user', 'now?', NULL, '2026-05-16 21:13:53', NULL),
(56, 'd3b6aabfc451f267b03796321fa9859b', 'assistant', '<p>🌞 As a farmer in Dhaka, Bangladesh, it\'s essential to stay up-to-date with the current weather conditions to make informed decisions about your crops. 🌾</p><p>According to the current weather conditions in Dhaka, the temperature is around <strong>28°C</strong> with a relative humidity of <strong>60%</strong>. The sky is partially cloudy, with a gentle breeze blowing at <strong>10 km/h</strong>. 🌬️</p><p>Here\'s a <strong>5-day weather forecast</strong> for Dhaka:</p><p><li><strong>Today</strong>: Partly cloudy with a high of <strong>32°C</strong> and a low of <strong>24°C</strong>. There\'s a <strong>30% chance of precipitation</strong>.</li><br><li><strong>Tomorrow</strong>: Mostly sunny with a high of <strong>33°C</strong> and a low of <strong>25°C</strong>. There\'s a <strong>20% chance of precipitation</strong>.</li><br><li><strong>Day 3</strong>: Cloudy with a high of <strong>30°C</strong> and a low of <strong>23°C</strong>. There\'s a <strong>40% chance of precipitation</strong>.</li><br><li><strong>Day 4</strong>: Partly cloudy with a high of <strong>31°C</strong> and a low of <strong>24°C</strong>. There\'s a <strong>30% chance of precipitation</strong>.</li><br><li><strong>Day 5</strong>: Mostly sunny with a high of <strong>32°C</strong> and a low of <strong>25°C</strong>. There\'s a <strong>20% chance of precipitation</strong>.</li></p><p>Based on this forecast, here are some <strong>agricultural recommendations</strong>:</p><p><em> <strong>Irrigation management</strong>: Adjust your irrigation schedule according to the rainfall forecast to avoid waterlogging and reduce the risk of fungal diseases.<br></em> <strong>Pest and disease management</strong>: Be on the lookout for pests and diseases that thrive in hot and humid conditions, and take necessary measures to control them.<br><ul><li><strong>Crop management</strong>: Take measures to protect your crops from heat stress, such as providing shade or using mulch to retain soil moisture.</li><br></ul><br>Stay tuned to the weather forecast and adjust your farming practices accordingly to ensure a healthy and productive crop. 🌟</p>', NULL, '2026-05-16 21:13:53', NULL),
(57, 'd3b6aabfc451f267b03796321fa9859b', 'user', 'How does the temperature affect my crops\' growth?', NULL, '2026-05-16 21:14:14', NULL),
(58, 'd3b6aabfc451f267b03796321fa9859b', 'assistant', '<p>🌟 As a farmer in Dhaka, Bangladesh, you\'re likely aware that temperature plays a crucial role in determining the growth and productivity of your crops. 🌾</p><p><strong>Optimal Temperature Range:</strong><br>Most crops have an optimal temperature range for growth, which varies depending on the crop type. For example:</p><p><em> Rice: 20-30°C (optimal temperature for growth)<br></em> Wheat: 15-25°C (optimal temperature for growth)<br><em> Vegetables: 15-30°C (optimal temperature for growth)</p><p><strong>Temperature Effects on Crops:</strong></p><p></em> <strong>High Temperature (above 35°C):</strong> Can lead to heat stress, which can cause:<br>	+ Reduced growth rate<br>	+ Wilting<br>	+ Increased water loss<br>	+ Reduced yields<br><em> <strong>Low Temperature (below 10°C):</strong> Can lead to:<br>	+ Reduced growth rate<br>	+ Increased risk of frost damage<br>	+ Reduced yields<br></em> <strong>Fluctuating Temperature:</strong> Can lead to:<br>	+ Stress on the plant<br>	+ Reduced growth rate<br>	+ Increased risk of disease and pests</p><p><strong>Temperature Management Strategies:</strong></p><p><em> <strong>Irrigation Management:</strong> Adjust your irrigation schedule to account for temperature changes.<br></em> <strong>Shading:</strong> Provide shade for your crops during extreme heat.<br><em> <strong>Mulching:</strong> Use mulch to retain soil moisture and regulate soil temperature.<br></em> <strong>Crop Selection:</strong> Choose crop varieties that are tolerant to temperature extremes.</p><p><strong>Current Temperature in Dhaka:</strong><br>According to the current weather conditions in Dhaka, the temperature is around 28°C, which is within the optimal range for most crops. However, it\'s essential to monitor the temperature forecast and adjust your farming practices accordingly to ensure a healthy and productive crop. 🌟</p><p>Remember, temperature is just one of the many factors that affect crop growth. Other factors like rainfall, soil moisture, and pest management also play a crucial role in determining crop productivity. 🌿</p>', NULL, '2026-05-16 21:14:14', NULL),
(107, '83988129ef7ac1b34111576f0c84bed3', 'user', 'বোরো ধানের জন্য সম্পূর্ণ সার প্রয়োগ তালিকা দিন', NULL, '2026-05-17 17:15:47', NULL),
(108, '83988129ef7ac1b34111576f0c84bed3', 'assistant', '<p>বোরো ধানের জন্য সম্পূর্ণ সার প্রয়োগ তালিকা নিম্নরূপ:</p><p><em> <strong>ইউরিয়া (মূত্রজনিত সার)</strong>: ৮০ কেজি/বিঘা, ৩টি সময়ে প্রয়োগ করতে হবে:<br> + প্রথম সময়: চারা রোপণের সময় ১/৩ অর্থাৎ ২৬.৬৭ কেজি/বিঘা<br> + দ্বিতীয় সময়: গাছের গজানোর সময় ১/৩ অর্থাৎ ২৬.৬৭ কেজি/বিঘা<br> + তৃতীয় সময়: ধানের শিষ বের হওয়ার সময় ১/৩ অর্থাৎ ২৬.৬৭ কেজি/বিঘা<br></em> <strong>টিএসপি (ট্রিপল সুপারফসফেট)</strong>: ২২ কেজি/বিঘা, চারা রোপণের সময় প্রয়োগ করতে হবে<br><em> <strong>এমওপি (মিউরিয়েট অফ পটাশ)</strong>: ৩০ কেজি/বিঘা, চারা রোপণের সময় প্রয়োগ করতে হবে<br></em> <strong>জিপসাম (জিপসাম)</strong>: ২৫ কেজি/বিঘা, চারা রোপণের সময় প্রয়োগ করতে হবে<br><em> <strong>জিঙ্ক সালফেট (জিঙ্ক সালফেট)</strong>: ২ কেজি/বিঘা, গাছের গজানোর সময় প্রয়োগ করতে হবে<br></em> <strong>বোরাক্স (বোরাক্স)</strong>: ১ কেজি/বিঘা, গাছের গজানোর সময় প্রয়োগ করতে হবে</p><p>এছাড়াও, বোরো ধানের জন্য জৈব সার ব্যবহার করা যেতে পারে। জৈব সার হিসেবে কম্পোস্ট, ভার্মিকম্পোস্ট, গোবর সার ইত্যাদি ব্যবহ</p>', NULL, '2026-05-17 17:15:47', NULL),
(109, '83988129ef7ac1b34111576f0c84bed3', 'user', 'কোন ফলাফল দেখা যাবে বোরো ধানে টিএসপি সার প্রয়োগের সাথে?', NULL, '2026-05-17 17:15:54', NULL),
(110, '83988129ef7ac1b34111576f0c84bed3', 'assistant', '<p>বোরো ধানে টিএসপি সার প্রয়োগের ফলে নিম্নলিখিত ফলাফল দেখা যাবে:</p><p><em> <strong>ধানের গাছের বৃদ্ধি বৃদ্ধি</strong>: টিএসপি সারে ফসফরাস থাকে, যা ধানের গাছের বৃদ্ধির জন্য অত্যন্ত গুরুত্বপূর্ণ। এটি গাছের মূলের বৃদ্ধি, পাতার বৃদ্ধি এবং ধানের শিষের গঠনে সাহায্য করে।<br></em> <strong>ধানের ফুলের বৃদ্ধি</strong>: টিএসপি সার প্রয়োগের ফলে ধানের ফুলের বৃদ্ধি বৃদ্ধি পায়। এটি ধানের ফলন বৃদ্ধির জন্য অত্যন্ত গুরুত্বপূর্ণ।<br><em> <strong>ধানের ফলন বৃদ্ধি</strong>: টিএসপি সার প্রয়োগের ফলে ধানের ফলন বৃদ্ধি পায়। এটি কৃষকদের জন্য অত্যন্ত গুরুত্বপূর্ণ, কারণ এটি তাদের আয় বৃদ্ধি করে।<br></em> <strong>ধানের গুণমান উন্নতি</strong>: টিএসপি সার প্রয়োগের ফলে ধানের গুণমান উন্নতি পায়। এটি ধানের রং, গন্ধ এবং স্বাদ উন্নতি করে।</p><p>এইভাবে, বোরো ধানে টিএসপি সার প্রয়োগের ফলে ধানের গাছের বৃদ্ধি, ফুলের বৃদ্ধি, ফলন বৃদ্ধি এবং গুণমান উন্নতি পায়। এটি কৃষকদের জন্য অত্যন্ত গুরুত্বপূর্ণ, কারণ এটি তাদের আয় বৃদ্ধি করে এবং তাদের জীবনযাত্রার মান উন্নতি করে।</p>', NULL, '2026-05-17 17:15:54', NULL),
(111, '3ad9b26b0fd0e15be1c4ddfbd438ab6b', 'user', 'I\'ve attached a crop image. What disease or problem do you see?', '[\"agent\\/uploads\\/64_1779038462_be6e9b2f.jpg\"]', '2026-05-17 17:21:04', NULL),
(112, '3ad9b26b0fd0e15be1c4ddfbd438ab6b', 'assistant', '<p>Based on the analysis, I can see that the detected disease is Yellow, also known as হলুদ পাতা রোগ in Bengali, with a confidence of 90.38% and high severity.</p><ol><br><li><strong>Disease / Condition</strong> — The detected disease is Yellow, with a confidence of 90.38% and high severity. This disease is characterized by the yellowing of the midrib followed by the entire leaf, stunted growth, and reduced sugar content.</li><br><li><strong>Symptoms to Confirm</strong> — To confirm the presence of this disease, please verify if the midrib of the leaves is turning yellow, followed by the entire leaf, and if the plant is exhibiting stunted growth. Also, check if the sugar content of the sugarcane is reduced.</li><br><li><strong>Chemical Treatment</strong> — To control the aphid vectors that spread this disease, you can use Imidacloprid @ 0.5ml/L. However, please note that there is no cure for infected plants. It\'s essential to follow the label instructions and take necessary precautions while applying any chemical treatment.</li><br><li><strong>Organic / IPM Alternative</strong> — As an organic farmer, you can consider removing infected plants, using virus-free setts, and controlling aphids with neem oil. Neem oil can be effective in managing aphid populations, which can help reduce the spread of the disease.</li><br><li><strong>Prevention for Next Season</strong> — To prevent this disease in the next season, consider the following steps:</li><br></ol><br>   - Use certified disease-free setts to plant sugarcane.<br>   - Rogue infected plants as soon as symptoms appear to prevent the spread of the disease.<br>   - Control aphid vectors using neem oil or other organic methods to reduce the risk of disease transmission.</p><ol><br><li><strong>Immediate Next Steps</strong> — Today, please inspect your sugarcane field to identify and remove any infected plants. Apply neem oil to control aphid vectors, and consider using Imidacloprid @ 0.5ml/L if the infestation is severe. Also, plan to use certified disease-free setts for the next planting season to prevent the recurrence of this disease.</li><br></ol>', NULL, '2026-05-17 17:21:04', NULL),
(113, '3ad9b26b0fd0e15be1c4ddfbd438ab6b', 'user', 'How can I treat this disease without harming the soil?', NULL, '2026-05-17 17:21:19', NULL);
INSERT INTO `agent_messages` (`id`, `conversation_id`, `role`, `content`, `images`, `created_at`, `feedback`) VALUES
(114, '3ad9b26b0fd0e15be1c4ddfbd438ab6b', 'assistant', '<p><strong>Disease Identification:</strong><br>Based on the symptoms, I suspect that your rice crop is suffering from <strong>Blast Disease</strong>, a common fungal disease in Bangladesh. The symptoms include yellowing or whitening of leaves, necrotic spots, and a distinctive \"blast\" or \"blight\" appearance on the leaves and stems.</p><p><strong>Organic Treatment Options:</strong><br>To treat Blast Disease without harming the soil, consider the following organic methods:</p><p><em> <strong>Neem Oil</strong>: Apply neem oil at a concentration of 3-5 ml/L to control fungal growth and prevent the spread of the disease.<br></em> <strong>Copper Oxychloride</strong>: Use copper oxychloride at a rate of 2.5 g/L as a fungicide to control the disease.<br><em> <strong>Bordeaux Mixture</strong>: Prepare a Bordeaux mixture by combining 1 kg of copper sulfate with 1 kg of lime in 100 L of water. This mixture can be used to control fungal diseases like Blast.<br></em> <strong>Trichoderma</strong>: Apply Trichoderma harzianum, a beneficial fungus, at a rate of 2 kg/ha to promote healthy microbial activity in the soil and control pathogens.</p><p><strong>Cultural Practices:</strong><br>In addition to these organic treatments, adopt the following cultural practices to manage Blast Disease:</p><ol><br><li><strong>Remove infected plants</strong>: Remove and destroy infected plants to prevent the spread of the disease.</li><br><li><strong>Improve air circulation</strong>: Ensure good air circulation in the field to reduce humidity and prevent fungal growth.</li><br><li><strong>Maintain soil health</strong>: Maintain soil health through regular addition of organic matter, such as compost or vermicompost.</li><br><li><strong>Use resistant varieties</strong>: Plant rice varieties that are resistant to Blast Disease.</li><br></ol><br><strong>Soil-Friendly Tips:</strong><br>To minimize the impact on the soil, follow these tips:</p><p><em> <strong>Avoid over-application</strong>: Avoid over-applying organic treatments, as this can harm beneficial microorganisms in the soil.<br></em> <strong>Use natural products</strong>: Opt for natural products like neem oil and copper oxychloride instead of synthetic chemicals.<br><ul><br><li><strong>Maintain soil pH</strong>: Maintain a soil pH between 5.5 and 7.0 to promote healthy microbial activity.</li><br></ul><br>By adopting these organic treatment options and cultural practices, you can effectively manage Blast Disease in your rice crop while maintaining soil health.</p>', NULL, '2026-05-17 17:21:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `agent_user_memory`
--

CREATE TABLE `agent_user_memory` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `memory_key` varchar(100) NOT NULL,
  `memory_value` text NOT NULL,
  `source` enum('auto','manual') NOT NULL DEFAULT 'auto',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `agent_user_memory`
--

INSERT INTO `agent_user_memory` (`id`, `user_id`, `memory_key`, `memory_value`, `source`, `updated_at`) VALUES
(1, 64, 'farming_type', 'vegetable farmer', 'auto', '2026-05-17 17:13:25'),
(2, 64, 'preferred_language', 'Bangla', 'auto', '2026-05-17 17:15:54'),
(3, 64, 'grows_crop', 'rice', 'auto', '2026-05-17 17:15:54'),
(13, 64, 'farming_method', 'organic farming', 'auto', '2026-05-17 10:36:46'),
(37, 64, 'grows_boro_rice', 'Boro rice', 'auto', '2026-05-17 17:15:54'),
(38, 64, 'grows_aus_rice', 'Aus rice', 'auto', '2026-05-17 16:39:58');

-- --------------------------------------------------------

--
-- Table structure for table `ai_chat_logs`
--

CREATE TABLE `ai_chat_logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_message` text DEFAULT NULL,
  `ai_response` text DEFAULT NULL,
  `message_type` enum('general','crop_advice','disease','weather','market') DEFAULT 'general',
  `language` enum('bangla','english') DEFAULT 'english',
  `sentiment` varchar(50) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL COMMENT '1-5 rating',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ai_recommendations`
--

CREATE TABLE `ai_recommendations` (
  `recommendation_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `crop_id` int(11) DEFAULT NULL,
  `recommendation_type` enum('crop_selection','planting_time','irrigation','fertilizer','pest_control','harvesting') NOT NULL,
  `recommendation` text NOT NULL,
  `confidence_score` decimal(5,2) DEFAULT NULL,
  `based_on` text DEFAULT NULL COMMENT 'weather, soil, history, etc',
  `is_accepted` tinyint(1) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ai_usage_logs`
--

CREATE TABLE `ai_usage_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `conversation_id` varchar(64) DEFAULT NULL,
  `provider` varchar(20) NOT NULL DEFAULT 'groq',
  `model` varchar(100) NOT NULL DEFAULT '',
  `prompt_tokens` int(11) NOT NULL DEFAULT 0,
  `completion_tokens` int(11) NOT NULL DEFAULT 0,
  `total_tokens` int(11) NOT NULL DEFAULT 0,
  `response_time_ms` int(11) NOT NULL DEFAULT 0,
  `success` tinyint(1) NOT NULL DEFAULT 1,
  `error_message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ai_usage_logs`
--

INSERT INTO `ai_usage_logs` (`id`, `user_id`, `conversation_id`, `provider`, `model`, `prompt_tokens`, `completion_tokens`, `total_tokens`, `response_time_ms`, `success`, `error_message`, `created_at`) VALUES
(1, 64, 'e62ebb1d16ef9d7aeead9a4d677f29b7', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2727, 1, NULL, '2026-05-16 15:10:11'),
(2, 64, 'de9c401b4210fc96727e3346a916f0a5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 3901, 1, NULL, '2026-05-16 19:49:21'),
(3, 64, 'de9c401b4210fc96727e3346a916f0a5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 3068, 1, NULL, '2026-05-16 19:49:33'),
(4, 64, 'de9c401b4210fc96727e3346a916f0a5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2894, 1, NULL, '2026-05-16 19:49:53'),
(5, 64, 'de9c401b4210fc96727e3346a916f0a5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2718, 1, NULL, '2026-05-16 19:50:02'),
(6, 64, 'de9c401b4210fc96727e3346a916f0a5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2511, 1, NULL, '2026-05-16 19:53:44'),
(7, 64, 'de9c401b4210fc96727e3346a916f0a5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2378, 1, NULL, '2026-05-16 19:53:59'),
(8, 64, 'de9c401b4210fc96727e3346a916f0a5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 543, 0, 'Provider returned null', '2026-05-16 19:54:14'),
(9, 64, 'de9c401b4210fc96727e3346a916f0a5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 3714, 1, NULL, '2026-05-16 19:54:28'),
(10, 64, 'de9c401b4210fc96727e3346a916f0a5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 4364, 1, NULL, '2026-05-16 19:55:22'),
(11, 64, '67a634ff3466ffc874821d37f166efb1', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 3724, 1, NULL, '2026-05-16 19:59:05'),
(12, 64, 'dab188e6f4f6eb36ed4c76fa382df377', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2595, 1, NULL, '2026-05-16 19:59:22'),
(13, 64, 'dab188e6f4f6eb36ed4c76fa382df377', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 3226, 1, NULL, '2026-05-16 19:59:33'),
(14, 64, '40e65a8ccc504a05f42bb519cdae159e', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2874, 1, NULL, '2026-05-16 20:01:34'),
(15, 64, 'c688bc823694b8af5dc75c5066d02e92', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2619, 1, NULL, '2026-05-16 20:26:33'),
(16, 64, 'c688bc823694b8af5dc75c5066d02e92', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2265, 1, NULL, '2026-05-16 20:27:17'),
(17, 64, 'c688bc823694b8af5dc75c5066d02e92', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1705, 1, NULL, '2026-05-16 20:28:13'),
(18, 64, 'c688bc823694b8af5dc75c5066d02e92', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1275, 1, NULL, '2026-05-16 20:28:16'),
(19, 64, 'c688bc823694b8af5dc75c5066d02e92', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1634, 1, NULL, '2026-05-16 20:41:50'),
(20, 64, 'c688bc823694b8af5dc75c5066d02e92', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1900, 1, NULL, '2026-05-16 20:42:08'),
(21, 64, '1f48d1a67a7579b9bd934ecc8d8caabd', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1134, 1, NULL, '2026-05-16 20:44:04'),
(22, 64, 'cdbc7dafaecf1f70e45e0e1dd6df4626', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1230, 1, NULL, '2026-05-16 20:59:27'),
(23, 64, 'd3b6aabfc451f267b03796321fa9859b', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1733, 1, NULL, '2026-05-16 21:09:20'),
(24, 64, 'd3b6aabfc451f267b03796321fa9859b', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1327, 1, NULL, '2026-05-16 21:09:36'),
(25, 64, 'd3b6aabfc451f267b03796321fa9859b', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1497, 1, NULL, '2026-05-16 21:13:33'),
(26, 64, 'd3b6aabfc451f267b03796321fa9859b', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1545, 1, NULL, '2026-05-16 21:13:53'),
(27, 64, 'd3b6aabfc451f267b03796321fa9859b', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1635, 1, NULL, '2026-05-16 21:14:14'),
(28, 64, '7f47874c984bd6568149be76fd97dbd7', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2558, 1, NULL, '2026-05-17 05:29:05'),
(29, 64, '7f47874c984bd6568149be76fd97dbd7', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1576, 1, NULL, '2026-05-17 05:51:20'),
(30, 64, '7f47874c984bd6568149be76fd97dbd7', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1473, 1, NULL, '2026-05-17 05:51:28'),
(31, 64, 'ad88b1c15721fe5b641bfeffe7b35bf5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2437, 1, NULL, '2026-05-17 05:59:23'),
(32, 64, 'ad88b1c15721fe5b641bfeffe7b35bf5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1754, 1, NULL, '2026-05-17 05:59:33'),
(33, 64, 'fc615d1280bccd8d1f9061975e4d97cc', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2046, 1, NULL, '2026-05-17 05:59:43'),
(34, 64, '58a46a8289ec28de1411e5bf802e1e33', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2158, 1, NULL, '2026-05-17 06:11:28'),
(35, 64, '58a46a8289ec28de1411e5bf802e1e33', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1686, 1, NULL, '2026-05-17 06:11:40'),
(36, 64, 'f333b7a439124d8d40eb69fc375f7023', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1598, 1, NULL, '2026-05-17 06:12:05'),
(37, 64, 'f333b7a439124d8d40eb69fc375f7023', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2764, 1, NULL, '2026-05-17 06:12:21'),
(38, 64, 'f333b7a439124d8d40eb69fc375f7023', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2893, 1, NULL, '2026-05-17 06:12:28'),
(39, 64, 'f333b7a439124d8d40eb69fc375f7023', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2999, 1, NULL, '2026-05-17 06:15:46'),
(40, 64, 'f333b7a439124d8d40eb69fc375f7023', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 292, 0, 'Provider returned null', '2026-05-17 06:15:51'),
(41, 64, '44b89da17e908942f6ef7a8fa25d2385', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2829, 1, NULL, '2026-05-17 10:16:10'),
(42, 64, 'd4a1f3cdcc69ee5328ecf409f84836f8', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2359, 1, NULL, '2026-05-17 10:25:22'),
(43, 64, 'd4a1f3cdcc69ee5328ecf409f84836f8', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2339, 1, NULL, '2026-05-17 10:25:29'),
(44, 64, 'a65d6adf9b5672879c0c31cc5d279b3e', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2052, 1, NULL, '2026-05-17 10:36:46'),
(45, 64, 'a65d6adf9b5672879c0c31cc5d279b3e', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1574, 1, NULL, '2026-05-17 10:45:24'),
(46, 64, '17444e1ebbbe742ebdf800d430bc4388', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1344, 1, NULL, '2026-05-17 11:41:18'),
(47, 64, '4b06314a870565ff733007ca620e7e06', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2846, 1, NULL, '2026-05-17 15:30:23'),
(48, 64, '1775977f974a7d1c7f5577526a1a5ab5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1535, 1, NULL, '2026-05-17 15:35:13'),
(49, 64, '9ae061331283c400f4216f37896152e5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2211, 1, NULL, '2026-05-17 15:35:31'),
(50, 64, 'bcf8b5806342a7dcc463ee13797ed0f9', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 3180, 1, NULL, '2026-05-17 15:43:15'),
(51, 64, '9ae061331283c400f4216f37896152e5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1323, 1, NULL, '2026-05-17 16:11:06'),
(52, 64, '1f23b2217102ebfe803585dc9be10c09', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 3539, 1, NULL, '2026-05-17 16:12:12'),
(53, 64, '9ae061331283c400f4216f37896152e5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 3059, 1, NULL, '2026-05-17 16:21:30'),
(54, 64, '9ae061331283c400f4216f37896152e5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2777, 1, NULL, '2026-05-17 16:23:41'),
(55, 64, '71c33f3720fb50135f070b8e6c80b2d5', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 254, 0, 'Provider returned null', '2026-05-17 16:27:29'),
(56, 64, 'ac2247686f5122b6c22290f950d663cf', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 292, 0, 'Provider returned null', '2026-05-17 16:27:53'),
(57, 64, '583e9a36408c8ec22d5e7362053de10f', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 237, 0, 'Provider returned null', '2026-05-17 16:27:59'),
(58, 64, 'b38e6d887c4bffbf0a250c501a41fa0e', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 257, 0, 'Provider returned null', '2026-05-17 16:28:02'),
(59, 64, '254932cde198777059dc8785cb225a2a', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 250, 0, 'Provider returned null', '2026-05-17 16:28:04'),
(60, 64, 'ff8b5dc7f77e40cd4e24dcd21ab92f8f', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2932, 1, NULL, '2026-05-17 16:38:57'),
(61, 64, '9e40e38c2f6dcb03dae76bd0aed2ba46', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 3299, 1, NULL, '2026-05-17 16:39:58'),
(62, 64, '9e40e38c2f6dcb03dae76bd0aed2ba46', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1737, 1, NULL, '2026-05-17 16:47:35'),
(63, 64, '1f23b2217102ebfe803585dc9be10c09', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1713, 1, NULL, '2026-05-17 16:48:21'),
(64, 64, 'a134416d240695dbdd2944f1303c32ed', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 3186, 1, NULL, '2026-05-17 16:57:21'),
(65, 64, 'bb8674ed1975ab28815ef7b43b7ef05b', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 3030, 1, NULL, '2026-05-17 17:13:25'),
(66, 64, '83988129ef7ac1b34111576f0c84bed3', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 3028, 1, NULL, '2026-05-17 17:15:47'),
(67, 64, '83988129ef7ac1b34111576f0c84bed3', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2537, 1, NULL, '2026-05-17 17:15:53'),
(68, 64, '3ad9b26b0fd0e15be1c4ddfbd438ab6b', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 1954, 1, NULL, '2026-05-17 17:21:04'),
(69, 64, '3ad9b26b0fd0e15be1c4ddfbd438ab6b', 'groq', 'llama-3.3-70b-versatile', 0, 0, 0, 2001, 1, NULL, '2026-05-17 17:21:19');

-- --------------------------------------------------------

--
-- Table structure for table `alerts`
--

CREATE TABLE `alerts` (
  `alert_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `alert_type` enum('weather','disease','market','system','advisory','crop','community') DEFAULT 'system',
  `title` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `priority` enum('low','medium','high','critical') DEFAULT 'low',
  `category` varchar(100) DEFAULT NULL,
  `action_url` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` timestamp NULL DEFAULT NULL,
  `sent_via` enum('app','email','sms','all') DEFAULT 'app',
  `created_by` int(11) DEFAULT NULL COMMENT 'officer/admin who created alert',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `alerts`
--

INSERT INTO `alerts` (`alert_id`, `user_id`, `alert_type`, `title`, `message`, `priority`, `category`, `action_url`, `is_read`, `read_at`, `sent_via`, `created_by`, `created_at`, `expires_at`) VALUES
(111, 50, 'weather', 'Cold Wave', 'There will be a cold wave from the 22nd to the 26th', 'critical', 'Weather', NULL, 0, NULL, 'app', 70, '2026-01-15 11:09:29', NULL),
(112, 64, 'weather', 'Cold Wave', 'There will be a cold wave from the 22nd to the 26th', 'critical', 'Weather', NULL, 0, NULL, 'app', 70, '2026-01-15 11:09:29', NULL),
(113, 69, 'weather', 'Cold Wave', 'There will be a cold wave from the 22nd to the 26th', 'critical', 'Weather', NULL, 0, NULL, 'app', 70, '2026-01-15 11:09:29', NULL),
(114, 64, 'system', 'Field Visit Scheduled', 'An agricultural officer has scheduled a field visit on Jan 16, 2026 at 05:11 PM.', 'medium', 'Visit', NULL, 0, NULL, 'app', 71, '2026-01-15 11:12:11', NULL),
(115, 50, 'system', 'Field Visit Scheduled', 'An agricultural officer has scheduled a field visit on Jan 17, 2026 at 04:11 PM.', 'medium', 'Visit', NULL, 0, NULL, 'app', 70, '2026-01-15 11:14:05', NULL),
(116, 69, 'system', 'Field Visit Scheduled', 'An agricultural officer has scheduled a field visit on Jan 16, 2026 at 04:14 PM.', 'medium', 'Visit', NULL, 0, NULL, 'app', 70, '2026-01-15 11:14:42', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `api_request_logs`
--

CREATE TABLE `api_request_logs` (
  `log_id` int(11) NOT NULL,
  `endpoint` varchar(255) DEFAULT NULL,
  `method` varchar(10) DEFAULT NULL,
  `response_code` int(11) DEFAULT NULL,
  `response_time_ms` int(11) DEFAULT NULL,
  `request_size` int(11) DEFAULT NULL,
  `response_size` int(11) DEFAULT NULL,
  `memory_usage` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `article_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `title_bn` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `excerpt` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `featured_image` varchar(255) DEFAULT NULL,
  `language` enum('english','bangla','both') DEFAULT 'both',
  `views` int(11) DEFAULT 0,
  `likes` int(11) DEFAULT 0,
  `is_published` tinyint(1) DEFAULT 0,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `audit_trail`
--

CREATE TABLE `audit_trail` (
  `audit_id` int(11) NOT NULL,
  `table_name` varchar(100) NOT NULL,
  `record_id` int(11) NOT NULL,
  `action` enum('INSERT','UPDATE','DELETE') NOT NULL,
  `old_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_data`)),
  `new_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_data`)),
  `changed_fields` text DEFAULT NULL,
  `change_summary` varchar(500) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_role` varchar(50) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `backup_records`
--

CREATE TABLE `backup_records` (
  `backup_id` int(11) NOT NULL,
  `backup_type` enum('full','incremental','database','files','config') NOT NULL,
  `backup_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `checksum` varchar(64) DEFAULT NULL,
  `checksum_type` varchar(20) DEFAULT 'sha256',
  `tables_included` text DEFAULT NULL,
  `rows_count` int(11) DEFAULT NULL,
  `compression` enum('none','gzip','zip') DEFAULT 'gzip',
  `encryption` enum('none','aes256') DEFAULT 'none',
  `status` enum('pending','in_progress','completed','failed','deleted','corrupted') DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `duration_seconds` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backup_records`
--

INSERT INTO `backup_records` (`backup_id`, `backup_type`, `backup_name`, `file_path`, `file_size`, `checksum`, `checksum_type`, `tables_included`, `rows_count`, `compression`, `encryption`, `status`, `error_message`, `duration_seconds`, `created_by`, `created_at`, `expires_at`, `deleted_at`) VALUES
(1, 'full', NULL, NULL, NULL, NULL, 'sha256', NULL, NULL, 'gzip', 'none', 'in_progress', NULL, NULL, NULL, '2025-12-30 14:18:54', NULL, NULL),
(2, 'full', NULL, NULL, NULL, NULL, 'sha256', NULL, NULL, 'gzip', 'none', 'in_progress', NULL, NULL, NULL, '2025-12-30 14:19:27', NULL, NULL),
(3, 'full', NULL, NULL, NULL, NULL, 'sha256', NULL, NULL, 'gzip', 'none', 'in_progress', NULL, NULL, NULL, '2025-12-30 14:22:00', NULL, NULL),
(4, 'full', NULL, 'C:\\xampp\\htdocs\\smartcashi/backups/2025-12-30/backup_2025-12-30_15-23-22_full', NULL, NULL, 'sha256', NULL, NULL, 'gzip', 'none', 'completed', NULL, NULL, 49, '2025-12-30 14:23:22', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `message_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `comment_likes`
--

CREATE TABLE `comment_likes` (
  `like_id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `community_posts`
--

CREATE TABLE `community_posts` (
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `post_type` enum('question','discussion','tip','success_story','problem') DEFAULT 'discussion',
  `image_url` varchar(255) DEFAULT NULL,
  `likes` int(11) DEFAULT 0,
  `views` int(11) DEFAULT 0,
  `is_pinned` tinyint(1) DEFAULT 0,
  `is_featured` tinyint(1) DEFAULT 0,
  `is_approved` tinyint(1) DEFAULT 1,
  `approved_by` int(11) DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `community_posts`
--

INSERT INTO `community_posts` (`post_id`, `user_id`, `title`, `content`, `category`, `post_type`, `image_url`, `likes`, `views`, `is_pinned`, `is_featured`, `is_approved`, `approved_by`, `tags`, `created_at`, `updated_at`) VALUES
(1, 73, 'Amar crop yellow hoi geche', 'Amar crop yellow hoi geche ki kora jai', 'Crop Problems', 'discussion', 'public/uploads/community/post_73_1768476974.jpg', 0, 0, 0, 0, 1, NULL, NULL, '2026-01-15 11:36:14', '2026-01-15 11:36:14'),
(2, 50, 'ধান পাতায় বাদামী দাগ – এটি কি Brown Spot?', 'ধানের পাতায় বাদামী ছোট দাগ দেখা যাচ্ছে। কিছুদিন পর দাগগুলো বড় হচ্ছে এবং গাছ দুর্বল হয়ে পড়ছে। কেউ কি নিশ্চিত বলতে পারবেন এটি Brown Spot কিনা? Fungicide ব্যবহারের পরামর্শ চাই।', 'Agriculture', 'question', NULL, 12, 166, 0, 0, 1, NULL, 'brown spot, paddy disease', '2026-01-15 11:42:23', '2026-01-16 03:05:46'),
(3, 64, 'Solar Irrigation System খরচ কত?', '২ একর জমির জন্য solar pump বসাতে চাই। Panel, inverter, wiring এবং maintenance এর মোট খরচ কত হতে পারে? কোনো কোম্পানি থেকে নিলে সুবিধা বেশি, নাকি আলাদা আলাদা কিনে বসানো ভালো?', 'Agriculture', 'question', NULL, 18, 250, 0, 0, 1, NULL, 'solar pump, irrigation', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(4, 69, 'ছাদের বাগানে কোন জৈব কীটনাশক ভালো?', 'Neem oil ব্যবহার করেছি কিন্তু কাজে ধীর। অন্য কোনো organic pest control যেমন রসুন extract বা মরিচের ঝোল ব্যবহার করলে কি ভালো ফল পাওয়া যায়? অভিজ্ঞরা সাজেশন দিন।', 'Agriculture', '', NULL, 8, 140, 0, 0, 1, NULL, 'organic pesticide, rooftop garden', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(5, 70, 'Biofloc Fish Farming কিভাবে শুরু করবো?', 'Biofloc পদ্ধতিতে মাছ চাষ করতে চাই। Tank size, aeration system, C/N ratio, feed schedule—কোনো complete guideline চাই। শুরুর দিকে কত লিটার পানি লাগবে জানতে চাই।', 'Agriculture', 'question', NULL, 15, 210, 0, 0, 1, NULL, 'biofloc, aquaculture', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(6, 71, 'Hybrid বেগুনের ফলন বাড়ানোর উপায়', 'Hybrid বেগুন গাছ খুব বড় হচ্ছে কিন্তু ফল কম আসছে। সম্ভবত pollination সমস্যা। আমি কি hormone spray ব্যবহার করবো, নাকি মাটির সার বাড়ালে হবে?', 'Agriculture', 'question', NULL, 11, 120, 0, 0, 1, NULL, 'brinjal hybrid, yield increase', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(7, 72, 'মরিচ গাছে পাতা মোচড়ানো রোগ – সমাধান দিন', 'মরিচ গাছের পাতায় মোচড়ানো সমস্যা দেখা যাচ্ছে। অনেকেই বলেছে virus attack হতে পারে। কেউ কি নিশ্চিত সমাধান দিতে পারবেন? কোন insecticide ব্যবহার করা ভালো?', 'Agriculture', 'problem', NULL, 14, 155, 0, 0, 1, NULL, 'chili curl virus', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(8, 73, 'গমের ফলন কমে যাচ্ছে কেন?', 'এই বছর গমের ফলন আশানুরূপ হয়নি। মাটি পরীক্ষা করলে দেখা যায় Potash কম। কোন সার কতটুকু ব্যবহার করলে ফলন বাড়ানো যাবে?', 'Agriculture', 'question', NULL, 9, 180, 0, 0, 1, NULL, 'wheat, fertilizer', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(9, 49, 'Village Pond Fish Farming – Profit Calculation', 'আমাদের গ্রামের পুকুরে কার্প জাতীয় মাছ চাষ করি। Feed cost এবং বাজার মূল্য বিশ্লেষণ করে দেখি প্রতি বছর প্রায় ৩০–৪০% লাভ থাকে। নতুন উদ্যোক্তারা চাইলে ছোট পুকুর দিয়েও শুরু করতে পারে।', 'Agriculture', '', NULL, 25, 320, 0, 1, 1, NULL, 'fish farming, profit', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(10, 50, 'পেঁপে গাছে ফুল ঝরে যাচ্ছে', 'গরমে পেঁপে গাছে ফুল ধরে না। অনেক ফুল ধরলেও ঝরে পড়ে। কেউ কি জানেন এটা কি পানি কম পায় নাকি temperature problem? কিভাবে নিয়ন্ত্রণ করবো?', 'Agriculture', 'question', NULL, 7, 110, 0, 0, 1, NULL, 'papaya flower drop', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(11, 64, 'Organic কৃষি – নিজের ফার্মের অভিজ্ঞতা', 'গত বছর থেকে রাসায়নিক সার বাদ দিয়ে পুরোপুরি organic farming শুরু করেছি। মাটির গুণগত মান অনেক বেড়েছে। ফলন একটু কম হলেও বাজারে organic vegetables বেশি দাম পাওয়া যায়।', 'Agriculture', '', NULL, 32, 350, 0, 0, 1, NULL, 'organic farming', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(12, 69, 'ধান চাষে পানি ব্যবস্থাপনা', 'ধান ক্ষেতে অনেকেই প্রয়োজনের বেশি পানি দেয়, যা root damage করে। Alternating Wetting and Drying (AWD) technique ব্যবহার করলে পানি বাঁচে এবং ফলন বাড়ে। কেউ কি AWD ব্যবহার করছেন?', 'Agriculture', 'discussion', NULL, 12, 175, 0, 0, 1, NULL, 'AWD, irrigation', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(13, 70, 'কলায় ছত্রাক রোগ ছড়াচ্ছে', 'Banana leaf এ কালো দাগ দেখা যাচ্ছে যা দ্রুত ছড়াচ্ছে। স্থানীয়ভাবে বলা হয়েছে এটি Sigatoka disease। Fungicide কোনটি বেশি কাজ করে?', 'Agriculture', 'question', NULL, 6, 95, 0, 0, 1, NULL, 'banana disease, sigatoka', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(14, 71, 'ড্রিপ সেচ বনাম ফ্লাড সেচ', 'ড্রিপ সেচে পানির অপচয় কম হয় এবং গাছ সুস্থ থাকে। কিন্তু ছোট চাষির জন্য cost বেশি। বাংলাদেশের মাঠপর্যায়ে কোনটা বেশি কার্যকর?', 'Agriculture', 'discussion', NULL, 10, 130, 0, 0, 1, NULL, 'drip irrigation, flood irrigation', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(15, 72, 'পুকুরে pH কমে যাচ্ছে – করণীয় কী?', 'পুকুরের পানির pH 6.0 এ নেমে গেছে। Lime দিলে কি সঙ্গে সঙ্গে ঠিক হবে? কত কেজি দিতে হয়? কেউ অভিজ্ঞতা শেয়ার করবেন?', 'Agriculture', 'question', NULL, 13, 165, 0, 0, 1, NULL, 'fish pond ph', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(16, 73, 'গরুর তাজা ঘাস উৎপাদন টেকনিক', 'Napier এবং German ঘাস গরুর খাবারের জন্য সবচেয়ে ভালো। সঠিক কেটে ছাঁটাই করলে প্রতি মাসে নতুন ঘাস ওঠে। নতুন ফার্মারদের জন্য এটি ideal fodder.', 'Agriculture', '', NULL, 19, 210, 0, 0, 1, NULL, 'fodder, cattle feed', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(17, 49, 'ডাল চাষে পোকা দমন কৌশল', 'ডাল গাছের শুঁয়োপোকা খুব ক্ষতি করে। Neem oil + light trap ব্যবহার করলে অনেকটা কমে যায়। chemical insecticide কম ব্যবহার করাই ভালো।', 'Agriculture', '', NULL, 11, 105, 0, 0, 1, NULL, 'lentils, pest control', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(18, 50, 'Hybrid Rice – কোন জাত সবচেয়ে ভালো?', 'BRRI hybrid varieties নিয়ে কারো কি অভিজ্ঞতা আছে? Yield ভালো হলেও কিছু জায়গায় রোগ দেখা যায়। কোন varietie সবচেয়ে disease resistant?', 'Agriculture', 'question', NULL, 16, 225, 0, 0, 1, NULL, 'hybrid rice', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(19, 64, 'কুমড়া চাষ – উচ্চ ফলনের কৌশল', 'কুমড়া গাছ ছড়িয়ে বেড়ে জায়গা বেশি লাগে। Proper pruning করলে ফলন দ্বিগুণ হয়। আমি ৪০টি গাছ থেকে ২০০+ কুমড়া পেয়েছি।', 'Agriculture', '', NULL, 28, 330, 0, 1, 1, NULL, 'pumpkin, pruning', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(20, 69, 'পেঁয়াজ চারা নষ্ট হয়ে যাচ্ছে', 'বর্ষায় চারা নষ্ট হচ্ছে। মাটিতে পানি বেশি থাকার কারণে root rot হচ্ছে বলে মনে হয়। Raised bed করলে কি উপকার হবে?', 'Agriculture', 'question', NULL, 9, 115, 0, 0, 1, NULL, 'onion seedling problem', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(21, 70, 'Greenhouse Farming – Bangladesh এ কতটা লাভজনক?', 'Controlled environment এ সবজি উৎপাদন করলে pest কম হয় এবং yield বেশি। কিন্তু setup cost বেশি। কেউ কি টেকসইভাবে চালাতে পেরেছেন?', 'Agriculture', 'discussion', NULL, 21, 260, 0, 0, 1, NULL, 'greenhouse, climate control', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(22, 71, 'তরমুজে মিষ্টতা বাড়ানোর উপায়', 'Late stage এ potash বাড়ালে তরমুজের মিষ্টতা বাড়ে। পানি কম দিলে ফল আরও মিষ্টি হয়।', 'Agriculture', 'tip', NULL, 14, 150, 0, 0, 1, NULL, 'watermelon', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(23, 72, 'রসুন চাষ – কখন সার দেবেন?', 'রসুন লাগানোর ২০ দিন পর প্রথম সার, এরপর প্রতি ৩০ দিনে একটি light fertilizer দিলে ভালো ফল হয়।', 'Agriculture', 'tip', NULL, 9, 98, 0, 0, 1, NULL, 'garlic farming', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(24, 73, 'মিষ্টি কুমড়ায় পোকা সমস্যা', 'Fruit borer attack করছে। Pheromone trap ব্যবহার করলে অনেক কমে যায়।', 'Agriculture', 'problem', NULL, 12, 140, 0, 0, 1, NULL, 'pumpkin pest', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(25, 49, 'Chemical Fertilizer Overdose Damage', 'অনেকে ভুল করে বেশি সার দেয়। এতে root burn হয়ে গাছ মারা যায়। Balanced fertilizer ব্যবহার করুন।', 'Agriculture', '', NULL, 15, 180, 0, 0, 1, NULL, 'fertilizer burn', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(26, 50, 'আদা চাষে লাভ কেমন?', 'আদার দাম বেশি থাকে। ৫ শতক জমিতে বছরে ৫০-৭০ হাজার টাকা লাভ করা যায়।', 'Agriculture', 'discussion', NULL, 18, 210, 0, 0, 1, NULL, 'ginger farming', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(27, 64, 'তিল চাষের সঠিক সময়', 'তিল বর্ষার আগে লাগাতে হয়। বৃষ্টির পরে ফলন কমে যায়।', 'Agriculture', 'tip', NULL, 6, 90, 0, 0, 1, NULL, 'sesame', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(28, 69, 'ধানের শিষে Blast রোগ', 'Blast disease ধানের জন্য সবচেয়ে ক্ষতিকর। Tricyclazole দ্রুত কাজ করে।', 'Agriculture', 'question', NULL, 13, 160, 0, 0, 1, NULL, 'paddy blast', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(29, 70, 'সয়াবিন চাষে পানি ব্যবস্থাপনা', 'Soybean এ বেশি পানি দিলে ফলন কমে। Light irrigation সেরা।', 'Agriculture', 'tip', NULL, 11, 130, 0, 0, 1, NULL, 'soybean', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(30, 71, 'জলপাই গাছে ফলন কম কেন?', 'Olive trees require cross-pollination. একাধিক জাত লাগানো উচিত।', 'Agriculture', 'question', NULL, 7, 110, 0, 0, 1, NULL, 'olive farming', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(31, 72, 'Groundwater কমে যাচ্ছে – কৃষিতে কী হবে?', 'Extra irrigation এ underground water কমছে। Rainwater harvesting জরুরি।', 'Agriculture', 'discussion', NULL, 16, 190, 0, 0, 1, NULL, 'irrigation crisis', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(32, 73, 'স্ট্রবেরি চাষ – নবীনদের জন্য পরামর্শ', 'Strawberry cool weather পছন্দ করে। Shade net দিলে ফলন ভালো হয়।', 'Agriculture', '', NULL, 20, 240, 0, 0, 1, NULL, 'strawberry', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(33, 49, 'মাশরুম চাষ – কিভাবে শুরু করবো?', 'মাশরুম চাষ কম জায়গায় করা যায়। Proper humidity প্রয়োজন।', 'Agriculture', 'question', NULL, 14, 175, 0, 0, 1, NULL, 'mushroom farming', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(34, 50, 'চিনা বাদাম চাষ লাভজনক?', 'চিনা বাদামের উৎপাদন খরচ কম এবং বাজারে চাহিদা বেশি।', 'Agriculture', 'discussion', NULL, 10, 120, 0, 0, 1, NULL, 'peanut', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(35, 64, 'পেয়ারা গাছে fruit fly সমস্যা', 'Fruit fly সবচেয়ে বেশি ক্ষতি করে। Bagging করলে ফলন রক্ষা করা যায়।', 'Agriculture', 'problem', NULL, 21, 230, 0, 0, 1, NULL, 'guava pests', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(36, 69, 'কাঁঠাল গাছে পুষ্টি ব্যবস্থাপনা', 'Jackfruit tree এ NPK ব্যালেন্স করলে ফলন বেশি হয়।', 'Agriculture', 'tip', NULL, 8, 105, 0, 0, 1, NULL, 'jackfruit', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(37, 70, 'কফি চাষ বাংলাদেশে সম্ভব?', 'Hill tract এ coffee garden এর সম্ভাবনা বেশি। Rainfall প্রয়োজন।', 'Agriculture', 'discussion', NULL, 17, 200, 0, 0, 1, NULL, 'coffee', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(38, 71, 'Jute Fiber এর মান কমে যাচ্ছে', 'Soil fertility কমলে পাটের মান কমে। Organic matter বাড়ানো জরুরি।', 'Agriculture', 'problem', NULL, 12, 130, 0, 0, 1, NULL, 'jute', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(39, 72, 'পুকুরে মাছ মরছে কেন?', 'Oxygen কমে গেলে sudden fish death হয়। Aerator ব্যবহার করা উচিত।', 'Agriculture', 'question', NULL, 15, 190, 0, 0, 1, NULL, 'fish oxygen', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(40, 73, 'পোল্ট্রি ফিড কিভাবে তৈরি করবো?', 'Locally maize, soybean meal, rice polish দিয়ে feed তৈরি করা যায়।', 'Agriculture', 'tip', NULL, 10, 140, 0, 0, 1, NULL, 'poultry', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(41, 49, 'তরমুজে virus attack', 'Watermelon mosaic virus এ পাতায় দাগ পড়ে এবং ফল নষ্ট হয়। Resistant variety লাগানো ভালো।', 'Agriculture', 'problem', NULL, 9, 100, 0, 0, 1, NULL, 'watermelon virus', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(42, 50, 'পেঁপে গাছ male হয়ে যাচ্ছে', 'Some papaya trees turn male. Hybrid seeds ব্যবহার করলে female tree বেশি পাওয়া যায়।', 'Agriculture', 'question', NULL, 11, 130, 0, 0, 1, NULL, 'papaya', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(43, 64, 'যান্ত্রিক কৃষিকাজে খরচ কমানোর উপায়', 'Mini tiller এবং power weeder ব্যবহার করলে cost কমে এবং সময় বাঁচে।', 'Agriculture', '', NULL, 18, 210, 0, 0, 1, NULL, 'mechanized farming', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(44, 69, 'বাঁধাকপিতে পোকা কমানোর উপায়', 'Cabbage moth trap ব্যবহার করলে pest অনেক কমে যায়।', 'Agriculture', 'tip', NULL, 14, 160, 0, 0, 1, NULL, 'cabbage pest', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(45, 70, 'ড্রাগন ফল চাষ – কতটা লাভজনক?', 'Dragon fruit কম যত্নে বেশি ফল দেয়। বাজারে high demand।', 'Agriculture', '', NULL, 22, 280, 0, 1, 1, NULL, 'dragon fruit', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(46, 71, 'Tea Garden setup cost in Bangladesh', 'চা বাগান স্থাপনে জমি প্রস্তুতি, irrigation, fencing মিলিয়ে খরচ বেশি। Long term investment।', 'Agriculture', 'discussion', NULL, 15, 190, 0, 0, 1, NULL, 'tea garden', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(47, 72, 'মধু উৎপাদন – মৌমাছি পালন টিপস', 'Mustard field এ bee box রাখলে মধু উৎপাদন বাড়ে।', 'Agriculture', 'tip', NULL, 20, 240, 0, 0, 1, NULL, 'honey', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(48, 73, 'Agro Startup Idea Needed', 'কৃষিভিত্তিক নতুন business idea চাই—hydroponics, fish feed factory etc.', 'Agriculture', 'question', NULL, 18, 220, 0, 0, 1, NULL, 'agro startup', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(49, 49, 'হাইড্রোপনিক চাষ – Beginner Guide', 'Soil ছাড়া nutrient water এ সবজি চাষ করা যায়। High yield but high setup cost।', 'Agriculture', '', NULL, 23, 260, 0, 0, 1, NULL, 'hydroponic', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(50, 50, 'ধান কাটার পর জমি প্রস্তুতি', 'Straw clean করে deep tilling করলে পরের ফসল ভালো হয়।', 'Agriculture', 'tip', NULL, 13, 170, 0, 0, 1, NULL, 'land preparation', '2026-01-15 11:42:23', '2026-01-15 11:42:23'),
(51, 49, 'শীতকালীন সবজি চাষ – সম্পূর্ণ অভিজ্ঞতা', 'এই বছর প্রথমবার শীতকালীন সবজি চাষ করেছি। মাটি ভালোভাবে চাষ দিয়ে গোবর সার মিশিয়েছি। প্রতিটি bed এ ৩০-৪০ সেমি দূরত্বে চারা লাগিয়েছি। সেচ কম লাগে, তবে আগাছা দ্রুত পরিষ্কার করতে হয়। নতুন চাষিদের জন্য এটি খুবই লাভজনক।', 'Agriculture', '', NULL, 20, 210, 0, 0, 1, NULL, 'winter vegetables, fertilizer', '2026-01-15 11:42:23', '2026-01-15 11:42:23');

-- --------------------------------------------------------

--
-- Table structure for table `content_reports`
--

CREATE TABLE `content_reports` (
  `report_id` int(11) NOT NULL,
  `content_type` enum('post','comment','product','user','message','review') NOT NULL,
  `content_id` int(11) NOT NULL,
  `reporter_id` int(11) NOT NULL,
  `report_reason` enum('spam','inappropriate','harassment','fraud','copyright','misinformation','violence','hate_speech','other') NOT NULL,
  `report_details` text DEFAULT NULL,
  `evidence_urls` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`evidence_urls`)),
  `status` enum('pending','reviewing','resolved','dismissed','escalated') DEFAULT 'pending',
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `assigned_to` int(11) DEFAULT NULL,
  `resolution` text DEFAULT NULL,
  `action_taken` enum('none','warning','content_edited','content_removed','user_warned','user_suspended','user_banned') DEFAULT 'none',
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `course_pricing_history`
--

CREATE TABLE `course_pricing_history` (
  `history_id` bigint(20) UNSIGNED NOT NULL,
  `course_id` varchar(20) NOT NULL,
  `price` decimal(8,2) UNSIGNED NOT NULL DEFAULT 0.00,
  `original_price` decimal(8,2) UNSIGNED DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'USD',
  `is_free` tinyint(1) NOT NULL DEFAULT 0,
  `changed_by` varchar(255) NOT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `crop_activities`
--

CREATE TABLE `crop_activities` (
  `activity_id` int(11) NOT NULL,
  `crop_id` int(11) NOT NULL,
  `activity_type` enum('planting','irrigation','fertilization','pesticide','weeding','harvesting','other') NOT NULL,
  `activity_date` date NOT NULL,
  `description` text DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  `quantity` varchar(50) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `crop_data`
--

CREATE TABLE `crop_data` (
  `crop_id` int(11) NOT NULL,
  `farmer_id` int(11) NOT NULL,
  `crop_name` varchar(100) NOT NULL,
  `crop_type` varchar(100) DEFAULT NULL COMMENT 'e.g., grain, vegetable, fruit',
  `variety` varchar(100) DEFAULT NULL,
  `planting_date` date DEFAULT NULL,
  `planted_date` date DEFAULT NULL,
  `expected_harvest` date DEFAULT NULL,
  `actual_harvest_date` date DEFAULT NULL,
  `area` decimal(10,2) DEFAULT NULL COMMENT 'in acres',
  `area_hectares` decimal(10,2) DEFAULT NULL,
  `field_location` varchar(255) DEFAULT NULL,
  `status` enum('planning','growing','harvesting','harvested','completed','failed') DEFAULT 'planning',
  `expected_yield` decimal(10,2) DEFAULT NULL,
  `actual_yield` decimal(10,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `crop_data`
--

INSERT INTO `crop_data` (`crop_id`, `farmer_id`, `crop_name`, `crop_type`, `variety`, `planting_date`, `planted_date`, `expected_harvest`, `actual_harvest_date`, `area`, `area_hectares`, `field_location`, `status`, `expected_yield`, `actual_yield`, `notes`, `created_at`, `updated_at`) VALUES
(45, 50, 'Rice', NULL, 'xxxx', NULL, '2026-01-08', '2026-01-30', NULL, NULL, 3.00, NULL, 'growing', NULL, NULL, NULL, '2026-01-11 10:41:26', '2026-01-11 10:41:26'),
(46, 64, 'Rice', NULL, 'dfdf', NULL, '2026-01-01', '2026-01-30', NULL, NULL, 33.00, NULL, 'growing', NULL, NULL, NULL, '2026-01-11 14:22:07', '2026-01-11 14:22:07'),
(49, 75, 'Wheat', NULL, 'Soft Red', NULL, '2026-01-15', '2026-01-30', NULL, NULL, 10.00, NULL, 'planning', NULL, NULL, NULL, '2026-01-15 12:12:09', '2026-01-15 12:12:09');

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_widgets`
--

CREATE TABLE `dashboard_widgets` (
  `widget_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `widget_type` varchar(50) NOT NULL,
  `widget_name` varchar(100) DEFAULT NULL,
  `position_x` int(11) DEFAULT 0,
  `position_y` int(11) DEFAULT 0,
  `width` int(11) DEFAULT 1,
  `height` int(11) DEFAULT 1,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `is_visible` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `disease_library`
--

CREATE TABLE `disease_library` (
  `disease_id` int(11) NOT NULL,
  `disease_name` varchar(100) NOT NULL,
  `disease_name_bn` varchar(100) DEFAULT NULL,
  `common_name` varchar(100) DEFAULT NULL,
  `scientific_name` varchar(255) DEFAULT NULL,
  `affected_crops` text DEFAULT NULL,
  `symptoms` text DEFAULT NULL,
  `causes` text DEFAULT NULL,
  `prevention` text DEFAULT NULL,
  `treatment` text DEFAULT NULL,
  `organic_treatment` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `severity_level` enum('low','medium','high') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `disease_library`
--

INSERT INTO `disease_library` (`disease_id`, `disease_name`, `disease_name_bn`, `common_name`, `scientific_name`, `affected_crops`, `symptoms`, `causes`, `prevention`, `treatment`, `organic_treatment`, `image_url`, `severity_level`, `created_at`, `updated_at`) VALUES
(1, 'Blast', 'ধানের বিস্ট রোগ', 'Rice Blast', 'Magnaporthe grisea', 'Rice', 'Spindle-shaped lesions on leaves, stem, and panicles. Gray-colored lesions with dark borders.', 'Fungal infection. High humidity and nitrogen-rich soil promote disease.', 'Use resistant varieties, proper spacing, avoid excess nitrogen, ensure good drainage.', 'Apply carbendazim or propiconazole fungicide at early stages.', 'Use Bacillus subtilis bioagent, neem oil spray, sulfur dust.', NULL, 'high', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(2, 'Brown Spot', 'বাদামী দাগ রোগ', 'Rice Brown Spot', 'Bipolaris oryzae', 'Rice', 'Brown circular lesions on leaves, starting from leaf tips. Concentric rings visible.', 'Fungal infection, poor seed quality, nutrient deficiency, especially zinc.', 'Use quality seeds, apply zinc sulfate, maintain proper spacing, ensure good drainage.', 'Apply mancozeb or carbendazim fungicide. Use zinc sulfate solution.', 'Apply Trichoderma bioagent, neem oil, and increase zinc application.', NULL, 'medium', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(3, 'Sheath Blight', 'পাতার আবরণ পচা রোগ', 'Rice Sheath Blight', 'Rhizoctonia solani', 'Rice', 'Elliptical lesions on leaf sheath. White mycelium growth. Causes panicle sterility.', 'Fungal infection promoted by high humidity, excess nitrogen, and poor drainage.', 'Reduce nitrogen fertilizer, improve drainage, use resistant varieties, proper spacing.', 'Apply carbendazim or tricyclazole fungicide. Reduce irrigation frequency.', 'Use Bacillus subtilis, Pseudomonas bioagent. Apply botanical fungicides.', NULL, 'high', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(4, 'Powdery Mildew', 'সাদা গুঁড়ো রোগ', 'Powdery Mildew', 'Erysiphe species', 'Wheat, Vegetables', 'White powder-like coating on leaves. Yellowing of affected leaves. Leaf distortion.', 'Fungal infection favored by warm days, cool nights, and low humidity.', 'Ensure good air circulation, avoid overhead irrigation, use resistant varieties.', 'Apply sulfur dust or potassium bicarbonate spray. Use carbendazim.', 'Apply sulfur dust, neem oil, or potassium bicarbonate spray.', NULL, 'low', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(5, 'Leaf Spot', 'পাতায় দাগ রোগ', 'Various Leaf Spots', 'Alternaria, Cercospora species', 'Vegetables, Crops', 'Circular or angular spots on leaves. Brown or grayish necrotic tissue.', 'Fungal or bacterial infections. Poor air circulation and excess moisture promote disease.', 'Remove infected leaves, improve air circulation, avoid overhead irrigation, use resistant varieties.', 'Apply copper fungicide or mancozeb. Remove severely infected leaves.', 'Use Bacillus subtilis, remove infected plant parts, apply neem oil.', NULL, 'medium', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(6, 'Early Blight', 'প্রাথমিক ধ্বসা রোগ', 'Tomato Early Blight', 'Alternaria solani', 'Tomato', 'Circular lesions with concentric rings on older leaves. Brown spots with yellow halos.', 'Fungal infection spread by spores. Favored by warm, humid weather.', 'Remove lower leaves, ensure good air circulation, mulch soil, use resistant varieties.', 'Apply mancozeb or chlorothalonil fungicide. Remove infected leaves.', 'Use Bacillus subtilis, remove infected parts, apply copper fungicide.', NULL, 'medium', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(7, 'Late Blight', 'দেরিতে আসা ধ্বসা রোগ', 'Tomato Late Blight', 'Phytophthora infestans', 'Tomato, Potato', 'Water-soaked lesions on leaves and stems. White mold on undersides. Fruit rot.', 'Fungal infection favored by cool, wet weather with high humidity.', 'Use resistant varieties, avoid overhead irrigation, ensure good drainage, remove infected plants.', 'Apply carbendazim or metalaxyl fungicide immediately upon detection.', 'Use Bacillus subtilis, remove infected plants, apply copper sulfate.', NULL, 'high', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(8, 'Bacterial Wilt', 'ব্যাকটেরিয়াল ঢলে পড়া', 'Bacterial Wilt', 'Ralstonia solanacearum', 'Tomato, Potato, Vegetables', 'Sudden wilting of plants without yellowing. Brown discoloration in vascular tissue.', 'Bacterial infection spread through soil and contaminated tools. Survives in soil.', 'Use resistant varieties, practice crop rotation, disinfect tools, avoid waterlogging.', 'No chemical cure. Remove and destroy infected plants. Use resistant varieties.', 'Remove infected plants, disinfect soil, use resistant varieties, practice rotation.', NULL, 'high', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(9, 'Mosaic Virus', 'মোজাইক ভাইরাস', 'Plant Mosaic Virus', 'Various Virus species', 'Vegetables, Crops', 'Mottled or mosaic pattern on leaves. Yellowing, distortion, and stunting of plants.', 'Viral infection spread by aphids and other insects. Contaminated tools can spread.', 'Control insect vectors, use resistant varieties, remove infected plants, disinfect tools.', 'Remove infected plants immediately. Control insect vectors with insecticides.', 'Remove infected plants, control aphids with neem oil, plant resistant varieties.', NULL, 'high', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(10, 'Rust', 'মরিচা রোগ', 'Crop Rust', 'Puccinia species', 'Wheat, Vegetables', 'Small rust-colored pustules on leaf undersides. Yellow spots on upper surface.', 'Fungal infection favored by cool, humid weather. Spores spread by wind.', 'Use resistant varieties, ensure good air circulation, avoid excess nitrogen.', 'Apply sulfur dust or propiconazole fungicide at early stages.', 'Apply sulfur dust, neem oil, and Bacillus subtilis bioagent.', NULL, 'medium', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(11, 'Anthracnose', 'অ্যানথ্রাকনোজ রোগ', 'Anthracnose', 'Colletotrichum species', 'Pepper, Vegetables', 'Circular lesions with dark centers on leaves and fruits. Pink spore masses.', 'Fungal infection favored by warm, wet weather. Spread by water splash.', 'Ensure good drainage, remove infected fruits, avoid overhead watering, use resistant varieties.', 'Apply copper fungicide or thiram. Remove infected plant parts.', 'Use neem oil, copper sulfate, and remove infected parts.', NULL, 'medium', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(12, 'Damping Off', 'গাছের শুকিয়ে পড়া', 'Damping Off', 'Pythium, Rhizoctonia', 'All Crops', 'Young seedlings collapse near soil line. Seedlings wilt and die.', 'Fungal infection in nursery beds. Caused by poor drainage and high moisture.', 'Use sterile soil, proper drainage, avoid overwatering, ensure good air circulation.', 'Treat seeds with fungicide. Improve nursery management.', 'Apply Trichoderma treatment, use well-drained soil, reduce watering.', NULL, 'high', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(13, 'Leaf Miner', 'পাতার খোদাইকারী', 'Leaf Miner Damage', 'Various Leaf Miner species', 'Vegetables', 'Winding tunnels and blotches on leaves. Transparent patches.', 'Insect pest that mines inside leaves. Reduced photosynthesis capacity.', 'Remove infected leaves, use netting, crop rotation, remove host plants nearby.', 'Spray malathion or acetamiprid insecticide. Remove affected leaves.', 'Use neem oil, remove infected leaves, practice crop rotation.', NULL, 'low', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(14, 'Aphids', 'জাসিড', 'Aphid Infestation', 'Aphididae family', 'All Vegetables', 'Curled, yellowing leaves. Sticky honeydew on plants. Stunted growth.', 'Insect pest that sucks plant sap. Spreads viruses.', 'Use resistant varieties, spray with water, use yellow sticky traps, encourage natural predators.', 'Spray insecticide. Use neem oil or pyrethrin.', 'Spray neem oil, insecticidal soap, encourage ladybugs, use reflective mulch.', NULL, 'medium', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(15, 'Whitefly', 'সাদা মাছি', 'Whitefly Infestation', 'Bemisia tabaci', 'Tomato, Vegetables', 'Yellowing and wilting of leaves. White insects on leaf undersides. Sooty mold.', 'Insect pest feeding on phloem sap. Rapid multiplication in warm weather.', 'Use yellow sticky traps, introduce beneficial insects, remove weeds, proper ventilation.', 'Spray insecticide. Use neem oil or yellow sticky traps.', 'Use neem oil, yellow sticky traps, insecticidal soap, encourage parasitoids.', NULL, 'medium', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(16, 'Fruit Fly', 'ফল উড়াল', 'Fruit Fly', 'Bactrocera species', 'Fruits', 'Infested fruits have small holes. Larval damage inside fruits. Rotting.', 'Insect pest that lays eggs in developing fruits. Larvae feed inside.', 'Use fruit bagging, remove fallen fruits, use pheromone traps, sanitation.', 'Apply spinosad or malathion. Use pheromone traps.', 'Use pheromone traps, remove infested fruits, neem oil spray.', NULL, 'high', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(17, 'Stem Borer', 'কান্ড ছেদকারী', 'Stem Borer', 'Chilo partellus', 'Rice, Corn', 'Entry holes in stems. Wilting of tillers. Deadheart formation.', 'Insect pest whose larvae bore inside plant stems. Causes total crop loss if severe.', 'Remove infested tillers, use pheromone traps, plant early, crop rotation.', 'Apply insecticide. Use pheromone traps and biopesticides.', 'Use pheromone traps, Trichogramma parasitoids, neem oil.', NULL, 'high', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(18, 'Slug & Snail', 'শামুক ও স্লাগ', 'Slug & Snail Damage', 'Limax, Achatina', 'Vegetables, Seedlings', 'Irregular holes in leaves. Slimy trails on plants. Seedling destruction.', 'Mollusk pests that feed on leaf tissue. Active in wet conditions.', 'Remove debris, reduce moisture, use beer traps, remove by hand, use copper barriers.', 'Metaldehyde pellets or slug bait. Hand picking effective.', 'Hand picking, beer traps, copper barriers, diatomaceous earth.', NULL, 'low', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(19, 'Caterpillar', 'শুঁয়োপোকা', 'Caterpillar Damage', 'Noctuidae, Pieridae', 'Vegetables, Cabbage', 'Ragged holes in leaves. Defoliation. Fecal pellets on plants.', 'Lepidopteran insect larvae that feed on leaves. Can cause severe damage.', 'Remove affected leaves, use Bt (Bacillus thuringiensis), crop rotation, hand-picking.', 'Spray spinosad or malathion. Use Bacillus thuringiensis spray.', 'Use Bacillus thuringiensis, neem oil, hand-picking, beneficial insects.', NULL, 'medium', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(20, 'Gall Midge', 'গল মিজ', 'Gall Midge', 'Mayetiola species', 'Rice', 'Small gall-like swellings on rice leaves. Discolored patches.', 'Dipteran pest whose larvae feed on leaf tissue causing galls.', 'Use resistant varieties, proper spacing, optimize fertilizer, remove alternate hosts.', 'Apply carbofuran or carbaryl insecticide at boot stage.', 'Use resistant varieties, remove alternate hosts, biological control agents.', NULL, 'medium', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(21, 'Grain Moth', 'শস্য পোকা', 'Grain Moth', 'Sitotroga cerealella', 'Rice, Grains', 'Holes in grain. Webbing inside stored grains. Grain discoloration.', 'Post-harvest pest that infests stored grains. Can destroy entire storage.', 'Proper grain drying, airtight storage, temperature control, regular inspection.', 'Use neem oil or insecticide powder on stored grains. Use pheromone traps.', 'Use neem powder, diatomaceous earth, proper drying, cold storage.', NULL, 'medium', '2025-12-18 15:02:20', '2025-12-18 15:02:20'),
(22, 'Spider Mite', 'মাকড়সা মাইট', 'Spider Mite', 'Tetranychus urticae', 'Vegetables, Cotton', 'Fine webbing on leaves. Yellow stippling. Leaf yellowing and dropping.', 'Arachnid pest that feeds on leaf tissue. Favored by hot, dry weather.', 'Increase humidity, spray water, remove weeds, use sulfur, encourage natural enemies.', 'Spray neem oil or sulfur dust. Use miticide if severe.', 'Neem oil spray, sulfur dust, increase humidity, release predatory mites.', NULL, 'medium', '2025-12-18 15:02:20', '2025-12-18 15:02:20');

-- --------------------------------------------------------

--
-- Table structure for table `disease_reports`
--

CREATE TABLE `disease_reports` (
  `detection_id` int(11) NOT NULL,
  `report_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `crop_id` int(11) DEFAULT NULL,
  `disease_name` varchar(100) DEFAULT NULL,
  `disease_type` varchar(100) DEFAULT NULL,
  `severity` enum('low','medium','high') DEFAULT 'low',
  `confidence_score` decimal(5,2) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `symptoms` text DEFAULT NULL,
  `detected_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `treatment_recommended` text DEFAULT NULL,
  `treatment_applied` text DEFAULT NULL,
  `treatment_cost` decimal(10,2) DEFAULT NULL,
  `status` enum('detected','treating','cured','failed') DEFAULT 'detected',
  `verified_by` int(11) DEFAULT NULL COMMENT 'officer user_id who verified',
  `verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `disease_reports`
--

INSERT INTO `disease_reports` (`detection_id`, `report_id`, `user_id`, `crop_id`, `disease_name`, `disease_type`, `severity`, `confidence_score`, `image_url`, `symptoms`, `detected_date`, `treatment_recommended`, `treatment_applied`, `treatment_cost`, `status`, `verified_by`, `verified_at`, `created_at`, `updated_at`) VALUES
(35, NULL, 50, 45, 'jhjfhdfd', NULL, 'medium', NULL, 'uploads/disease_reports/report_50_1768128453_0.png', 'dfndfbd\n\nAdditional notes: dfjnfjdfd', '2026-01-11 10:47:33', NULL, NULL, NULL, 'cured', NULL, NULL, '2026-01-11 10:47:33', '2026-01-11 11:17:16'),
(36, NULL, 50, 45, 'fn dnfd', NULL, 'low', NULL, NULL, 'vm dfdmfd', '2026-01-11 11:19:45', NULL, NULL, NULL, 'cured', NULL, NULL, '2026-01-11 11:19:45', '2026-01-12 08:02:23'),
(39, NULL, 64, 46, 'b b', NULL, 'low', NULL, NULL, 'nn b', '2026-01-12 08:15:37', NULL, NULL, NULL, 'cured', NULL, NULL, '2026-01-12 08:15:37', '2026-01-12 08:16:54'),
(40, NULL, 64, 46, '4544454', NULL, 'low', NULL, NULL, '4545', '2026-01-12 09:39:18', NULL, NULL, NULL, 'detected', NULL, NULL, '2026-01-12 09:39:18', '2026-01-12 09:39:18');

-- --------------------------------------------------------

--
-- Table structure for table `disease_report_responses`
--

CREATE TABLE `disease_report_responses` (
  `response_id` int(11) NOT NULL,
  `report_id` int(11) NOT NULL,
  `officer_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `recommended_action` text DEFAULT NULL,
  `status` enum('pending','reviewed','resolved') DEFAULT 'reviewed',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email_queue`
--

CREATE TABLE `email_queue` (
  `queue_id` int(11) NOT NULL,
  `to_email` varchar(255) NOT NULL,
  `to_name` varchar(255) DEFAULT NULL,
  `from_email` varchar(255) DEFAULT NULL,
  `from_name` varchar(255) DEFAULT NULL,
  `reply_to` varchar(255) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `body_text` text DEFAULT NULL,
  `body_html` text DEFAULT NULL,
  `template` varchar(100) DEFAULT NULL,
  `template_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`template_data`)),
  `attachments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attachments`)),
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `category` varchar(50) DEFAULT NULL,
  `status` enum('pending','sending','sent','failed','cancelled') DEFAULT 'pending',
  `attempts` int(11) DEFAULT 0,
  `max_attempts` int(11) DEFAULT 3,
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `scheduled_at` timestamp NULL DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `opened_at` timestamp NULL DEFAULT NULL,
  `clicked_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `error_logs`
--

CREATE TABLE `error_logs` (
  `error_id` int(11) NOT NULL,
  `error_hash` varchar(32) DEFAULT NULL,
  `error_type` varchar(100) NOT NULL,
  `error_code` varchar(50) DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `error_file` varchar(255) DEFAULT NULL,
  `error_line` int(11) DEFAULT NULL,
  `stack_trace` text DEFAULT NULL,
  `request_url` varchar(500) DEFAULT NULL,
  `request_method` varchar(10) DEFAULT NULL,
  `request_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`request_data`)),
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `severity` enum('debug','info','warning','error','critical') DEFAULT 'error',
  `occurrence_count` int(11) DEFAULT 1,
  `first_seen` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_seen` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_resolved` tinyint(1) DEFAULT 0,
  `resolved_by` int(11) DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `resolution_notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `farmer_profiles`
--

CREATE TABLE `farmer_profiles` (
  `profile_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `farm_size` decimal(10,2) DEFAULT NULL COMMENT 'in acres',
  `land_size_hectares` decimal(10,2) DEFAULT NULL,
  `experience_level` enum('beginner','intermediate','advanced') DEFAULT NULL,
  `primary_crops` varchar(255) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `sub_district` varchar(100) DEFAULT NULL,
  `village` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `location_lat` decimal(10,8) DEFAULT NULL,
  `location_lng` decimal(10,8) DEFAULT NULL,
  `farming_type` enum('organic','conventional','mixed') DEFAULT 'conventional',
  `soil_type` varchar(100) DEFAULT NULL,
  `irrigation_type` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `farmer_profiles`
--

INSERT INTO `farmer_profiles` (`profile_id`, `user_id`, `farm_size`, `land_size_hectares`, `experience_level`, `primary_crops`, `region`, `district`, `sub_district`, `village`, `address`, `location_lat`, `location_lng`, `farming_type`, `soil_type`, `irrigation_type`, `created_at`, `updated_at`) VALUES
(29, 50, NULL, 0.00, NULL, '', 'Dhaka', NULL, NULL, NULL, NULL, NULL, NULL, 'conventional', NULL, NULL, '2026-01-11 10:05:50', '2026-01-11 11:26:27'),
(30, 64, NULL, 0.00, 'beginner', '', 'Dhaka', NULL, NULL, NULL, NULL, NULL, NULL, 'conventional', NULL, NULL, '2026-01-11 11:37:01', '2026-01-11 11:37:01');

-- --------------------------------------------------------

--
-- Table structure for table `farm_tasks`
--

CREATE TABLE `farm_tasks` (
  `task_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `task_name` varchar(255) NOT NULL,
  `task_type` enum('planting','irrigation','fertilizer','pesticide','harvest','maintenance','other') DEFAULT 'other',
  `task_date` date NOT NULL,
  `task_time` time DEFAULT NULL,
  `crop` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `weather_dependent` tinyint(1) DEFAULT 1,
  `priority` enum('low','medium','high') DEFAULT 'medium',
  `status` enum('pending','in_progress','completed','cancelled') DEFAULT 'pending',
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fertilizer_recommendations`
--

CREATE TABLE `fertilizer_recommendations` (
  `recommendation_id` int(11) NOT NULL,
  `crop_id` int(11) NOT NULL,
  `recommended_by` int(11) DEFAULT NULL COMMENT 'officer user_id',
  `fertilizer_type` varchar(100) DEFAULT NULL,
  `fertilizer_name` varchar(255) DEFAULT NULL,
  `quantity_kg` decimal(10,2) DEFAULT NULL,
  `application_date` date DEFAULT NULL,
  `application_method` varchar(100) DEFAULT NULL,
  `frequency` varchar(50) DEFAULT NULL,
  `duration_days` int(11) DEFAULT NULL,
  `cost_estimate` decimal(10,2) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `benefits` text DEFAULT NULL,
  `precautions` text DEFAULT NULL,
  `is_organic` tinyint(1) DEFAULT 0,
  `status` enum('recommended','applied','declined') DEFAULT 'recommended',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `field_visits`
--

CREATE TABLE `field_visits` (
  `visit_id` int(11) NOT NULL,
  `officer_id` int(11) NOT NULL,
  `farmer_id` int(11) NOT NULL,
  `visit_date` date NOT NULL,
  `visit_time` time DEFAULT NULL,
  `purpose` text DEFAULT NULL,
  `observations` text DEFAULT NULL,
  `recommendations` text DEFAULT NULL,
  `follow_up_required` tinyint(1) DEFAULT 0,
  `follow_up_date` date DEFAULT NULL,
  `status` enum('scheduled','completed','cancelled','postponed') DEFAULT 'scheduled',
  `report_file` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `field_visits`
--

INSERT INTO `field_visits` (`visit_id`, `officer_id`, `farmer_id`, `visit_date`, `visit_time`, `purpose`, `observations`, `recommendations`, `follow_up_required`, `follow_up_date`, `status`, `report_file`, `created_at`, `updated_at`) VALUES
(6, 71, 64, '2026-01-16', '17:11:00', 'I don’t know', NULL, NULL, 0, NULL, 'scheduled', NULL, '2026-01-15 11:12:11', '2026-01-15 11:12:11'),
(7, 70, 50, '2026-01-17', '16:11:00', 'I will visit you at the mentioned time. You need to be there.', NULL, NULL, 0, NULL, 'scheduled', NULL, '2026-01-15 11:14:05', '2026-01-15 11:14:05'),
(8, 70, 69, '2026-01-16', '16:14:00', 'I will visit you at the mentioned time. You need to be there.', NULL, NULL, 0, NULL, 'scheduled', NULL, '2026-01-15 11:14:42', '2026-01-15 11:14:42');

-- --------------------------------------------------------

--
-- Table structure for table `file_uploads`
--

CREATE TABLE `file_uploads` (
  `file_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `entity_type` varchar(50) DEFAULT NULL COMMENT 'crop, disease, post, etc',
  `entity_id` int(11) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `general_users`
--

CREATE TABLE `general_users` (
  `user_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `profile_img_url` varchar(255) DEFAULT 'shop/assets/images/default-avatar.png',
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `email_verified` tinyint(1) DEFAULT 0,
  `is_verified` tinyint(1) DEFAULT 0,
  `verification_token` varchar(255) DEFAULT NULL,
  `verification_expires` datetime DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `remember_token` varchar(64) DEFAULT NULL,
  `remember_token_expires` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `general_users`
--

INSERT INTO `general_users` (`user_id`, `email`, `phone`, `password_hash`, `first_name`, `last_name`, `profile_img_url`, `address`, `city`, `district`, `postal_code`, `is_active`, `email_verified`, `is_verified`, `verification_token`, `verification_expires`, `reset_token`, `reset_token_expires`, `last_login`, `created_at`, `updated_at`, `remember_token`, `remember_token_expires`) VALUES
(1, 'tibetoc366@hidevak.com', '016222222', '$2y$10$R0RnwK3Gt4dbnPqk2QpiZOQWWzQaUTaW9xdDURDj4v11kqJBKKGVS', 'mr', 'xxxxx', 'shop/assets/images/default-avatar.png', NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, '2026-05-15 19:22:41', '2026-05-15 19:22:41', NULL, NULL),
(2, 'nifabak637@itquoted.com', '54353535', '$2y$10$u8kJr3OaDfEDacHzEmByPedSL32zLaOSuaqA4uCS.fjtvB9XtZxGi', 'MR', 'XXX', 'shop/assets/images/default-avatar.png', NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, '2026-05-15 23:36:08', '2026-05-15 20:09:40', '2026-05-15 23:36:08', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `generated_reports`
--

CREATE TABLE `generated_reports` (
  `report_id` int(11) NOT NULL,
  `report_name` varchar(255) NOT NULL,
  `report_type` enum('users','activity','security','performance','financial','content','custom') NOT NULL,
  `format` enum('pdf','csv','excel','json','html') DEFAULT 'pdf',
  `parameters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`parameters`)),
  `date_range_start` date DEFAULT NULL,
  `date_range_end` date DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `status` enum('pending','generating','completed','failed') DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `generation_time_ms` int(11) DEFAULT NULL,
  `generated_by` int(11) DEFAULT NULL,
  `generated_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `download_count` int(11) DEFAULT 0,
  `last_downloaded_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `generated_reports`
--

INSERT INTO `generated_reports` (`report_id`, `report_name`, `report_type`, `format`, `parameters`, `date_range_start`, `date_range_end`, `file_path`, `file_size`, `status`, `error_message`, `generation_time_ms`, `generated_by`, `generated_at`, `expires_at`, `download_count`, `last_downloaded_at`, `created_at`) VALUES
(4, '', '', 'pdf', '{\"date_from\":\"2025-11-30\",\"date_to\":\"2025-12-30\"}', '2025-11-30', '2025-12-30', 'C:\\xampp\\htdocs\\smartcashi/reports/2025-12/report_user_summary_2025-12-30_15-32-28.pdf.json', 1547, 'completed', NULL, NULL, 49, '2025-12-30 14:32:28', NULL, 0, NULL, '2025-12-30 14:32:28');

-- --------------------------------------------------------

--
-- Table structure for table `honeypot_logs`
--

CREATE TABLE `honeypot_logs` (
  `log_id` int(11) NOT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `field_value` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `page_url` varchar(255) DEFAULT NULL,
  `form_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `honeypot_logs`
--

INSERT INTO `honeypot_logs` (`log_id`, `field_name`, `field_value`, `ip_address`, `user_agent`, `page_url`, `form_name`, `created_at`) VALUES
(1, 'website/phone_number', 'mohatamim44|', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'http://localhost/smartcashi/admin-login', 'admin_login', '2025-12-30 08:01:10'),
(2, 'website/phone_number', 'mohatamim44|', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'http://localhost/smartcashi/admin-login', 'admin_login', '2025-12-30 08:01:48'),
(3, 'website/phone_number', 'mohatamim44|', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'http://localhost/smartcashi/admin-login', 'admin_login', '2025-12-30 08:01:52'),
(4, 'website/phone_number', 'mohatamim44|', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'http://localhost/smartcashi/admin-login', 'admin_login', '2025-12-30 08:02:55'),
(5, 'website/phone_number', 'mohatamim44|', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'http://localhost/smartcashi/admin-login', 'admin_login', '2025-12-30 08:02:59'),
(6, 'website/phone_number', 'mohatamim44|', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'http://localhost/smartcashi/admin-login', 'admin_login', '2025-12-30 08:03:45'),
(7, 'website/phone_number', 'mohatamim44|', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'http://localhost/smartcashi/admin-login', 'admin_login', '2025-12-30 08:03:48'),
(8, 'website/phone_number', 'mohatamim44|', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'http://localhost/smartcashi/admin-login', 'admin_login', '2025-12-30 08:03:53'),
(9, 'website/phone_number', 'mohatamim44|', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'http://localhost/smartcashi/admin-login', 'admin_login', '2025-12-30 08:04:21'),
(10, 'website/phone_number', 'mohatamim44|', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'http://localhost/smartcashi/admin-login', 'admin_login', '2025-12-30 08:04:25'),
(11, 'website/phone_number', 'mohatamim44|', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'http://localhost/smartcashi/admin-login', 'admin_login', '2025-12-30 08:04:27'),
(12, 'website/phone_number', 'mohatamim44|', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'http://localhost/smartcashi/admin-login', 'admin_login', '2025-12-30 08:04:32'),
(13, 'website/phone_number', 'mohatamim44|', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'http://localhost/smartcashi/admin-login', 'admin_login', '2025-12-30 08:04:39');

-- --------------------------------------------------------

--
-- Table structure for table `learn_categories`
--

CREATE TABLE `learn_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `name_bn` varchar(100) DEFAULT NULL,
  `icon` varchar(60) NOT NULL DEFAULT 'menu_book',
  `color` varchar(20) NOT NULL DEFAULT '#557A46',
  `sort_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `learn_categories`
--

INSERT INTO `learn_categories` (`id`, `name`, `name_bn`, `icon`, `color`, `sort_order`) VALUES
(1, 'Video Tutorials', 'ভিডিও টিউটোরিয়াল', 'play_circle', '#e53935', 1),
(2, 'Farming Blogs', 'কৃষি ব্লগ', 'article', '#1976d2', 2),
(3, 'Seasonal Guides', 'মৌসুমী গাইড', 'calendar_month', '#0097a7', 3),
(4, 'Expert Articles', 'বিশেষজ্ঞ নিবন্ধ', 'auto_stories', '#7b1fa2', 4),
(5, 'Live Webinars', 'লাইভ ওয়েবিনার', 'live_tv', '#f57c00', 5),
(6, 'Quizzes', 'কুইজ ও সার্টিফিকেট', 'quiz', '#388e3c', 6);

-- --------------------------------------------------------

--
-- Table structure for table `learn_certificates`
--

CREATE TABLE `learn_certificates` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL,
  `certificate_code` varchar(64) NOT NULL,
  `score` int(11) NOT NULL DEFAULT 0,
  `issued_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `learn_certificates`
--

INSERT INTO `learn_certificates` (`id`, `user_id`, `content_id`, `certificate_code`, `score`, `issued_at`) VALUES
(1, 2, 9, 'CERT-2024-U2-Q9-A1F3', 80, '2026-05-16 16:45:54'),
(2, 3, 9, 'CERT-2024-U3-Q9-B7D2', 100, '2026-05-16 16:45:54'),
(3, 4, 9, 'CERT-2024-U4-Q9-C2E8', 80, '2026-05-16 16:45:54'),
(4, 64, 9, '5553E4174893CF48', 100, '2026-05-16 17:04:58');

-- --------------------------------------------------------

--
-- Table structure for table `learn_content`
--

CREATE TABLE `learn_content` (
  `id` int(11) NOT NULL,
  `type` enum('video','playlist','blog','guide','article','webinar','quiz') NOT NULL,
  `title` varchar(255) NOT NULL,
  `title_bn` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `thumbnail_url` varchar(500) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `season` enum('all','boro','aman','aus','rabi','kharif') NOT NULL DEFAULT 'all',
  `crop_tags` varchar(500) DEFAULT NULL,
  `difficulty` enum('beginner','intermediate','advanced') NOT NULL DEFAULT 'beginner',
  `duration_min` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `views` int(11) NOT NULL DEFAULT 0,
  `content_body` longtext DEFAULT NULL,
  `youtube_url` varchar(500) DEFAULT NULL,
  `webinar_url` varchar(500) DEFAULT NULL,
  `webinar_scheduled_at` datetime DEFAULT NULL,
  `pass_score` int(11) NOT NULL DEFAULT 70,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `learn_content`
--

INSERT INTO `learn_content` (`id`, `type`, `title`, `title_bn`, `description`, `thumbnail_url`, `category_id`, `season`, `crop_tags`, `difficulty`, `duration_min`, `created_by`, `is_published`, `is_featured`, `views`, `content_body`, `youtube_url`, `webinar_url`, `webinar_scheduled_at`, `pass_score`, `created_at`, `updated_at`) VALUES
(1, 'playlist', 'xc dcvdvcddvdvd', 'xcxcx', 'xcxcxc', '', NULL, 'all', '', 'beginner', NULL, 50, 1, 1, 4, '', '', '', NULL, 70, '2026-05-16 04:39:59', '2026-05-16 05:12:24'),
(2, 'video', 'Integrated Pest Management', 'সমন্বিত বালাই ব্যবস্থাপনা', 'How to control pests without over-relying on chemicals.', 'https://img.youtube.com/vi/abc123/hqdefault.jpg', 1, 'all', 'rice,vegetable,wheat', 'intermediate', 25, 1, 1, 0, 1870, '', 'https://youtu.be/abc123', NULL, NULL, 70, '2026-05-16 16:45:02', '2026-05-16 16:45:02'),
(3, 'playlist', 'Complete Vegetable Farming Series', 'সম্পূর্ণ সবজি চাষ সিরিজ', 'A 5-part series covering land prep, sowing, irrigation, and harvest.', 'https://img.youtube.com/vi/playlist1/hqdefault.jpg', 1, 'kharif', 'tomato,brinjal,okra', 'beginner', 90, 1, 1, 1, 5210, NULL, NULL, NULL, NULL, 70, '2026-05-16 16:45:02', '2026-05-16 16:45:02'),
(4, 'blog', 'Why Organic Farming Matters', 'জৈব চাষ কেন গুরুত্বপূর্ণ', 'A detailed blog on the long-term benefits of organic practices.', NULL, 2, 'all', 'organic,soil', 'beginner', 12, 1, 1, 0, 980, '<h2>Introduction</h2><p>Organic farming reduces chemical dependency and improves soil health over time...</p><h2>Key Benefits</h2><ul><li>Better soil structure</li><li>Higher market value</li><li>Environmental sustainability</li></ul>', NULL, NULL, NULL, 70, '2026-05-16 16:45:02', '2026-05-16 16:45:02'),
(5, 'blog', 'Soil pH and Crop Yield', 'মাটির pH ও ফসলের উৎপাদন', 'How soil acidity/alkalinity directly affects your harvest.', NULL, 2, 'all', 'soil,rice,wheat', 'intermediate', 10, 1, 1, 0, 640, '<h2>What is Soil pH?</h2><p>pH measures how acidic or alkaline your soil is on a scale of 0–14...</p><h2>Ideal pH Ranges</h2><p>Rice: 5.5–6.5 | Wheat: 6.0–7.0 | Vegetables: 6.0–6.8</p>', NULL, NULL, NULL, 70, '2026-05-16 16:45:02', '2026-05-16 16:45:02'),
(6, 'guide', 'Boro Season Farming Calendar', 'বোরো মৌসুমের চাষ ক্যালেন্ডার', 'Month-by-month guide for boro paddy — from seedbed to threshing.', NULL, 3, 'boro', 'rice,paddy', 'beginner', 20, 1, 1, 1, 2100, '<h2>November</h2><p>Prepare seedbed. Use 30kg seed per hectare...</p><h2>December</h2><p>Transplant seedlings at 3–4 leaf stage...</p><h2>March</h2><p>Apply potash before flowering...</p>', NULL, NULL, NULL, 70, '2026-05-16 16:45:02', '2026-05-16 16:45:02'),
(7, 'article', 'Climate-Smart Agriculture in Bangladesh', 'বাংলাদেশে জলবায়ু-স্মার্ট কৃষি', 'Expert analysis on adapting farming to climate variability.', NULL, 4, 'all', 'climate,rice,adaptation', 'advanced', 30, 1, 1, 1, 1350, '<p>Bangladesh loses 17% of its arable land per 1°C temperature rise...</p>', NULL, NULL, NULL, 70, '2026-05-16 16:45:02', '2026-05-16 16:45:02'),
(8, 'webinar', 'Live Q&A: Flood-Tolerant Rice Varieties', 'লাইভ: বন্যা-সহিষ্ণু ধানের জাত', 'Join our agronomist for a live session on BRRI dhan52 and SwarnaSub1.', NULL, 5, 'aman', 'rice,flood', 'intermediate', 60, 1, 1, 1, 310, NULL, NULL, 'https://meet.example.com/webinar-rice', '2025-08-15 14:00:00', 70, '2026-05-16 16:45:02', '2026-05-16 16:45:02'),
(9, 'quiz', 'Fertilizer Knowledge Quiz', 'সার জ্ঞান কুইজ', 'Test your knowledge of NPK, urea, and organic fertilizers. Pass to earn a certificate!', NULL, 6, 'all', 'fertilizer,soil', 'beginner', 15, 1, 1, 0, 783, NULL, NULL, NULL, NULL, 80, '2026-05-16 16:45:02', '2026-05-16 17:05:18'),
(10, 'video', 'Paddy Cultivation Basics', 'ধান চাষের মূল বিষয়', 'Step-by-step guide to paddy cultivation for beginners.', 'https://img.youtube.com/vi/dQw4w9WgXcQ/hqdefault.jpg', 1, 'boro', 'rice,paddy', 'beginner', 18, 1, 1, 1, 3420, '', 'https://youtu.be/dQw4w9WgXcQ', NULL, NULL, 70, '2026-05-16 16:45:02', '2026-05-16 16:45:02');

-- --------------------------------------------------------

--
-- Table structure for table `learn_likes`
--

CREATE TABLE `learn_likes` (
  `user_id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL,
  `liked_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `learn_likes`
--

INSERT INTO `learn_likes` (`user_id`, `content_id`, `liked_at`) VALUES
(2, 1, '2026-05-16 16:45:54'),
(2, 6, '2026-05-16 16:45:54'),
(2, 7, '2026-05-16 16:45:54'),
(3, 1, '2026-05-16 16:45:54'),
(3, 3, '2026-05-16 16:45:54'),
(3, 6, '2026-05-16 16:45:54'),
(3, 8, '2026-05-16 16:45:54'),
(4, 4, '2026-05-16 16:45:54'),
(4, 5, '2026-05-16 16:45:54'),
(4, 7, '2026-05-16 16:45:54');

-- --------------------------------------------------------

--
-- Table structure for table `learn_paths`
--

CREATE TABLE `learn_paths` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `crop_focus` varchar(100) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `learn_paths`
--

INSERT INTO `learn_paths` (`id`, `title`, `description`, `crop_focus`, `created_by`, `is_published`, `created_at`) VALUES
(1, 'Beginner Paddy Farmer Path', 'A curated 4-step learning path for first-time paddy farmers.', 'rice', 1, 1, '2026-05-16 16:45:54'),
(2, 'Vegetable Farming Starter Kit', 'Everything a new vegetable farmer needs — blogs, videos, and a quiz.', 'vegetables', 1, 1, '2026-05-16 16:45:54');

-- --------------------------------------------------------

--
-- Table structure for table `learn_path_items`
--

CREATE TABLE `learn_path_items` (
  `id` int(11) NOT NULL,
  `path_id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `learn_path_items`
--

INSERT INTO `learn_path_items` (`id`, `path_id`, `content_id`, `sort_order`) VALUES
(1, 1, 6, 1),
(2, 1, 1, 2),
(3, 1, 2, 3),
(4, 1, 9, 4),
(5, 2, 3, 1),
(6, 2, 4, 2),
(7, 2, 5, 3),
(8, 2, 9, 4);

-- --------------------------------------------------------

--
-- Table structure for table `learn_playlist_items`
--

CREATE TABLE `learn_playlist_items` (
  `id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `youtube_url` varchar(500) NOT NULL,
  `duration_min` int(11) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `learn_playlist_items`
--

INSERT INTO `learn_playlist_items` (`id`, `content_id`, `title`, `youtube_url`, `duration_min`, `sort_order`) VALUES
(1, 3, 'Part 1 – Land Preparation', 'https://youtu.be/veg001', 15, 1),
(2, 3, 'Part 2 – Seed Selection & Sowing', 'https://youtu.be/veg002', 18, 2),
(3, 3, 'Part 3 – Irrigation Techniques', 'https://youtu.be/veg003', 20, 3),
(4, 3, 'Part 4 – Fertilizer Application', 'https://youtu.be/veg004', 17, 4),
(5, 3, 'Part 5 – Harvesting & Storage', 'https://youtu.be/veg005', 20, 5),
(6, 3, 'Part 1 – Land Preparation', 'https://youtu.be/veg001', 15, 1),
(7, 3, 'Part 2 – Seed Selection & Sowing', 'https://youtu.be/veg002', 18, 2),
(8, 3, 'Part 3 – Irrigation Techniques', 'https://youtu.be/veg003', 20, 3),
(9, 3, 'Part 4 – Fertilizer Application', 'https://youtu.be/veg004', 17, 4),
(10, 3, 'Part 5 – Harvesting & Storage', 'https://youtu.be/veg005', 20, 5);

-- --------------------------------------------------------

--
-- Table structure for table `learn_progress`
--

CREATE TABLE `learn_progress` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT 0,
  `last_accessed` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `learn_progress`
--

INSERT INTO `learn_progress` (`id`, `user_id`, `content_id`, `completed`, `last_accessed`) VALUES
(1, 50, 1, 0, '2026-05-16 04:40:14'),
(3, 49, 1, 0, '2026-05-16 05:12:25'),
(5, 2, 1, 1, '2026-05-16 16:45:54'),
(6, 2, 6, 1, '2026-05-16 16:45:54'),
(7, 2, 9, 0, '2026-05-16 16:45:54'),
(8, 3, 1, 1, '2026-05-16 16:45:54'),
(9, 3, 2, 1, '2026-05-16 16:45:54'),
(10, 3, 3, 0, '2026-05-16 16:45:54'),
(11, 3, 6, 1, '2026-05-16 16:45:54'),
(12, 4, 3, 0, '2026-05-16 16:45:54'),
(13, 4, 4, 1, '2026-05-16 16:45:54'),
(14, 4, 5, 1, '2026-05-16 16:45:54'),
(15, 64, 9, 1, '2026-05-16 17:05:18');

-- --------------------------------------------------------

--
-- Table structure for table `learn_quiz_attempts`
--

CREATE TABLE `learn_quiz_attempts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL,
  `score` int(11) NOT NULL DEFAULT 0,
  `total` int(11) NOT NULL DEFAULT 0,
  `passed` tinyint(1) NOT NULL DEFAULT 0,
  `attempted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `learn_quiz_attempts`
--

INSERT INTO `learn_quiz_attempts` (`id`, `user_id`, `content_id`, `score`, `total`, `passed`, `attempted_at`) VALUES
(1, 2, 9, 4, 5, 1, '2026-05-16 16:45:54'),
(2, 3, 9, 3, 5, 0, '2026-05-16 16:45:54'),
(3, 3, 9, 5, 5, 1, '2026-05-16 16:45:54'),
(4, 4, 9, 4, 5, 1, '2026-05-16 16:45:54'),
(5, 64, 9, 100, 5, 1, '2026-05-16 17:04:58');

-- --------------------------------------------------------

--
-- Table structure for table `learn_quiz_options`
--

CREATE TABLE `learn_quiz_options` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `option_text` text NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `learn_quiz_options`
--

INSERT INTO `learn_quiz_options` (`id`, `question_id`, `option_text`, `is_correct`) VALUES
(1, 1, 'Nitrogen', 1),
(2, 1, 'Neon', 0),
(3, 1, 'Nickel', 0),
(4, 1, 'Nitrate only', 0),
(5, 2, 'Triple Super Phosphate', 0),
(6, 2, 'Muriate of Potash', 0),
(7, 2, 'Urea', 1),
(8, 2, 'Gypsum', 0),
(9, 3, '5:10:5', 0),
(10, 3, '20:5:5', 1),
(11, 3, '10:10:10', 0),
(12, 3, '0:20:10', 0),
(13, 4, 'Fruit colour', 0),
(14, 4, 'Root development', 1),
(15, 4, 'Water absorption', 0),
(16, 4, 'Leaf thickness', 0),
(17, 5, 'Faster ripening', 0),
(18, 5, 'Increased grain size', 0),
(19, 5, 'Root burn and lodging risk', 1),
(20, 5, 'Better drought resistance', 0),
(21, 1, 'Nitrogen', 1),
(22, 1, 'Neon', 0),
(23, 1, 'Nickel', 0),
(24, 1, 'Nitrate only', 0),
(25, 2, 'Triple Super Phosphate', 0),
(26, 2, 'Muriate of Potash', 0),
(27, 2, 'Urea', 1),
(28, 2, 'Gypsum', 0),
(29, 3, '5:10:5', 0),
(30, 3, '20:5:5', 1),
(31, 3, '10:10:10', 0),
(32, 3, '0:20:10', 0),
(33, 4, 'Fruit colour', 0),
(34, 4, 'Root development', 1),
(35, 4, 'Water absorption', 0),
(36, 4, 'Leaf thickness', 0),
(37, 5, 'Faster ripening', 0),
(38, 5, 'Increased grain size', 0),
(39, 5, 'Root burn and lodging risk', 1),
(40, 5, 'Better drought resistance', 0);

-- --------------------------------------------------------

--
-- Table structure for table `learn_quiz_questions`
--

CREATE TABLE `learn_quiz_questions` (
  `id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL,
  `question` text NOT NULL,
  `explanation` text DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `learn_quiz_questions`
--

INSERT INTO `learn_quiz_questions` (`id`, `content_id`, `question`, `explanation`, `sort_order`) VALUES
(1, 9, 'What does \"N\" stand for in NPK fertilizer?', 'N = Nitrogen, which is essential for leaf and stem growth.', 1),
(2, 9, 'Which fertilizer is the main source of Nitrogen in Bangladesh?', 'Urea contains 46% Nitrogen and is the most widely used N fertilizer.', 2),
(3, 9, 'What is the ideal NPK ratio for a rice crop at tillering stage?', 'High Nitrogen at tillering supports maximum tiller production.', 3),
(4, 9, 'Phosphorus (P) is most important for which plant function?', 'Phosphorus is critical for root development and energy transfer (ATP).', 4),
(5, 9, 'Applying too much urea can cause which of the following?', 'Excess urea burns roots and makes plants susceptible to lodging and pest attack.', 5);

-- --------------------------------------------------------

--
-- Table structure for table `marketplace_orders`
--

CREATE TABLE `marketplace_orders` (
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `delivery_address` text DEFAULT NULL,
  `payment_method` enum('cash','bkash','nagad','bank','other') DEFAULT 'cash',
  `order_status` enum('pending','confirmed','delivered','cancelled') DEFAULT 'pending',
  `payment_status` enum('pending','paid','refunded') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `marketplace_orders`
--

INSERT INTO `marketplace_orders` (`order_id`, `product_id`, `seller_id`, `buyer_id`, `quantity`, `total_price`, `delivery_address`, `payment_method`, `order_status`, `payment_status`, `notes`, `created_at`, `updated_at`) VALUES
(3, 7, 73, 72, 20, 600.00, 'Gazipur', 'cash', 'cancelled', 'pending', 'Products jeno vlo hoy', '2026-01-15 11:45:50', '2026-01-15 11:52:33');

-- --------------------------------------------------------

--
-- Table structure for table `marketplace_products`
--

CREATE TABLE `marketplace_products` (
  `product_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_type` enum('crop','seed','fertilizer','equipment','service','other') DEFAULT 'crop',
  `category` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `price_unit` varchar(20) DEFAULT 'kg',
  `quantity_available` int(11) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `quality_grade` enum('A','B','C','standard') DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `images` text DEFAULT NULL COMMENT 'JSON array of image URLs',
  `contact_phone` varchar(20) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `status` enum('available','sold','pending','expired') DEFAULT 'available',
  `views` int(11) DEFAULT 0,
  `is_featured` tinyint(1) DEFAULT 0,
  `is_verified` tinyint(1) DEFAULT 0,
  `verified_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_negotiable` tinyint(1) DEFAULT 1,
  `min_order_quantity` int(11) DEFAULT 1,
  `bulk_discount_percent` decimal(5,2) DEFAULT NULL,
  `bulk_min_quantity` int(11) DEFAULT NULL,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `review_count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `marketplace_products`
--

INSERT INTO `marketplace_products` (`product_id`, `seller_id`, `product_name`, `product_type`, `category`, `description`, `price`, `price_unit`, `quantity_available`, `unit`, `quality_grade`, `location`, `district`, `region`, `image_url`, `images`, `contact_phone`, `contact_email`, `status`, `views`, `is_featured`, `is_verified`, `verified_by`, `created_at`, `updated_at`, `expires_at`, `is_negotiable`, `min_order_quantity`, `bulk_discount_percent`, `bulk_min_quantity`, `average_rating`, `review_count`) VALUES
(5, 72, 'Potato', 'crop', 'Vegetables', 'Freshly harvest potato', 15.00, 'kg', 500, 'kg', 'A', 'Gazipur', '', 'Dhaka', 'public/uploads/products/product_72_1768477018.jpg', NULL, '01855512505', '', 'available', 1, 0, 0, NULL, '2026-01-15 11:36:58', '2026-05-16 04:47:46', NULL, 1, 10, 10.00, 100, 0.00, 0),
(6, 72, 'Prawn', 'other', 'Others', 'Best prawn in the market', 800.00, 'kg', 100, 'kg', 'A', 'Gazipur', '', 'Dhaka', 'public/uploads/products/product_72_1768477306.jpg', NULL, '01855512505', '', 'available', 0, 0, 0, NULL, '2026-01-15 11:41:46', '2026-01-15 11:41:46', NULL, 1, 10, 5.00, 50, 0.00, 0),
(7, 73, 'Tomatoes 🍅', 'other', 'Vegetables', 'Good condition tomatoes 🍅', 30.00, 'kg', 20, 'kg', 'standard', 'Gazipur, Dhaka', '', 'Dhaka', 'public/uploads/products/product_73_1768477315.jpeg', NULL, '01770459590', '', 'available', 3, 0, 0, NULL, '2026-01-15 11:41:55', '2026-05-15 23:54:20', NULL, 1, 1, NULL, NULL, 0.00, 0),
(8, 69, 'ফুলকপি', 'crop', 'Vegetables', 'আমাদের খামারের তাজা ও স্বাস্থ্যকর ফুলকপি বিক্রয় করা হচ্ছে। \r\nসরাসরি ক্ষেত থেকে সংগ্রহ করা, কোনো কেমিক্যাল ফ্রেশনার ব্যবহার করা হয়নি।\r\nবড় অর্ডারে বিশেষ ছাড় প্রদান করা হবে। \r\nঢাকা ও আশপাশের এলাকায় দ্রুত ডেলিভারি দেওয়া সম্ভব।', 10.00, 'kg', 500, 'kg', 'standard', 'Mirsarai,Chittagong', '', 'Chittagong', 'public/uploads/products/product_69_1768477773.webp', NULL, '01867568689', '', 'available', 0, 0, 0, NULL, '2026-01-15 11:49:33', '2026-01-15 11:49:33', NULL, 1, 5, 10.00, 30, 0.00, 0),
(9, 72, 'Jambo prawn', 'other', 'Others', 'Very good quality prawn', 900.00, 'kg', 500, 'kg', 'standard', 'Gazipur', '', 'Dhaka', 'public/uploads/products/product_72_1768477923.jpg', NULL, '01855512505', '', 'available', 23, 0, 0, NULL, '2026-01-15 11:52:03', '2026-05-16 04:46:17', NULL, 1, 1, 10.00, 100, 5.00, 1),
(10, 64, 'Rice', 'crop', 'Seeds', 'Lorem Ipsum is a standard placeholder or \"dummy\" text used in the graphic design, printing, and publishing industries. It is used to demonstrate the visual layout of a document or typeface without the distraction of meaningful content.', 80.00, 'kg', 100, 'kg', 'A', 'Dinajpur', '', 'Dhaka', 'uploads/marketplace/product_10_1768498409.jpg', NULL, '017233633764', '', 'available', 0, 0, 0, NULL, '2026-01-15 17:32:47', '2026-01-15 17:33:29', NULL, 1, 20, 20.00, NULL, 0.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `market_prices`
--

CREATE TABLE `market_prices` (
  `price_id` int(11) NOT NULL,
  `crop_name` varchar(100) NOT NULL,
  `crop_type` varchar(100) DEFAULT NULL,
  `variety` varchar(100) DEFAULT NULL,
  `market_location` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `price_per_unit` decimal(10,2) NOT NULL,
  `unit_type` varchar(20) DEFAULT 'kg',
  `min_price` decimal(10,2) DEFAULT NULL,
  `max_price` decimal(10,2) DEFAULT NULL,
  `avg_price` decimal(10,2) DEFAULT NULL,
  `quality_grade` enum('A','B','C','standard') DEFAULT 'standard',
  `demand_level` enum('low','medium','high') DEFAULT 'medium',
  `supply_level` enum('low','medium','high') DEFAULT 'medium',
  `recorded_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `price_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `market_prices`
--

INSERT INTO `market_prices` (`price_id`, `crop_name`, `crop_type`, `variety`, `market_location`, `district`, `region`, `price_per_unit`, `unit_type`, `min_price`, `max_price`, `avg_price`, `quality_grade`, `demand_level`, `supply_level`, `recorded_date`, `price_date`) VALUES
(1, 'Rice', 'grain', 'BRRI dhan28', 'Dhaka Wholesale Market', 'Dhaka Sadar', 'Dhaka', 52.00, 'kg', 50.00, 55.00, 52.50, 'standard', 'high', 'medium', '2025-12-18 15:02:20', '2025-12-18'),
(2, 'Wheat', 'grain', 'BARI Gom-33', 'Narayanganj Market', 'Narayanganj', 'Dhaka', 48.00, 'kg', 45.00, 50.00, 47.80, 'standard', 'medium', 'high', '2025-12-18 15:02:20', '2025-12-18'),
(3, 'Onion', 'vegetable', 'Improved Local Red', 'Khulna Market', 'Khulna Sadar', 'Khulna', 45.00, 'kg', 40.00, 50.00, 45.50, 'A', 'high', 'medium', '2025-12-18 15:02:20', '2025-12-18'),
(4, 'Cabbage', 'vegetable', 'Bangladesh Local', 'Rajshahi Market', 'Pabna', 'Rajshahi', 25.00, 'kg', 22.00, 28.00, 25.20, 'A', 'medium', 'high', '2025-12-18 15:02:20', '2025-12-18'),
(5, 'Tomato', 'vegetable', 'Roma', 'Chittagong Market', 'Feni', 'Chittagong', 60.00, 'kg', 55.00, 65.00, 60.50, 'B', 'medium', 'medium', '2025-12-18 15:02:20', '2025-12-18'),
(6, 'Potato', 'vegetable', 'Cardinal', 'Dhaka Wholesale Market', 'Dhaka Sadar', 'Dhaka', 35.00, 'kg', 32.00, 38.00, 35.50, 'standard', 'high', 'high', '2025-12-18 15:02:20', '2025-12-18'),
(7, 'Jute', 'fiber', 'Bangladesh Local Jute', 'Khulna Market', 'Khulna Sadar', 'Khulna', 120.00, 'kg', 110.00, 130.00, 122.00, 'standard', 'medium', 'low', '2025-12-18 15:02:20', '2025-12-18'),
(8, 'Lentil', 'pulse', 'Barisal-2', 'Bogra Market', 'Bogra', 'Rajshahi', 78.00, 'kg', 75.00, 82.00, 78.50, 'standard', 'high', 'medium', '2025-12-18 15:02:20', '2025-12-18'),
(9, 'Chickpea', 'pulse', 'Local White', 'Rajshahi Market', 'Rajshahi', 'Rajshahi', 85.00, 'kg', 82.00, 88.00, 85.50, 'A', 'medium', 'medium', '2025-12-18 15:02:20', '2025-12-18'),
(10, 'Barley', 'grain', 'Local Barley', 'Tangail Market', 'Tangail', 'Dhaka', 42.00, 'kg', 40.00, 45.00, 42.50, 'standard', 'low', 'high', '2025-12-18 15:02:20', '2025-12-18'),
(11, 'Mustard', 'oilseed', 'BARI Sarisha-14', 'Jessore Market', 'Jessore', 'Khulna', 95.00, 'kg', 92.00, 98.00, 95.50, 'standard', 'medium', 'low', '2025-12-18 15:02:20', '2025-12-18'),
(12, 'Cotton', 'fiber', 'Local Cotton', 'Comilla Market', 'Comilla', 'Chittagong', 185.00, 'kg', 180.00, 190.00, 186.00, 'A', 'low', 'medium', '2025-12-18 15:02:20', '2025-12-18'),
(13, 'Chili', 'vegetable', 'Long Chili', 'Nawabganj Market', 'Nawabganj', 'Rajshahi', 120.00, 'kg', 110.00, 130.00, 120.50, 'A', 'high', 'low', '2025-12-18 15:02:20', '2025-12-18'),
(14, 'Eggplant', 'vegetable', 'Local Long', 'Chandpur Market', 'Chandpur', 'Chittagong', 32.00, 'kg', 28.00, 36.00, 32.50, 'A', 'medium', 'medium', '2025-12-18 15:02:20', '2025-12-18'),
(15, 'Spinach', 'vegetable', 'Green Leaf', 'Gazipur Market', 'Gazipur', 'Dhaka', 22.00, 'kg', 18.00, 26.00, 22.50, 'A', 'low', 'high', '2025-12-18 15:02:20', '2025-12-18'),
(16, 'Carrot', 'vegetable', 'Red Long', 'Kushtia Market', 'Kushtia', 'Khulna', 28.00, 'kg', 25.00, 31.00, 28.50, 'A', 'medium', 'medium', '2025-12-18 15:02:20', '2025-12-18'),
(17, 'Broccoli', 'vegetable', 'Hybrid', 'Satkhira Market', 'Satkhira', 'Khulna', 55.00, 'kg', 50.00, 60.00, 55.50, 'A', 'low', 'low', '2025-12-18 15:02:20', '2025-12-18'),
(18, 'Cauliflower', 'vegetable', 'Local White', 'Shibganj Market', 'Shibganj', 'Rajshahi', 35.00, 'kg', 32.00, 38.00, 35.50, 'A', 'medium', 'medium', '2025-12-18 15:02:20', '2025-12-18'),
(19, 'Garlic', 'vegetable', 'Local White', 'Pirojpur Market', 'Pirojpur', 'Khulna', 150.00, 'kg', 140.00, 160.00, 150.50, 'A', 'medium', 'low', '2025-12-18 15:02:20', '2025-12-18'),
(20, 'Turmeric', 'spice', 'Local Yellow', 'Rangamati Market', 'Rangamati', 'Chittagong', 320.00, 'kg', 300.00, 340.00, 320.50, 'standard', 'low', 'low', '2025-12-18 15:02:20', '2025-12-18'),
(21, 'Papaya', 'fruit', 'Local Paw Paw', 'Cox Bazar Market', 'Cox Bazar', 'Chittagong', 25.00, 'kg', 20.00, 30.00, 25.50, 'B', 'medium', 'high', '2025-12-18 15:02:20', '2025-12-18'),
(22, 'Mango', 'fruit', 'Langra', 'Khagrachhari Market', 'Khagrachhari', 'Chittagong', 180.00, 'kg', 160.00, 200.00, 180.50, 'A', 'low', 'medium', '2025-12-18 15:02:20', '2025-12-18'),
(23, 'Banana', 'fruit', 'Sagor', 'Shariatpur Market', 'Shariatpur', 'Dhaka', 45.00, 'dozen', 40.00, 50.00, 45.50, 'A', 'high', 'high', '2025-12-18 15:02:20', '2025-12-18'),
(24, 'Sesame', 'oilseed', 'White Sesame', 'Natore Market', 'Natore', 'Rajshahi', 280.00, 'kg', 270.00, 290.00, 280.50, 'standard', 'low', 'low', '2025-12-18 15:02:20', '2025-12-18'),
(25, 'Sunflower', 'oilseed', 'Local Sunflower', 'Rajbari Market', 'Rajbari', 'Dhaka', 92.00, 'kg', 88.00, 96.00, 92.50, 'standard', 'medium', 'medium', '2025-12-18 15:02:20', '2025-12-18');

-- --------------------------------------------------------

--
-- Table structure for table `notification_preferences`
--

CREATE TABLE `notification_preferences` (
  `preference_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `weather_alerts` tinyint(1) DEFAULT 1,
  `disease_alerts` tinyint(1) DEFAULT 1,
  `market_alerts` tinyint(1) DEFAULT 1,
  `community_alerts` tinyint(1) DEFAULT 1,
  `email_notifications` tinyint(1) DEFAULT 1,
  `sms_notifications` tinyint(1) DEFAULT 0,
  `push_notifications` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notification_preferences`
--

INSERT INTO `notification_preferences` (`preference_id`, `user_id`, `weather_alerts`, `disease_alerts`, `market_alerts`, `community_alerts`, `email_notifications`, `sms_notifications`, `push_notifications`, `created_at`, `updated_at`) VALUES
(31, 49, 1, 1, 1, 1, 1, 0, 1, '2025-12-30 10:46:02', '2025-12-30 10:46:02'),
(33, 50, 1, 1, 1, 1, 1, 0, 1, '2026-01-11 10:03:02', '2026-01-11 10:03:02'),
(34, 64, 1, 1, 1, 1, 1, 0, 1, '2026-01-11 11:36:53', '2026-01-11 11:36:53');

-- --------------------------------------------------------

--
-- Table structure for table `officer_profiles`
--

CREATE TABLE `officer_profiles` (
  `profile_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `office_location` varchar(255) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `expertise_area` text DEFAULT NULL,
  `license_number` varchar(50) DEFAULT NULL,
  `joining_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_history`
--

CREATE TABLE `password_history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `post_bookmarks`
--

CREATE TABLE `post_bookmarks` (
  `bookmark_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `post_bookmarks`
--

INSERT INTO `post_bookmarks` (`bookmark_id`, `post_id`, `user_id`, `created_at`) VALUES
(2, 27, 46, '2025-12-30 04:05:42'),
(3, 68, 46, '2026-01-11 07:31:32');

-- --------------------------------------------------------

--
-- Table structure for table `post_comments`
--

CREATE TABLE `post_comments` (
  `comment_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `parent_comment_id` int(11) DEFAULT NULL,
  `content` text NOT NULL,
  `likes` int(11) DEFAULT 0,
  `is_approved` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `post_comments`
--

INSERT INTO `post_comments` (`comment_id`, `post_id`, `user_id`, `parent_comment_id`, `content`, `likes`, `is_approved`, `created_at`, `updated_at`) VALUES
(1, 1, 50, NULL, 'খুব সুন্দরভাবে শেয়ার করেছেন ভাই। শীতকালীন সবজিতে লাভ ভালো হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(2, 1, 69, NULL, 'আগাছা পরিষ্কার করার টিপসটা কাজে লাগবে। ধন্যবাদ।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(3, 1, 72, 1, 'আপনি কোন সার ব্যবহার করেছিলেন? একটু জানালে ভালো হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(4, 2, 49, NULL, 'হ্যাঁ, এটি Brown Spot হতে পারে। Tricyclazole দিতে পারেন।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(5, 2, 71, NULL, 'পাতা একটু ছবি দিলে নিশ্চিত বলা যেত।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(6, 2, 73, 4, 'আমি ব্যবহার করেছি। বেশ ভালো কাজ করেছে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(7, 3, 70, NULL, 'Solar irrigation এ cost একটু বেশি, কিন্তু long-term এ সাশ্রয়ী।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(8, 3, 64, NULL, '২ একরের জন্য 2HP solar pump যথেষ্ট হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(9, 3, 49, 7, 'কোন কোম্পানি থেকে quotation নিয়েছেন?', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(10, 4, 73, NULL, 'রাসুন-মরিচ মিশ্রণ spray করলে ভালো কাজ হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(11, 4, 71, NULL, 'Neem oil একটু নিয়মিত দিলে ফল ভালো পাওয়া যায়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(12, 5, 49, NULL, 'Biofloc শুরুতে aerator সবচেয়ে জরুরি।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(13, 5, 69, NULL, 'C/N ratio maintain না করলে সমস্যা হবে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(14, 5, 64, 13, 'আপনি কোন fish species ব্যবহার করছেন?', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(15, 6, 50, NULL, 'Pollination সমস্যা হলে hormone spray ব্যবহার করা যায়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(16, 6, 72, NULL, 'মাটিতে potash কম হলে ফলন কমে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(17, 6, 70, 17, 'আপনি কি micronutrient দিয়েছেন?', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(18, 7, 49, NULL, 'এটা ভাইরাস হতে পারে। Whitefly control করুন।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(19, 7, 73, NULL, 'Imidacloprid দিলে অনেকটা কমে যায়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(20, 7, 71, 20, 'Organic কিছু ব্যবহার করা যায় কি?', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(21, 8, 69, NULL, 'Potash সার কম ছিল বলেই ফলন কমেছে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(22, 8, 50, NULL, 'MOP দিতে পারেন। ভালো ফল পাবেন।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(23, 9, 72, NULL, 'Profit calculation টা খুব সুন্দর করে দিয়েছেন।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(24, 9, 49, NULL, 'Feed cost কমালে লাভ আরও বাড়বে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(25, 9, 70, 27, 'আপনি কোন কোম্পানির feed দেন?', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(26, 10, 64, NULL, 'তাপমাত্রা বেশি হলে papaya flower drop হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(27, 10, 71, NULL, 'পানি কম পেলে ও সমস্যা হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(28, 10, 73, 31, 'Mulching দিলে অনেক কমে যায়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(29, 11, 69, NULL, 'Organic farming এ soil quality আসলেই অনেক উন্নত হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(30, 11, 50, NULL, 'আপনি কোন compost ব্যবহার করেন?', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(31, 11, 72, 34, 'Vermicompost সবচেয়ে ভালো।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(32, 12, 49, NULL, 'AWD technique এ পানি অনেক সাশ্রয় হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(33, 12, 64, NULL, 'আমি ব্যবহার করেছি। ফলনও বেড়েছে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(34, 13, 70, NULL, 'Sigatoka হলে Mancozeb ব্যবহার করতে পারেন।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(35, 13, 49, NULL, 'পাতার নিচেও দাগ হয়?', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(36, 14, 73, NULL, 'ড্রিপ সেচ long-term এ সাশ্রয়ী।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(37, 14, 72, NULL, 'ছোট চাষির জন্য flood irrigation ভালো।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(38, 15, 71, NULL, 'pH কম হলে Lime দিতে হবে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(39, 15, 50, NULL, 'প্রতি decimal এ ২–৩ কেজি Lime যথেষ্ট।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(40, 15, 69, 43, 'ধীরে ধীরে pH বাড়ে, একবারে না।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(41, 16, 49, NULL, 'Napier ঘাসে protein অনেক বেশি।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(42, 16, 73, NULL, 'Cutting interval maintain করলে yield ভালো হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(43, 17, 72, NULL, 'Light trap খুব effective।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(44, 17, 64, NULL, 'Chemical insecticide কম ব্যবহার করা উচিত।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(45, 18, 50, NULL, 'BRRI hybrid 4 বেশ ভালো।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(46, 18, 69, NULL, 'Disease resistance একটু কম।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(47, 18, 73, 53, 'BRRI hybrid 5 বেশি ভালো ফল দেয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(48, 19, 49, NULL, 'Pruning টা সঠিকভাবে করলে ফলন সত্যিই বাড়ে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(49, 19, 71, NULL, 'আপনি কোন variety ব্যবহার করেছেন?', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(50, 20, 72, NULL, 'Raised bed করলে পানি জমে না।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(51, 20, 50, NULL, 'Root rot কমে যাবে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(52, 21, 49, NULL, 'Greenhouse এ pest খুব কম হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(53, 21, 69, NULL, 'Cost বেশি, maintenance কঠিন।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(54, 22, 64, NULL, 'Potash সত্যিই মিষ্টতা বাড়ায়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(55, 22, 70, NULL, 'Late irrigation কম দিলে ফল মিষ্টি হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(56, 23, 49, NULL, 'Garlic এ first fertilizer খুব গুরুত্বপূর্ণ।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(57, 23, 72, NULL, 'Organic compost দিলে আরও ভালো।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(58, 24, 50, NULL, 'Pheromone trap খুব কার্যকর।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(59, 24, 69, NULL, 'Weekly monitoring করতে হবে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(60, 25, 64, NULL, 'Overdose দিলে plant die হয়ে যায়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(61, 25, 71, NULL, 'Balanced fertilizer plan follow করা উচিত।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(62, 26, 72, NULL, 'Ginger farming লাভজনক।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(63, 26, 49, NULL, 'Local variety হলে yield কম হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(64, 27, 70, NULL, 'Sesame early monsoon এ ভালো হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(65, 27, 73, NULL, 'দेरি করলে ফলন কমে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(66, 28, 50, NULL, 'Blast disease dangerous.', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(67, 28, 64, NULL, 'Tricyclazole best solution।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(68, 29, 71, NULL, 'Soybean এ পানি বেশি দিলে ফলন কমে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(69, 29, 49, NULL, 'Light irrigation best।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(70, 30, 72, NULL, 'Olive এ cross-pollination দরকার।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(71, 30, 70, NULL, 'একাধিক variety লাগালে ফলন বেড়ে যায়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(72, 31, 50, NULL, 'Groundwater crisis বাড়ছে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(73, 31, 64, NULL, 'Rainwater harvesting জরুরি।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(74, 32, 49, NULL, 'Strawberry cool climate পছন্দ করে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(75, 32, 73, NULL, 'Shade net দিলে ফলন ভালো হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(76, 33, 50, NULL, 'Mushroom farming small space এ করা যায়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(77, 33, 72, NULL, 'Humidity 80-85% maintain করতে হবে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(78, 34, 49, NULL, 'Peanut farming কম খরচে লাভজনক।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(79, 34, 69, NULL, 'Soil sandy loam হলে yield বেশি।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(80, 35, 70, NULL, 'Fruit fly সবচেয়ে ক্ষতিকর।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(81, 35, 64, NULL, 'Bagging করলে damage কমে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(82, 36, 72, NULL, 'Jackfruit এ NPK balance জরুরি।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(83, 36, 49, NULL, 'Leaf spray দিলে ফলন বাড়ে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(84, 37, 71, NULL, 'Coffee hilly area তে ভালো হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(85, 37, 69, NULL, 'Rainfall pattern match করতে হবে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(86, 38, 50, NULL, 'Jute fiber quality soil fertility এর উপর নির্ভর।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(87, 38, 72, NULL, 'Organic matter বাড়াতে হবে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(88, 39, 64, NULL, 'Fish sudden death হলে oxygen কমে গেছে।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(89, 39, 49, NULL, 'Aerator ব্যবহার করলেই ঠিক হয়ে যায়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(90, 40, 73, NULL, 'Local ingredients দিয়ে poultry feed তৈরি করা যায়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(91, 40, 70, NULL, 'Protein ratio maintain করা জরুরি।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(92, 41, 50, NULL, 'Watermelon mosaic virus dangerous.', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(93, 41, 49, NULL, 'Resistant variety use করুন।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(94, 42, 64, NULL, 'Hybrid papaya female বেশি হয়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(95, 42, 73, NULL, 'Male tree হলে ফল আসে না।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(96, 43, 70, NULL, 'Mini tiller cost কমায়।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12'),
(97, 43, 69, NULL, 'Power weeder খুব helpful।', 0, 1, '2026-01-15 11:54:12', '2026-01-15 11:54:12');

-- --------------------------------------------------------

--
-- Table structure for table `post_helpfulness`
--

CREATE TABLE `post_helpfulness` (
  `helpfulness_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `is_helpful` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `post_helpfulness`
--

INSERT INTO `post_helpfulness` (`helpfulness_id`, `post_id`, `user_id`, `is_helpful`, `created_at`) VALUES
(1, 31, 47, 1, '2025-12-29 23:59:35'),
(2, 32, 46, 1, '2025-12-30 04:22:35'),
(3, 81, 46, 0, '2026-01-11 04:40:24'),
(4, 68, 46, 1, '2026-01-11 07:10:38'),
(5, 68, 68, 0, '2026-01-12 07:28:32');

-- --------------------------------------------------------

--
-- Table structure for table `post_likes`
--

CREATE TABLE `post_likes` (
  `like_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `post_reports`
--

CREATE TABLE `post_reports` (
  `report_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('pending','reviewed','resolved','dismissed') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `resolved_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `post_shares`
--

CREATE TABLE `post_shares` (
  `share_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `platform` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `post_shares`
--

INSERT INTO `post_shares` (`share_id`, `post_id`, `user_id`, `platform`, `created_at`) VALUES
(1, 32, 46, 'internal', '2025-12-30 04:22:39');

-- --------------------------------------------------------

--
-- Table structure for table `product_comparisons`
--

CREATE TABLE `product_comparisons` (
  `comparison_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_inquiries`
--

CREATE TABLE `product_inquiries` (
  `inquiry_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `message` text DEFAULT NULL,
  `inquiry_type` enum('price','availability','quality','delivery','general') DEFAULT 'general',
  `status` enum('pending','responded','closed') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_offers`
--

CREATE TABLE `product_offers` (
  `offer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `offered_price` decimal(10,2) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `message` text DEFAULT NULL,
  `status` enum('pending','accepted','rejected','countered','expired') DEFAULT 'pending',
  `counter_price` decimal(10,2) DEFAULT NULL,
  `seller_message` text DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_reports`
--

CREATE TABLE `product_reports` (
  `report_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `reporter_id` int(11) NOT NULL,
  `reason` enum('fake','inappropriate','spam','wrong_category','overpriced','scam','other') NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('pending','reviewed','resolved','dismissed') DEFAULT 'pending',
  `admin_notes` text DEFAULT NULL,
  `reviewed_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_reviews`
--

CREATE TABLE `product_reviews` (
  `review_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `parent_review_id` int(11) DEFAULT NULL COMMENT 'For replies',
  `rating` int(1) DEFAULT NULL COMMENT '1-5 star rating (NULL for replies)',
  `review_text` text DEFAULT NULL,
  `images` text DEFAULT NULL COMMENT 'JSON array of image URLs',
  `helpful_count` int(11) DEFAULT 0,
  `not_helpful_count` int(11) DEFAULT 0,
  `is_verified_purchase` tinyint(1) DEFAULT 0,
  `status` enum('active','hidden','deleted') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_reviews`
--

INSERT INTO `product_reviews` (`review_id`, `product_id`, `user_id`, `parent_review_id`, `rating`, `review_text`, `images`, `helpful_count`, `not_helpful_count`, `is_verified_purchase`, `status`, `created_at`, `updated_at`) VALUES
(3, 9, 76, NULL, 5, 'cxcsc', NULL, 0, 0, 0, 'active', '2026-05-16 04:46:17', '2026-05-16 04:46:17');

-- --------------------------------------------------------

--
-- Table structure for table `product_wishlist`
--

CREATE TABLE `product_wishlist` (
  `wishlist_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `notify_price_drop` tinyint(1) DEFAULT 1,
  `notify_back_in_stock` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rate_limits`
--

CREATE TABLE `rate_limits` (
  `id` int(11) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `identifier_type` enum('ip','user','session','api_key') NOT NULL,
  `endpoint` varchar(255) DEFAULT NULL,
  `request_count` int(11) DEFAULT 1,
  `window_start` timestamp NOT NULL DEFAULT current_timestamp(),
  `blocked_until` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rate_limits`
--

INSERT INTO `rate_limits` (`id`, `identifier`, `identifier_type`, `endpoint`, `request_count`, `window_start`, `blocked_until`) VALUES
(56, '127.0.0.1', 'ip', 'admin_login', 1, '2026-01-15 12:17:15', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `recently_viewed`
--

CREATE TABLE `recently_viewed` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `viewed_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `recently_viewed`
--

INSERT INTO `recently_viewed` (`id`, `user_id`, `product_id`, `viewed_at`) VALUES
(24, 50, 9, '2026-01-15 12:20:31'),
(26, 76, 9, '2026-05-16 04:45:54'),
(28, 76, 5, '2026-05-16 04:47:46');

-- --------------------------------------------------------

--
-- Table structure for table `restore_logs`
--

CREATE TABLE `restore_logs` (
  `restore_id` int(11) NOT NULL,
  `backup_id` int(11) NOT NULL,
  `restore_type` enum('full','partial','table','data_only') NOT NULL,
  `status` enum('pending','in_progress','completed','failed','rolled_back') DEFAULT 'pending',
  `tables_restored` text DEFAULT NULL,
  `rows_affected` bigint(20) DEFAULT NULL,
  `duration_seconds` int(11) DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `started_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL,
  `restored_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `review_helpfulness`
--

CREATE TABLE `review_helpfulness` (
  `vote_id` int(11) NOT NULL,
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `is_helpful` tinyint(1) NOT NULL COMMENT '1 = helpful, 0 = not helpful',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `review_likes`
--

CREATE TABLE `review_likes` (
  `like_id` int(11) NOT NULL,
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `scheduled_reports`
--

CREATE TABLE `scheduled_reports` (
  `schedule_id` int(11) NOT NULL,
  `report_name` varchar(255) NOT NULL,
  `report_type` enum('users','activity','security','performance','financial','content','custom') NOT NULL,
  `schedule_cron` varchar(50) NOT NULL,
  `schedule_human` varchar(100) DEFAULT NULL,
  `format` enum('pdf','csv','excel') DEFAULT 'pdf',
  `parameters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`parameters`)),
  `recipients` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`recipients`)),
  `include_attachment` tinyint(1) DEFAULT 1,
  `is_enabled` tinyint(1) DEFAULT 1,
  `last_sent` timestamp NULL DEFAULT NULL,
  `last_status` enum('success','failed') DEFAULT NULL,
  `next_send` timestamp NULL DEFAULT NULL,
  `send_count` int(11) DEFAULT 0,
  `fail_count` int(11) DEFAULT 0,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `scheduled_tasks`
--

CREATE TABLE `scheduled_tasks` (
  `task_id` int(11) NOT NULL,
  `task_name` varchar(100) NOT NULL,
  `task_description` text DEFAULT NULL,
  `task_type` enum('backup','cleanup','report','email','metric','security','custom') DEFAULT 'custom',
  `task_handler` varchar(255) DEFAULT NULL,
  `task_params` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`task_params`)),
  `schedule_cron` varchar(50) DEFAULT NULL,
  `schedule_human` varchar(100) DEFAULT NULL,
  `is_enabled` tinyint(1) DEFAULT 1,
  `is_running` tinyint(1) DEFAULT 0,
  `last_run` timestamp NULL DEFAULT NULL,
  `next_run` timestamp NULL DEFAULT NULL,
  `last_status` enum('pending','running','success','failed','timeout') DEFAULT 'pending',
  `last_result` text DEFAULT NULL,
  `last_duration_ms` int(11) DEFAULT NULL,
  `run_count` int(11) DEFAULT 0,
  `fail_count` int(11) DEFAULT 0,
  `consecutive_fails` int(11) DEFAULT 0,
  `max_retries` int(11) DEFAULT 3,
  `timeout_seconds` int(11) DEFAULT 300,
  `priority` int(11) DEFAULT 5,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `scheduled_tasks`
--

INSERT INTO `scheduled_tasks` (`task_id`, `task_name`, `task_description`, `task_type`, `task_handler`, `task_params`, `schedule_cron`, `schedule_human`, `is_enabled`, `is_running`, `last_run`, `next_run`, `last_status`, `last_result`, `last_duration_ms`, `run_count`, `fail_count`, `consecutive_fails`, `max_retries`, `timeout_seconds`, `priority`, `created_at`, `updated_at`) VALUES
(1, 'Daily Backup', 'Automated daily database backup', 'backup', 'BackupHandler::daily', NULL, '0 2 * * *', 'Every day at 2:00 AM', 1, 0, NULL, NULL, 'pending', NULL, NULL, 0, 0, 0, 3, 300, 5, '2025-12-30 05:45:11', '2025-12-30 14:03:57'),
(2, 'Cleanup Old Sessions', 'Remove expired admin sessions', 'cleanup', 'CleanupHandler::sessions', NULL, '0 * * * *', 'Every hour', 1, 0, NULL, NULL, 'pending', NULL, NULL, 0, 0, 0, 3, 300, 5, '2025-12-30 05:45:11', '2025-12-30 05:45:11'),
(3, 'Cleanup Old Logs', 'Remove logs older than 30 days', 'cleanup', 'CleanupHandler::logs', NULL, '0 3 * * *', 'Every day at 3:00 AM', 0, 0, NULL, NULL, 'pending', NULL, NULL, 0, 0, 0, 3, 300, 5, '2025-12-30 05:45:11', '2025-12-30 14:12:26'),
(4, 'Collect System Metrics', 'Record system performance metrics', 'metric', 'MetricHandler::collect', NULL, '*/5 * * * *', 'Every 5 minutes', 1, 0, NULL, NULL, 'pending', NULL, NULL, 0, 0, 0, 3, 300, 5, '2025-12-30 05:45:11', '2025-12-30 05:45:11'),
(5, 'Security Scan', 'Scan for security anomalies', 'security', 'SecurityHandler::scan', NULL, '0 */6 * * *', 'Every 6 hours', 0, 0, '2025-12-30 14:13:59', '2025-12-30 15:14:00', 'success', NULL, 1005, 0, 0, 0, 3, 300, 5, '2025-12-30 05:45:11', '2025-12-30 14:14:05'),
(6, 'Generate Daily Report', 'Generate daily activity report', 'report', 'ReportHandler::daily', NULL, '0 6 * * *', 'Every day at 6:00 AM', 0, 0, NULL, NULL, 'pending', NULL, NULL, 0, 0, 0, 3, 300, 5, '2025-12-30 05:45:11', '2025-12-30 05:45:11'),
(7, 'Process Email Queue', 'Send pending emails', 'email', 'EmailHandler::process', NULL, '*/5 * * * *', 'Every 5 minutes', 1, 0, NULL, NULL, 'pending', NULL, NULL, 0, 0, 0, 3, 300, 5, '2025-12-30 05:45:11', '2025-12-30 05:45:11');

-- --------------------------------------------------------

--
-- Table structure for table `security_events`
--

CREATE TABLE `security_events` (
  `event_id` int(11) NOT NULL,
  `event_type` enum('brute_force','suspicious_login','session_hijack','privilege_escalation','data_exfiltration','honeypot_trigger','rate_limit','geo_anomaly','time_anomaly','password_attack','sql_injection','xss_attempt') NOT NULL,
  `severity` enum('info','low','medium','high','critical') DEFAULT 'medium',
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `raw_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`raw_data`)),
  `is_acknowledged` tinyint(1) DEFAULT 0,
  `acknowledged_by` int(11) DEFAULT NULL,
  `acknowledged_at` timestamp NULL DEFAULT NULL,
  `action_taken` text DEFAULT NULL,
  `auto_blocked` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `security_events`
--

INSERT INTO `security_events` (`event_id`, `event_type`, `severity`, `user_id`, `ip_address`, `description`, `raw_data`, `is_acknowledged`, `acknowledged_by`, `acknowledged_at`, `action_taken`, `auto_blocked`, `created_at`) VALUES
(1, 'honeypot_trigger', 'high', NULL, '::1', 'Bot detected via honeypot on admin login', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 08:01:10'),
(2, 'honeypot_trigger', 'high', NULL, '::1', 'Bot detected via honeypot on admin login', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 08:01:48'),
(3, 'honeypot_trigger', 'high', NULL, '::1', 'Bot detected via honeypot on admin login', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 08:01:52'),
(4, 'honeypot_trigger', 'high', NULL, '::1', 'Bot detected via honeypot on admin login', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 08:02:55'),
(5, 'honeypot_trigger', 'high', NULL, '::1', 'Bot detected via honeypot on admin login', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 08:02:59'),
(6, 'honeypot_trigger', 'high', NULL, '::1', 'Bot detected via honeypot on admin login', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 08:03:45'),
(7, 'honeypot_trigger', 'high', NULL, '::1', 'Bot detected via honeypot on admin login', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 08:03:48'),
(8, 'honeypot_trigger', 'high', NULL, '::1', 'Bot detected via honeypot on admin login', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 08:03:53'),
(9, 'honeypot_trigger', 'high', NULL, '::1', 'Bot detected via honeypot on admin login', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 08:04:21'),
(10, 'honeypot_trigger', 'high', NULL, '::1', 'Bot detected via honeypot on admin login', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 08:04:25'),
(11, 'honeypot_trigger', 'high', NULL, '::1', 'Bot detected via honeypot on admin login', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 08:04:27'),
(12, 'honeypot_trigger', 'high', NULL, '::1', 'Bot detected via honeypot on admin login', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 08:04:32'),
(13, 'honeypot_trigger', 'high', NULL, '::1', 'Bot detected via honeypot on admin login', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 08:04:39'),
(14, 'brute_force', 'high', NULL, '::1', 'Blocked IP attempted admin login', '{\"email\":\"admin@smartcashi.com\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 10:04:53'),
(15, 'brute_force', 'high', NULL, '::1', 'Blocked IP attempted admin login', '{\"email\":\"admin@smartcashi.com\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 10:04:57'),
(16, '', 'medium', 49, '::1', 'Error creating user: SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry \'1518749114\' for key \'phone\'', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 11:12:40'),
(17, '', 'medium', 49, '::1', 'Error creating user: SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry \'1518749114\' for key \'phone\'', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 11:12:40'),
(18, '', 'medium', 49, '::1', 'Error creating user: SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry \'1518749114\' for key \'phone\'', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 11:12:40'),
(19, '', 'medium', 49, '::1', 'Error creating user: SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry \'1518749114\' for key \'phone\'', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 11:12:52'),
(20, '', 'medium', 49, '::1', 'Error creating user: SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry \'1518749114\' for key \'phone\'', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 11:12:52'),
(21, '', 'medium', 49, '::1', 'Error creating user: SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry \'1518749114\' for key \'phone\'', '{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\"}', 0, NULL, NULL, NULL, 0, '2025-12-30 11:12:52');

-- --------------------------------------------------------

--
-- Table structure for table `seller_stats`
--

CREATE TABLE `seller_stats` (
  `seller_id` int(11) NOT NULL,
  `total_products` int(11) DEFAULT 0,
  `total_sold` int(11) DEFAULT 0,
  `total_orders` int(11) DEFAULT 0,
  `completed_orders` int(11) DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `total_reviews` int(11) DEFAULT 0,
  `response_rate` decimal(5,2) DEFAULT 0.00,
  `badge` enum('new','bronze','silver','gold','platinum') DEFAULT 'new',
  `verified` tinyint(1) DEFAULT 0,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `setting_id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shop_cart`
--

CREATE TABLE `shop_cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `session_id` varchar(128) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shop_cart`
--

INSERT INTO `shop_cart` (`cart_id`, `user_id`, `session_id`, `product_id`, `quantity`, `created_at`, `updated_at`) VALUES
(2, NULL, 'cvdjtkc8sr6eabocpg3v0pgsm2', 7, 1, '2026-05-15 18:54:44', '2026-05-15 18:54:44'),
(3, 2, NULL, 9, 1, '2026-05-15 20:16:46', '2026-05-15 20:16:46');

-- --------------------------------------------------------

--
-- Table structure for table `shop_conversations`
--

CREATE TABLE `shop_conversations` (
  `conversation_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL COMMENT 'Related shop_orders.order_id',
  `product_id` int(11) DEFAULT NULL COMMENT 'Related marketplace_products.product_id',
  `product_name` varchar(255) DEFAULT NULL,
  `farmer_id` int(11) NOT NULL COMMENT 'users.user_id (farmer)',
  `customer_id` int(11) NOT NULL COMMENT 'general_users.user_id or users.user_id',
  `customer_type` enum('farmer','general') DEFAULT 'general' COMMENT 'Type of customer',
  `subject` varchar(255) DEFAULT NULL COMMENT 'Conversation subject',
  `last_message_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `farmer_unread` int(11) DEFAULT 0 COMMENT 'Unread count for farmer',
  `customer_unread` int(11) DEFAULT 0 COMMENT 'Unread count for customer',
  `status` enum('active','closed') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shop_conversations`
--

INSERT INTO `shop_conversations` (`conversation_id`, `order_id`, `product_id`, `product_name`, `farmer_id`, `customer_id`, `customer_type`, `subject`, `last_message_at`, `farmer_unread`, `customer_unread`, `status`, `created_at`) VALUES
(1, NULL, 9, 'Jambo prawn', 72, 2, 'general', 'Re: Jambo prawn', '2026-05-15 23:36:28', 2, 0, 'active', '2026-05-15 20:17:21');

-- --------------------------------------------------------

--
-- Table structure for table `shop_messages`
--

CREATE TABLE `shop_messages` (
  `message_id` int(11) NOT NULL,
  `conversation_id` int(11) NOT NULL,
  `sender_type` enum('farmer','customer') NOT NULL,
  `sender_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `attachment_url` varchar(500) DEFAULT NULL COMMENT 'Image/file attachment',
  `attachment_type` varchar(50) DEFAULT NULL COMMENT 'image/file/etc',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shop_messages`
--

INSERT INTO `shop_messages` (`message_id`, `conversation_id`, `sender_type`, `sender_id`, `message`, `attachment_url`, `attachment_type`, `is_read`, `created_at`) VALUES
(1, 1, 'customer', 2, 'hello', NULL, NULL, 0, '2026-05-15 20:17:21'),
(2, 1, 'customer', 2, 't6', NULL, NULL, 0, '2026-05-15 23:36:28');

-- --------------------------------------------------------

--
-- Table structure for table `shop_orders`
--

CREATE TABLE `shop_orders` (
  `order_id` int(11) NOT NULL,
  `order_number` varchar(50) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `shipping_cost` decimal(10,2) DEFAULT 0.00,
  `discount_amount` decimal(10,2) DEFAULT 0.00,
  `shipping_name` varchar(200) NOT NULL,
  `shipping_phone` varchar(20) NOT NULL,
  `shipping_address` text NOT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_district` varchar(100) DEFAULT NULL,
  `shipping_postal_code` varchar(20) DEFAULT NULL,
  `payment_method` enum('cod','bkash','nagad','bank') DEFAULT 'cod',
  `payment_status` enum('pending','paid','failed','refunded') DEFAULT 'pending',
  `payment_transaction_id` varchar(100) DEFAULT NULL,
  `order_status` enum('pending','confirmed','processing','shipped','delivered','cancelled','returned') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shop_order_items`
--

CREATE TABLE `shop_order_items` (
  `item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_image` varchar(255) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `item_status` enum('pending','confirmed','shipped','delivered','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shop_otp_codes`
--

CREATE TABLE `shop_otp_codes` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `purpose` enum('register','reset_password') NOT NULL DEFAULT 'register',
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shop_settings`
--

CREATE TABLE `shop_settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('text','html','json','boolean','number') NOT NULL DEFAULT 'text',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shop_settings`
--

INSERT INTO `shop_settings` (`setting_key`, `setting_value`, `setting_type`, `updated_at`) VALUES
('delivery_charge', '50', 'number', '2026-05-15 18:32:46'),
('delivery_note', 'Free delivery on orders over ৳500', 'text', '2026-05-15 18:32:46'),
('footer_about', 'Buy fresh agricultural products directly from farmers across Bangladesh.', 'text', '2026-05-15 18:32:46'),
('footer_address', 'Dhaka, Bangladesh', 'text', '2026-05-15 18:32:46'),
('footer_copyright', 'Smart Chashi Shop', 'text', '2026-05-15 18:32:46'),
('footer_email', 'info@smartchashi.com', 'text', '2026-05-15 18:32:46'),
('footer_facebook', '', 'text', '2026-05-15 18:32:46'),
('footer_instagram', '', 'text', '2026-05-15 18:32:46'),
('footer_phone', '+880 1700-000000', 'text', '2026-05-15 18:32:46'),
('footer_twitter', '', 'text', '2026-05-15 18:32:46'),
('footer_youtube', '', 'text', '2026-05-15 18:32:46'),
('min_free_delivery', '500', 'number', '2026-05-15 18:32:46'),
('shop_announcement', '', 'text', '2026-05-15 18:32:46'),
('shop_meta_description', 'Fresh farm products direct to your door.', 'text', '2026-05-15 18:32:46');

-- --------------------------------------------------------

--
-- Table structure for table `sms_settings`
--

CREATE TABLE `sms_settings` (
  `setting_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `rain_alert` tinyint(1) DEFAULT 1,
  `temp_alert` tinyint(1) DEFAULT 1,
  `storm_alert` tinyint(1) DEFAULT 0,
  `pest_alert` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_logs`
--

CREATE TABLE `system_logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) DEFAULT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_metrics`
--

CREATE TABLE `system_metrics` (
  `metric_id` int(11) NOT NULL,
  `metric_type` enum('cpu','memory','disk','database','response_time','error_rate','network','php','requests') NOT NULL,
  `metric_name` varchar(100) DEFAULT NULL,
  `metric_value` decimal(15,2) NOT NULL,
  `metric_unit` varchar(20) DEFAULT NULL,
  `server_id` varchar(50) DEFAULT 'main',
  `additional_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_data`)),
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL,
  `site_name` varchar(255) NOT NULL DEFAULT 'SmartChashi',
  `site_description` text DEFAULT NULL,
  `site_logo` varchar(255) DEFAULT NULL,
  `site_favicon` varchar(255) DEFAULT NULL,
  `default_language` varchar(10) NOT NULL DEFAULT 'en',
  `timezone` varchar(100) NOT NULL DEFAULT 'Asia/Dhaka',
  `date_format` varchar(50) NOT NULL DEFAULT 'Y-m-d',
  `time_format` varchar(50) NOT NULL DEFAULT 'H:i:s',
  `items_per_page` int(11) NOT NULL DEFAULT 20,
  `currency` varchar(10) NOT NULL DEFAULT 'BDT',
  `currency_symbol` varchar(10) NOT NULL DEFAULT '৳',
  `contact_email` varchar(255) DEFAULT NULL,
  `contact_phone` varchar(50) DEFAULT NULL,
  `contact_address` text DEFAULT NULL,
  `facebook_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `youtube_url` varchar(255) DEFAULT NULL,
  `instagram_url` varchar(255) DEFAULT NULL,
  `enable_registration` tinyint(1) NOT NULL DEFAULT 1,
  `enable_comments` tinyint(1) NOT NULL DEFAULT 1,
  `enable_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `google_analytics_id` varchar(100) DEFAULT NULL,
  `facebook_pixel_id` varchar(100) DEFAULT NULL,
  `seo_title` varchar(255) DEFAULT NULL,
  `seo_description` text DEFAULT NULL,
  `seo_keywords` text DEFAULT NULL,
  `agent_api_url` varchar(255) DEFAULT NULL,
  `disease_detection_api_url` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `site_name`, `site_description`, `site_logo`, `site_favicon`, `default_language`, `timezone`, `date_format`, `time_format`, `items_per_page`, `currency`, `currency_symbol`, `contact_email`, `contact_phone`, `contact_address`, `facebook_url`, `twitter_url`, `youtube_url`, `instagram_url`, `enable_registration`, `enable_comments`, `enable_notifications`, `google_analytics_id`, `facebook_pixel_id`, `seo_title`, `seo_description`, `seo_keywords`, `agent_api_url`, `disease_detection_api_url`, `updated_at`, `updated_by`) VALUES
(1, 'SmartChashi', 'Smart Agriculture Management System - Empowering Farmers with Technology', NULL, NULL, 'en', 'Asia/Dhaka', 'Y-m-d', 'H:i:s', 20, 'BDT', '৳', 'bluedot.smartchashi@gmail.com', '+8801518749114', 'Gazipur, Bangladesh', 'https://www.facebook.com/TeamBlueDot', '', 'https://www.youtube.com/@Team_BlueDot', '', 1, 1, 1, NULL, NULL, 'SmartChashi - Smart Agriculture Management System', 'A comprehensive platform for modern farming, crop management, disease detection, and agricultural guidance', NULL, 'https://chashi-bhai.up.railway.app/chat', 'http://localhost:8080/api/analyze', '2026-05-16 21:08:18', 49);

-- --------------------------------------------------------

--
-- Table structure for table `task_execution_logs`
--

CREATE TABLE `task_execution_logs` (
  `log_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  `status` enum('started','completed','failed','timeout','skipped') NOT NULL,
  `output` text DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `memory_peak` int(11) DEFAULT NULL,
  `started_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `profile_img_url` varchar(200) NOT NULL,
  `role` enum('farmer','officer','admin') DEFAULT 'farmer',
  `is_active` tinyint(1) DEFAULT 1,
  `is_verified` tinyint(1) DEFAULT 0,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `remember_token` varchar(64) DEFAULT NULL,
  `remember_token_expires` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `email`, `phone`, `password_hash`, `first_name`, `last_name`, `profile_img_url`, `role`, `is_active`, `is_verified`, `last_login`, `created_at`, `updated_at`, `remember_token`, `remember_token_expires`) VALUES
(49, 'bluedot.smartchashi@gmail.com', '+8801518749114', '$2y$10$xBCPU/lz302alc3LrmAzkOm2GRFZxG1jPmbiECj2av5Ki2aI0SZQC', 'Admin', '', 'uploads/profiles/profile_49_1768498597.png', 'admin', 1, 1, '2026-05-17 16:36:45', '2025-12-30 08:12:31', '2026-05-17 16:36:45', NULL, NULL),
(50, 'mohatamimhaque1234@gmail.com', '1518749114', '$2y$12$aoQZrbK9jhA1BPfMfWhUHuEg5GK/TAoCATkeg2hTKT8MMHmUGRNCK', 'Mohatamim', '', 'uploads/profiles/profile_50_1768475146.jpg', 'officer', 1, 1, '2026-05-16 16:47:59', '2025-12-30 11:09:26', '2026-05-16 16:47:59', NULL, NULL),
(64, 'fetok27108@gopicta.com', '017233633764', '$2y$10$7olSM1rR5WpBMUkjeRLP..NFdtx9NNgvYYdZ1yuv8YtVdSndaAS7G', 'Rahim', '', 'uploads/profiles/profile_64_1768498228.webp', 'farmer', 1, 1, '2026-05-17 16:38:48', '2026-01-11 11:07:42', '2026-05-17 16:38:48', '81f0f226a5cd3ca1b8a1fa6a7b4ec14862f93b99a13eb0f5c6c358352050b0cc', '2026-06-16 08:28:56'),
(69, 'nishandas655@gmail.com', '01867568689', '$2y$10$R7LErDeIDiH5WllfcH/ypuQY7EkNYYHXtZVHlYPeE79YrfGAAd8DG', 'Nishan ', 'Das', 'uploads/profiles/profile_69_1768474160.jpg', 'farmer', 1, 1, '2026-01-16 02:59:01', '2026-01-15 10:47:40', '2026-01-16 02:59:01', NULL, NULL),
(70, 'avijit2019mondal@gmail.com', '01855512502', '$2y$10$tjfRfZ0OryyEn6nUoDoJZOd3q6lid/MDhoA46Za9Kpr7JARgNBUvu', 'Avijit', 'Mondal', 'uploads/profiles/profile_70_1768474489.jpg', 'officer', 1, 1, '2026-01-15 10:55:55', '2026-01-15 10:50:54', '2026-01-15 10:55:55', NULL, NULL),
(71, 'siamabir35@gmail.com', '01770459588', '$2y$10$Q4DDDzPWuXTLl4.6guH83Ou7f1uFwp05iwkJYpyiZwX7pT0WXm1H6', 'Md Siam', 'Shaek', 'uploads/profiles/profile_71_1768475428.jpg', 'officer', 1, 1, '2026-01-15 11:10:28', '2026-01-15 11:08:33', '2026-01-15 11:10:28', NULL, NULL),
(72, 'avijitmondalavi2019@gmail.com', '01855512505', '$2y$10$0zfYQCyMuJWQ/zCIkNsc.uPzL2k23Q61zKz8dT/o6k6OjvrMcPVga', 'Avijit', 'Mondal', 'uploads/profiles/profile_72_1768476765.jpg', 'farmer', 1, 1, '2026-01-15 11:32:45', '2026-01-15 11:31:33', '2026-01-15 11:32:45', NULL, NULL),
(73, 'siamduetstudent@gmail.com', '01770459590', '$2y$10$anCeTMkk.asl.rXAmwblLeJADlIJRfuQNA4koepDUNaf1jkYB9pPa', 'Md siam', 'Abir', 'uploads/profiles/profile_73_1768476807.jpg', 'farmer', 1, 1, '2026-01-15 11:33:27', '2026-01-15 11:32:38', '2026-01-15 11:33:27', NULL, NULL),
(75, 'mohaimenulislam.cse@gmail.com', '+8801788-269-537', '$2y$10$FvnB42GnXPWERCj8VIb3rugHDHOKqbe9ZBxyejm3trvLJ7kiAmTkK', 'S.M Mohaimenul', 'Islam', 'uploads/profiles/profile_75_1768478966.jpeg', 'farmer', 1, 1, '2026-01-15 12:09:26', '2026-01-15 12:07:45', '2026-01-15 12:09:26', NULL, NULL),
(76, 'tibetoc366@hidevak.com', '0112132323232', '$2y$10$QW3tB2S0y7NQTigZQJ1/le0yBd.rwPLVZGuzHBrV2wnaQ5pCUqYAK', 'tibetoc366@hidevak.com', '', 'uploads/profiles/profile_76_1778906638.webp', 'farmer', 1, 1, '2026-05-16 04:48:16', '2026-05-16 04:42:27', '2026-05-16 04:48:16', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_bans`
--

CREATE TABLE `user_bans` (
  `ban_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ban_type` enum('temporary','permanent','ip_ban','shadow_ban') NOT NULL,
  `reason` text NOT NULL,
  `internal_notes` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `ip_range` varchar(100) DEFAULT NULL,
  `banned_by` int(11) NOT NULL,
  `banned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `unbanned_by` int(11) DEFAULT NULL,
  `unbanned_at` timestamp NULL DEFAULT NULL,
  `unban_reason` text DEFAULT NULL,
  `appeal_submitted` tinyint(1) DEFAULT 0,
  `appeal_text` text DEFAULT NULL,
  `appeal_reviewed_by` int(11) DEFAULT NULL,
  `appeal_status` enum('pending','approved','denied') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_bans`
--

INSERT INTO `user_bans` (`ban_id`, `user_id`, `ban_type`, `reason`, `internal_notes`, `ip_address`, `ip_range`, `banned_by`, `banned_at`, `expires_at`, `is_active`, `unbanned_by`, `unbanned_at`, `unban_reason`, `appeal_submitted`, `appeal_text`, `appeal_reviewed_by`, `appeal_status`) VALUES
(1, 58, 'temporary', 'nn n', NULL, NULL, NULL, 49, '2025-12-30 11:17:10', '2026-01-06 06:17:10', 1, NULL, NULL, NULL, 0, NULL, NULL, NULL),
(2, 58, 'temporary', 'nn n', NULL, NULL, NULL, 49, '2025-12-30 11:17:10', '2026-01-06 06:17:10', 1, NULL, NULL, NULL, 0, NULL, NULL, NULL),
(3, 58, 'temporary', 'nn n', NULL, NULL, NULL, 49, '2025-12-30 11:17:10', '2026-01-06 06:17:10', 1, NULL, NULL, NULL, 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_notifications`
--

CREATE TABLE `user_notifications` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_type` enum('farmer','officer','general') NOT NULL DEFAULT 'farmer',
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `icon` varchar(50) DEFAULT 'notifications',
  `link` varchar(500) DEFAULT NULL,
  `type` enum('order','message','alert','advisory','report','system') DEFAULT 'system',
  `reference_id` int(11) DEFAULT NULL COMMENT 'Related order/message/report ID',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_sessions`
--

CREATE TABLE `user_sessions` (
  `session_id` varchar(128) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_warnings`
--

CREATE TABLE `user_warnings` (
  `warning_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `warning_type` enum('content','behavior','spam','fraud','terms_violation','harassment') NOT NULL,
  `severity` enum('minor','moderate','severe') DEFAULT 'minor',
  `reason` text NOT NULL,
  `content_type` varchar(50) DEFAULT NULL,
  `content_id` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT 1,
  `expires_at` timestamp NULL DEFAULT NULL,
  `acknowledged` tinyint(1) DEFAULT 0,
  `acknowledged_at` timestamp NULL DEFAULT NULL,
  `issued_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `video_content`
--

CREATE TABLE `video_content` (
  `video_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `title_bn` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `video_url` varchar(255) NOT NULL,
  `thumbnail_url` varchar(255) DEFAULT NULL,
  `duration_seconds` int(11) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `language` enum('english','bangla','both') DEFAULT 'both',
  `target_audience` enum('beginner','intermediate','advanced','all') DEFAULT 'all',
  `views` int(11) DEFAULT 0,
  `likes` int(11) DEFAULT 0,
  `is_featured` tinyint(1) DEFAULT 0,
  `uploaded_by` int(11) DEFAULT NULL,
  `uploaded_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `weather_alerts`
--

CREATE TABLE `weather_alerts` (
  `alert_id` int(11) NOT NULL,
  `region` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `alert_type` enum('storm','flood','drought','heatwave','frost','cyclone','heavy_rain') NOT NULL,
  `severity` enum('low','medium','high','extreme') DEFAULT 'medium',
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `start_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `end_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `weather_alerts`
--

INSERT INTO `weather_alerts` (`alert_id`, `region`, `district`, `alert_type`, `severity`, `title`, `description`, `start_time`, `end_time`, `is_active`, `created_at`) VALUES
(1, 'Dhaka', 'Narayanganj', 'heavy_rain', 'medium', 'Moderate Rainfall Expected', 'Moderate to heavy rainfall expected during next 3 days. Please ensure proper drainage in fields.', '2025-12-18 15:02:20', '2025-12-21 15:02:20', 1, '2025-12-18 15:02:20'),
(2, 'Khulna', 'Khulna Sadar', 'drought', 'high', 'Prolonged Drought Conditions', 'Dry spell expected for 2 weeks. Plan irrigation carefully. Consider drought-resistant crops.', '2025-12-18 15:02:20', '2026-01-01 15:02:20', 1, '2025-12-18 15:02:20'),
(3, 'Rajshahi', 'Pabna', 'heatwave', 'medium', 'Above Normal Temperatures', 'Maximum temperatures 2-3°C above normal. Increase irrigation frequency. Protect crops from heat stress.', '2025-12-18 15:02:20', '2025-12-23 15:02:20', 0, '2025-12-18 15:02:20'),
(4, 'Chittagong', 'Feni', 'heavy_rain', 'high', 'Heavy Downpour Alert', 'Very heavy rainfall and strong winds expected. Secure structures, ensure drainage, protect loose items.', '2025-12-18 15:02:20', '2025-12-20 15:02:20', 1, '2025-12-18 15:02:20'),
(5, 'Dhaka', 'Tangail', 'frost', 'medium', 'Frost Warning', 'Light frost expected in early mornings. Protect sensitive seedlings with mulch or covers.', '2025-12-18 15:02:20', '2025-12-22 15:02:20', 0, '2025-12-18 15:02:20'),
(6, 'Khulna', 'Jessore', 'flood', 'high', 'Flash Flood Risk', 'Rivers rising above normal levels. Avoid low-lying areas. Prepare for evacuation.', '2025-12-18 15:02:20', '2025-12-24 15:02:20', 1, '2025-12-18 15:02:20'),
(7, 'Rajshahi', 'Bogra', 'heatwave', 'high', 'Extreme Heat Expected', 'Temperature exceeding 38°C expected for 5-7 days. Increase water supply, provide shade for livestock.', '2025-12-18 15:02:20', '2025-12-25 15:02:20', 1, '2025-12-18 15:02:20'),
(8, 'Chittagong', 'Comilla', 'cyclone', 'extreme', 'Cyclone Warning', 'Severe cyclone approaching coastal areas. Take immediate precautions. Follow weather updates hourly.', '2025-12-18 15:02:20', '2025-12-21 15:02:20', 1, '2025-12-18 15:02:20'),
(9, 'Dhaka', 'Manikganj', 'heavy_rain', 'medium', 'Scattered Showers', 'Intermittent rainfall expected. Not blocking planting activities but plan accordingly.', '2025-12-18 15:02:20', '2025-12-20 15:02:20', 0, '2025-12-18 15:02:20'),
(10, 'Khulna', 'Barisal', 'flood', 'medium', 'Moderate Flood Alert', 'River levels rising. Monitor closely. Keep evacuation routes clear.', '2025-12-18 15:02:20', '2025-12-23 15:02:20', 1, '2025-12-18 15:02:20'),
(11, 'Rajshahi', 'Sirajganj', 'drought', 'medium', 'Water Scarcity Warning', 'Reduced rainfall forecast. Groundwater levels declining. Promote water conservation.', '2025-12-18 15:02:20', '2025-12-28 15:02:20', 1, '2025-12-18 15:02:20'),
(12, 'Chittagong', 'Cox Bazar', 'cyclone', 'high', 'Severe Weather Condition', 'Unusual wind patterns and pressure changes. Secure all agricultural infrastructure.', '2025-12-18 15:02:20', '2025-12-20 15:02:20', 1, '2025-12-18 15:02:20'),
(13, 'Dhaka', 'Rajbari', 'frost', 'low', 'Light Frost Possible', 'Slight chance of ground frost in some areas. Monitor temperatures.', '2025-12-18 15:02:20', '2025-12-21 15:02:20', 0, '2025-12-18 15:02:20'),
(14, 'Khulna', 'Kushtia', 'heavy_rain', 'high', 'Torrential Rainfall', 'Unprecedented rainfall amounts expected. Serious flooding likely. Evacuate if necessary.', '2025-12-18 15:02:20', '2025-12-20 15:02:20', 1, '2025-12-18 15:02:20'),
(15, 'Rajshahi', 'Natore', 'heatwave', 'medium', 'High Temperature Alert', 'Continuous high temperatures for 4-5 days. Maintain crop hydration.', '2025-12-18 15:02:20', '2025-12-23 15:02:20', 1, '2025-12-18 15:02:20'),
(16, 'Chittagong', 'Rangamati', 'heavy_rain', 'high', 'Landslide Risk Alert', 'Heavy rainfall on hilly terrain. Risk of landslides. Avoid unstable slopes.', '2025-12-18 15:02:20', '2025-12-21 15:02:20', 1, '2025-12-18 15:02:20'),
(17, 'Dhaka', 'Gazipur', 'drought', 'low', 'Below Normal Rainfall', 'Slightly less rainfall than expected. Plan irrigation ahead.', '2025-12-18 15:02:20', '2025-12-26 15:02:20', 0, '2025-12-18 15:02:20'),
(18, 'Khulna', 'Pirojpur', 'flood', 'high', 'Major Flood Warning', 'Significant flooding expected in low-lying areas. Prepare protective measures.', '2025-12-18 15:02:20', '2025-12-25 15:02:20', 1, '2025-12-18 15:02:20'),
(19, 'Rajshahi', 'Nawabganj', 'frost', 'medium', 'Frost Expected', 'Ground frost will affect seedlings. Cover tender crops overnight.', '2025-12-18 15:02:20', '2025-12-21 15:02:20', 1, '2025-12-18 15:02:20'),
(20, 'Chittagong', 'Chandpur', 'heavy_rain', 'medium', 'Seasonal Rainfall', 'Normal seasonal rainfall expected. Good for crops. Manage water levels.', '2025-12-18 15:02:20', '2025-12-22 15:02:20', 0, '2025-12-18 15:02:20'),
(21, 'Dhaka', 'Shariatpur', 'heavy_rain', 'medium', 'Moderate Rain Event', 'Intermittent moderate rainfall. Ensure field drainage, monitor crops.', '2025-12-18 15:02:20', '2025-12-21 15:02:20', 1, '2025-12-18 15:02:20'),
(22, 'Khulna', 'Satkhira', '', 'high', 'Saltwater Intrusion Alert', 'High salinity levels in water sources. Use alternative water for irrigation.', '2025-12-18 15:02:20', '2025-12-28 15:02:20', 1, '2025-12-18 15:02:20'),
(23, 'Rajshahi', 'Shibganj', 'heavy_rain', 'medium', 'Moderate Showers', 'Beneficial rainfall for crops. Light winds. Good farming weather.', '2025-12-18 15:02:20', '2025-12-20 15:02:20', 0, '2025-12-18 15:02:20'),
(24, 'Chittagong', 'Khagrachhari', 'heavy_rain', 'high', 'Monsoon Downpour', 'Strong monsoon rains affecting hilly region. Prepare drainage systems.', '2025-12-18 15:02:20', '2025-12-23 15:02:20', 1, '2025-12-18 15:02:20');

-- --------------------------------------------------------

--
-- Table structure for table `weather_data`
--

CREATE TABLE `weather_data` (
  `weather_id` int(11) NOT NULL,
  `location` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `temperature` decimal(5,2) DEFAULT NULL,
  `temperature_min` decimal(5,2) DEFAULT NULL,
  `temperature_max` decimal(5,2) DEFAULT NULL,
  `feels_like` decimal(5,2) DEFAULT NULL,
  `humidity` int(11) DEFAULT NULL,
  `pressure` int(11) DEFAULT NULL,
  `rainfall` decimal(10,2) DEFAULT NULL,
  `wind_speed` decimal(5,2) DEFAULT NULL,
  `wind_direction` int(11) DEFAULT NULL,
  `cloud_coverage` int(11) DEFAULT NULL,
  `weather_condition` varchar(100) DEFAULT NULL,
  `weather_description` text DEFAULT NULL,
  `uv_index` int(11) DEFAULT NULL,
  `visibility` int(11) DEFAULT NULL,
  `recorded_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `forecast_date` date DEFAULT NULL,
  `is_forecast` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `weather_data`
--

INSERT INTO `weather_data` (`weather_id`, `location`, `region`, `district`, `latitude`, `longitude`, `temperature`, `temperature_min`, `temperature_max`, `feels_like`, `humidity`, `pressure`, `rainfall`, `wind_speed`, `wind_direction`, `cloud_coverage`, `weather_condition`, `weather_description`, `uv_index`, `visibility`, `recorded_date`, `forecast_date`, `is_forecast`) VALUES
(1, 'Dhaka', 'Dhaka', 'Dhaka Sadar', 23.81030000, 90.41250000, 28.50, 22.00, 34.00, NULL, 65, NULL, 0.00, 12.50, NULL, NULL, 'Partly Cloudy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(2, 'Narayanganj', 'Dhaka', 'Narayanganj', 23.43450000, 90.48910000, 27.80, 21.50, 33.50, NULL, 68, NULL, 0.00, 10.20, NULL, NULL, 'Clear', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(3, 'Khulna', 'Khulna', 'Khulna Sadar', 22.84560000, 89.56780000, 29.20, 23.50, 35.00, NULL, 62, NULL, 0.00, 15.80, NULL, NULL, 'Sunny', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(4, 'Rajshahi', 'Rajshahi', 'Pabna', 24.00190000, 89.34560000, 26.50, 20.00, 32.00, NULL, 70, NULL, 2.50, 8.50, NULL, NULL, 'Cloudy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(5, 'Chittagong', 'Chittagong', 'Feni', 23.02190000, 91.39870000, 30.10, 24.00, 35.50, NULL, 75, NULL, 0.50, 16.20, NULL, NULL, 'Rainy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(6, 'Tangail', 'Dhaka', 'Tangail', 24.24100000, 89.92630000, 27.20, 21.80, 32.50, NULL, 66, NULL, 0.00, 11.00, NULL, NULL, 'Partly Cloudy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(7, 'Barisal', 'Khulna', 'Barisal', 22.69450000, 90.25670000, 28.80, 23.00, 34.20, NULL, 70, NULL, 1.20, 14.50, NULL, NULL, 'Cloudy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(8, 'Nawabganj', 'Rajshahi', 'Nawabganj', 24.59450000, 88.27430000, 25.80, 19.50, 31.00, NULL, 72, NULL, 3.00, 9.20, NULL, NULL, 'Rainy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(9, 'Comilla', 'Chittagong', 'Comilla', 23.19630000, 91.64380000, 29.50, 23.80, 34.80, NULL, 73, NULL, 0.80, 13.80, NULL, NULL, 'Partly Cloudy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(10, 'Gazipur', 'Dhaka', 'Gazipur', 23.99570000, 90.43040000, 28.10, 22.20, 33.80, NULL, 67, NULL, 0.00, 10.80, NULL, NULL, 'Clear', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(11, 'Jessore', 'Khulna', 'Jessore', 23.18270000, 89.00920000, 29.00, 23.20, 34.50, NULL, 64, NULL, 0.00, 14.20, NULL, NULL, 'Sunny', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(12, 'Bogra', 'Rajshahi', 'Bogra', 24.84650000, 89.37890000, 26.20, 20.50, 31.80, NULL, 71, NULL, 2.80, 8.90, NULL, NULL, 'Cloudy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(13, 'Rangamati', 'Chittagong', 'Rangamati', 22.44560000, 92.12340000, 30.80, 25.00, 35.20, NULL, 78, NULL, 1.50, 17.50, NULL, NULL, 'Rainy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(14, 'Manikganj', 'Dhaka', 'Manikganj', 23.88220000, 90.00680000, 27.50, 21.70, 33.20, NULL, 68, NULL, 0.20, 11.50, NULL, NULL, 'Cloudy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(15, 'Satkhira', 'Khulna', 'Satkhira', 22.72670000, 89.01650000, 28.50, 22.80, 34.00, NULL, 72, NULL, 1.00, 12.80, NULL, NULL, 'Partly Cloudy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(16, 'Sirajganj', 'Rajshahi', 'Sirajganj', 24.45000000, 89.70000000, 26.80, 20.80, 32.50, NULL, 69, NULL, 1.50, 9.50, NULL, NULL, 'Cloudy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(17, 'Chandpur', 'Chittagong', 'Chandpur', 23.16500000, 91.68500000, 29.80, 24.20, 35.00, NULL, 76, NULL, 0.60, 15.20, NULL, NULL, 'Partly Cloudy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(18, 'Shariatpur', 'Dhaka', 'Shariatpur', 23.20090000, 90.53680000, 28.00, 22.10, 33.50, NULL, 69, NULL, 0.00, 10.50, NULL, NULL, 'Clear', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(19, 'Pirojpur', 'Khulna', 'Pirojpur', 22.45670000, 89.72340000, 28.90, 23.10, 34.30, NULL, 71, NULL, 1.80, 13.50, NULL, NULL, 'Cloudy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(20, 'Natore', 'Rajshahi', 'Natore', 24.41800000, 88.99000000, 26.50, 20.20, 31.50, NULL, 70, NULL, 2.20, 8.80, NULL, NULL, 'Rainy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(21, 'Cox Bazar', 'Chittagong', 'Cox Bazar', 21.45300000, 92.18950000, 31.20, 25.50, 35.80, NULL, 80, NULL, 2.00, 18.50, NULL, NULL, 'Rainy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(22, 'Rajbari', 'Dhaka', 'Rajbari', 23.01570000, 89.77180000, 27.80, 21.90, 33.10, NULL, 67, NULL, 0.50, 10.90, NULL, NULL, 'Partly Cloudy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(23, 'Kushtia', 'Khulna', 'Kushtia', 23.90640000, 89.01170000, 29.10, 23.40, 34.70, NULL, 63, NULL, 0.00, 15.50, NULL, NULL, 'Sunny', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(24, 'Shibganj', 'Rajshahi', 'Shibganj', 24.63390000, 88.26880000, 26.00, 20.00, 31.20, NULL, 73, NULL, 3.20, 9.00, NULL, NULL, 'Rainy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0),
(25, 'Dighinala', 'Chittagong', 'Khagrachhari', 23.12340000, 92.34560000, 30.00, 24.50, 35.50, NULL, 77, NULL, 1.20, 16.80, NULL, NULL, 'Rainy', NULL, NULL, NULL, '2025-12-18 15:02:20', NULL, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_2fa_backup_codes`
--
ALTER TABLE `admin_2fa_backup_codes`
  ADD PRIMARY KEY (`code_id`),
  ADD KEY `idx_user` (`user_id`);

--
-- Indexes for table `admin_2fa_tokens`
--
ALTER TABLE `admin_2fa_tokens`
  ADD PRIMARY KEY (`token_id`),
  ADD KEY `idx_user_token` (`user_id`,`token`),
  ADD KEY `idx_expires` (`expires_at`);

--
-- Indexes for table `admin_activity_logs`
--
ALTER TABLE `admin_activity_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_action` (`action`),
  ADD KEY `idx_category` (`action_category`),
  ADD KEY `idx_risk` (`risk_level`),
  ADD KEY `idx_created` (`created_at`);

--
-- Indexes for table `admin_ip_rules`
--
ALTER TABLE `admin_ip_rules`
  ADD PRIMARY KEY (`rule_id`),
  ADD KEY `idx_ip` (`ip_address`),
  ADD KEY `idx_type` (`rule_type`),
  ADD KEY `idx_expires` (`expires_at`);

--
-- Indexes for table `admin_login_attempts`
--
ALTER TABLE `admin_login_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ip` (`ip_address`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_attempted` (`attempted_at`);

--
-- Indexes for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_type` (`notification_type`),
  ADD KEY `idx_read` (`is_read`),
  ADD KEY `idx_created` (`created_at`);

--
-- Indexes for table `admin_profiles`
--
ALTER TABLE `admin_profiles`
  ADD PRIMARY KEY (`profile_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `admin_sessions`
--
ALTER TABLE `admin_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_active` (`is_active`);

--
-- Indexes for table `admin_settings`
--
ALTER TABLE `admin_settings`
  ADD PRIMARY KEY (`setting_id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`),
  ADD KEY `idx_group` (`setting_group`);

--
-- Indexes for table `admin_trusted_devices`
--
ALTER TABLE `admin_trusted_devices`
  ADD PRIMARY KEY (`device_id`),
  ADD UNIQUE KEY `unique_device` (`user_id`,`device_fingerprint`),
  ADD KEY `idx_user` (`user_id`);

--
-- Indexes for table `advisories`
--
ALTER TABLE `advisories`
  ADD PRIMARY KEY (`advisory_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_advisory_type` (`advisory_type`),
  ADD KEY `idx_is_active` (`is_active`);

--
-- Indexes for table `agent_conversations`
--
ALTER TABLE `agent_conversations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_conv_id` (`conversation_id`),
  ADD UNIQUE KEY `uk_share_token` (`share_token`),
  ADD KEY `idx_user_updated` (`user_id`,`updated_at`);

--
-- Indexes for table `agent_messages`
--
ALTER TABLE `agent_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_conv_created` (`conversation_id`,`created_at`);

--
-- Indexes for table `agent_user_memory`
--
ALTER TABLE `agent_user_memory`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_user_memory_key` (`user_id`,`memory_key`),
  ADD KEY `idx_user_memory_user` (`user_id`);

--
-- Indexes for table `ai_chat_logs`
--
ALTER TABLE `ai_chat_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_message_type` (`message_type`);

--
-- Indexes for table `ai_recommendations`
--
ALTER TABLE `ai_recommendations`
  ADD PRIMARY KEY (`recommendation_id`),
  ADD KEY `crop_id` (`crop_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_recommendation_type` (`recommendation_type`);

--
-- Indexes for table `ai_usage_logs`
--
ALTER TABLE `ai_usage_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_provider` (`provider`),
  ADD KEY `idx_created` (`created_at`),
  ADD KEY `idx_conversation` (`conversation_id`);

--
-- Indexes for table `alerts`
--
ALTER TABLE `alerts`
  ADD PRIMARY KEY (`alert_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_alert_type` (`alert_type`),
  ADD KEY `idx_is_read` (`is_read`),
  ADD KEY `idx_priority` (`priority`);

--
-- Indexes for table `api_request_logs`
--
ALTER TABLE `api_request_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_endpoint` (`endpoint`),
  ADD KEY `idx_response_time` (`response_time_ms`),
  ADD KEY `idx_response_code` (`response_code`),
  ADD KEY `idx_created` (`created_at`);

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`article_id`),
  ADD KEY `idx_author_id` (`author_id`),
  ADD KEY `idx_category` (`category`),
  ADD KEY `idx_is_published` (`is_published`);

--
-- Indexes for table `audit_trail`
--
ALTER TABLE `audit_trail`
  ADD PRIMARY KEY (`audit_id`),
  ADD KEY `idx_table_record` (`table_name`,`record_id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_action` (`action`),
  ADD KEY `idx_created` (`created_at`);

--
-- Indexes for table `backup_records`
--
ALTER TABLE `backup_records`
  ADD PRIMARY KEY (`backup_id`),
  ADD KEY `idx_type` (`backup_type`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created` (`created_at`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `idx_sender_id` (`sender_id`),
  ADD KEY `idx_receiver_id` (`receiver_id`),
  ADD KEY `idx_is_read` (`is_read`);

--
-- Indexes for table `comment_likes`
--
ALTER TABLE `comment_likes`
  ADD PRIMARY KEY (`like_id`),
  ADD UNIQUE KEY `unique_comment_like` (`comment_id`,`user_id`),
  ADD KEY `idx_comment_id` (`comment_id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Indexes for table `community_posts`
--
ALTER TABLE `community_posts`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `approved_by` (`approved_by`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_category` (`category`),
  ADD KEY `idx_is_approved` (`is_approved`);

--
-- Indexes for table `content_reports`
--
ALTER TABLE `content_reports`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `idx_content` (`content_type`,`content_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_priority` (`priority`),
  ADD KEY `idx_reporter` (`reporter_id`);

--
-- Indexes for table `course_pricing_history`
--
ALTER TABLE `course_pricing_history`
  ADD PRIMARY KEY (`history_id`),
  ADD KEY `idx_course_id` (`course_id`),
  ADD KEY `idx_changed_at` (`changed_at`),
  ADD KEY `idx_course_changed` (`course_id`,`changed_at`);

--
-- Indexes for table `crop_activities`
--
ALTER TABLE `crop_activities`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `idx_crop_id` (`crop_id`),
  ADD KEY `idx_activity_type` (`activity_type`);

--
-- Indexes for table `crop_data`
--
ALTER TABLE `crop_data`
  ADD PRIMARY KEY (`crop_id`),
  ADD KEY `idx_farmer_id` (`farmer_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_crop_name` (`crop_name`);

--
-- Indexes for table `dashboard_widgets`
--
ALTER TABLE `dashboard_widgets`
  ADD PRIMARY KEY (`widget_id`),
  ADD KEY `idx_user` (`user_id`);

--
-- Indexes for table `disease_library`
--
ALTER TABLE `disease_library`
  ADD PRIMARY KEY (`disease_id`),
  ADD KEY `idx_disease_name` (`disease_name`);

--
-- Indexes for table `disease_reports`
--
ALTER TABLE `disease_reports`
  ADD PRIMARY KEY (`detection_id`),
  ADD KEY `verified_by` (`verified_by`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_crop_id` (`crop_id`),
  ADD KEY `idx_severity` (`severity`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `disease_report_responses`
--
ALTER TABLE `disease_report_responses`
  ADD PRIMARY KEY (`response_id`),
  ADD KEY `idx_report_id` (`report_id`),
  ADD KEY `idx_officer_id` (`officer_id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `email_queue`
--
ALTER TABLE `email_queue`
  ADD PRIMARY KEY (`queue_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_priority` (`priority`),
  ADD KEY `idx_scheduled` (`scheduled_at`),
  ADD KEY `idx_to_email` (`to_email`);

--
-- Indexes for table `error_logs`
--
ALTER TABLE `error_logs`
  ADD PRIMARY KEY (`error_id`),
  ADD KEY `idx_severity` (`severity`),
  ADD KEY `idx_type` (`error_type`),
  ADD KEY `idx_hash` (`error_hash`),
  ADD KEY `idx_resolved` (`is_resolved`),
  ADD KEY `idx_first_seen` (`first_seen`);

--
-- Indexes for table `farmer_profiles`
--
ALTER TABLE `farmer_profiles`
  ADD PRIMARY KEY (`profile_id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD KEY `idx_region` (`region`),
  ADD KEY `idx_farming_type` (`farming_type`);

--
-- Indexes for table `farm_tasks`
--
ALTER TABLE `farm_tasks`
  ADD PRIMARY KEY (`task_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `task_date` (`task_date`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `fertilizer_recommendations`
--
ALTER TABLE `fertilizer_recommendations`
  ADD PRIMARY KEY (`recommendation_id`),
  ADD KEY `recommended_by` (`recommended_by`),
  ADD KEY `idx_crop_id` (`crop_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `field_visits`
--
ALTER TABLE `field_visits`
  ADD PRIMARY KEY (`visit_id`),
  ADD KEY `idx_officer_id` (`officer_id`),
  ADD KEY `idx_farmer_id` (`farmer_id`),
  ADD KEY `idx_visit_date` (`visit_date`);

--
-- Indexes for table `file_uploads`
--
ALTER TABLE `file_uploads`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_entity_type` (`entity_type`),
  ADD KEY `idx_entity_id` (`entity_id`);

--
-- Indexes for table `general_users`
--
ALTER TABLE `general_users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_phone` (`phone`),
  ADD KEY `idx_is_active` (`is_active`);

--
-- Indexes for table `generated_reports`
--
ALTER TABLE `generated_reports`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `idx_type` (`report_type`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_generated_by` (`generated_by`);

--
-- Indexes for table `honeypot_logs`
--
ALTER TABLE `honeypot_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_ip` (`ip_address`),
  ADD KEY `idx_created` (`created_at`);

--
-- Indexes for table `learn_categories`
--
ALTER TABLE `learn_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `learn_certificates`
--
ALTER TABLE `learn_certificates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_cert_code` (`certificate_code`),
  ADD UNIQUE KEY `uq_user_content` (`user_id`,`content_id`),
  ADD KEY `content_id` (`content_id`);

--
-- Indexes for table `learn_content`
--
ALTER TABLE `learn_content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_type_published` (`type`,`is_published`),
  ADD KEY `idx_created_by` (`created_by`),
  ADD KEY `idx_category` (`category_id`);

--
-- Indexes for table `learn_likes`
--
ALTER TABLE `learn_likes`
  ADD PRIMARY KEY (`user_id`,`content_id`),
  ADD KEY `content_id` (`content_id`);

--
-- Indexes for table `learn_paths`
--
ALTER TABLE `learn_paths`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `learn_path_items`
--
ALTER TABLE `learn_path_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `path_id` (`path_id`),
  ADD KEY `content_id` (`content_id`);

--
-- Indexes for table `learn_playlist_items`
--
ALTER TABLE `learn_playlist_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_content` (`content_id`);

--
-- Indexes for table `learn_progress`
--
ALTER TABLE `learn_progress`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_user_content` (`user_id`,`content_id`),
  ADD KEY `content_id` (`content_id`);

--
-- Indexes for table `learn_quiz_attempts`
--
ALTER TABLE `learn_quiz_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_content` (`user_id`,`content_id`),
  ADD KEY `content_id` (`content_id`);

--
-- Indexes for table `learn_quiz_options`
--
ALTER TABLE `learn_quiz_options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_question` (`question_id`);

--
-- Indexes for table `learn_quiz_questions`
--
ALTER TABLE `learn_quiz_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_content` (`content_id`);

--
-- Indexes for table `marketplace_orders`
--
ALTER TABLE `marketplace_orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `idx_seller_id` (`seller_id`),
  ADD KEY `idx_buyer_id` (`buyer_id`),
  ADD KEY `idx_order_status` (`order_status`);

--
-- Indexes for table `marketplace_products`
--
ALTER TABLE `marketplace_products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `verified_by` (`verified_by`),
  ADD KEY `idx_seller_id` (`seller_id`),
  ADD KEY `idx_product_type` (`product_type`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_mp_status_cat` (`status`,`category`);

--
-- Indexes for table `market_prices`
--
ALTER TABLE `market_prices`
  ADD PRIMARY KEY (`price_id`),
  ADD KEY `idx_crop_name` (`crop_name`),
  ADD KEY `idx_market_location` (`market_location`),
  ADD KEY `idx_price_date` (`price_date`);

--
-- Indexes for table `notification_preferences`
--
ALTER TABLE `notification_preferences`
  ADD PRIMARY KEY (`preference_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `officer_profiles`
--
ALTER TABLE `officer_profiles`
  ADD PRIMARY KEY (`profile_id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD KEY `idx_region` (`region`),
  ADD KEY `idx_department` (`department`);

--
-- Indexes for table `password_history`
--
ALTER TABLE `password_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user` (`user_id`);

--
-- Indexes for table `post_bookmarks`
--
ALTER TABLE `post_bookmarks`
  ADD PRIMARY KEY (`bookmark_id`),
  ADD UNIQUE KEY `unique_post_user_bookmark` (`post_id`,`user_id`),
  ADD KEY `idx_post_id` (`post_id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Indexes for table `post_comments`
--
ALTER TABLE `post_comments`
  ADD PRIMARY KEY (`comment_id`),
  ADD KEY `fk_post` (`post_id`);

--
-- Indexes for table `post_helpfulness`
--
ALTER TABLE `post_helpfulness`
  ADD PRIMARY KEY (`helpfulness_id`),
  ADD UNIQUE KEY `unique_post_user_helpfulness` (`post_id`,`user_id`),
  ADD KEY `idx_post_id` (`post_id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Indexes for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD PRIMARY KEY (`like_id`),
  ADD UNIQUE KEY `unique_post_like` (`post_id`,`user_id`),
  ADD KEY `idx_post_id` (`post_id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Indexes for table `post_reports`
--
ALTER TABLE `post_reports`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `idx_post_id` (`post_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `post_shares`
--
ALTER TABLE `post_shares`
  ADD PRIMARY KEY (`share_id`),
  ADD KEY `idx_post_id` (`post_id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Indexes for table `product_comparisons`
--
ALTER TABLE `product_comparisons`
  ADD PRIMARY KEY (`comparison_id`),
  ADD UNIQUE KEY `unique_comparison` (`user_id`,`product_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `fk_comparison_product` (`product_id`);

--
-- Indexes for table `product_inquiries`
--
ALTER TABLE `product_inquiries`
  ADD PRIMARY KEY (`inquiry_id`),
  ADD KEY `idx_product_id` (`product_id`),
  ADD KEY `idx_buyer_id` (`buyer_id`);

--
-- Indexes for table `product_offers`
--
ALTER TABLE `product_offers`
  ADD PRIMARY KEY (`offer_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `buyer_id` (`buyer_id`),
  ADD KEY `seller_id` (`seller_id`);

--
-- Indexes for table `product_reports`
--
ALTER TABLE `product_reports`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `reporter_id` (`reporter_id`);

--
-- Indexes for table `product_reviews`
--
ALTER TABLE `product_reviews`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `parent_review_id` (`parent_review_id`),
  ADD KEY `rating` (`rating`);

--
-- Indexes for table `product_wishlist`
--
ALTER TABLE `product_wishlist`
  ADD PRIMARY KEY (`wishlist_id`),
  ADD UNIQUE KEY `unique_wishlist` (`user_id`,`product_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `rate_limits`
--
ALTER TABLE `rate_limits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_identifier` (`identifier`,`endpoint`),
  ADD KEY `idx_window` (`window_start`);

--
-- Indexes for table `recently_viewed`
--
ALTER TABLE `recently_viewed`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_view` (`user_id`,`product_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `restore_logs`
--
ALTER TABLE `restore_logs`
  ADD PRIMARY KEY (`restore_id`),
  ADD KEY `idx_backup` (`backup_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `review_helpfulness`
--
ALTER TABLE `review_helpfulness`
  ADD PRIMARY KEY (`vote_id`),
  ADD UNIQUE KEY `unique_review_vote` (`review_id`,`user_id`),
  ADD KEY `review_id` (`review_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `review_likes`
--
ALTER TABLE `review_likes`
  ADD PRIMARY KEY (`like_id`),
  ADD UNIQUE KEY `unique_review_like` (`review_id`,`user_id`),
  ADD KEY `review_id` (`review_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `scheduled_reports`
--
ALTER TABLE `scheduled_reports`
  ADD PRIMARY KEY (`schedule_id`),
  ADD KEY `idx_enabled` (`is_enabled`),
  ADD KEY `idx_next_send` (`next_send`);

--
-- Indexes for table `scheduled_tasks`
--
ALTER TABLE `scheduled_tasks`
  ADD PRIMARY KEY (`task_id`),
  ADD KEY `idx_enabled` (`is_enabled`),
  ADD KEY `idx_next_run` (`next_run`),
  ADD KEY `idx_type` (`task_type`);

--
-- Indexes for table `security_events`
--
ALTER TABLE `security_events`
  ADD PRIMARY KEY (`event_id`),
  ADD KEY `idx_type` (`event_type`),
  ADD KEY `idx_severity` (`severity`),
  ADD KEY `idx_acknowledged` (`is_acknowledged`),
  ADD KEY `idx_created` (`created_at`);

--
-- Indexes for table `seller_stats`
--
ALTER TABLE `seller_stats`
  ADD PRIMARY KEY (`seller_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`setting_id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`),
  ADD KEY `idx_setting_key` (`setting_key`);

--
-- Indexes for table `shop_cart`
--
ALTER TABLE `shop_cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_session_id` (`session_id`),
  ADD KEY `idx_product_id` (`product_id`),
  ADD KEY `idx_cart_session` (`session_id`),
  ADD KEY `idx_cart_user` (`user_id`);

--
-- Indexes for table `shop_conversations`
--
ALTER TABLE `shop_conversations`
  ADD PRIMARY KEY (`conversation_id`),
  ADD KEY `idx_farmer` (`farmer_id`),
  ADD KEY `idx_customer` (`customer_id`,`customer_type`),
  ADD KEY `idx_order` (`order_id`),
  ADD KEY `idx_product` (`product_id`),
  ADD KEY `idx_last_message` (`last_message_at`);

--
-- Indexes for table `shop_messages`
--
ALTER TABLE `shop_messages`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `idx_conversation` (`conversation_id`),
  ADD KEY `idx_sender` (`sender_type`,`sender_id`),
  ADD KEY `idx_created` (`created_at`);

--
-- Indexes for table `shop_orders`
--
ALTER TABLE `shop_orders`
  ADD PRIMARY KEY (`order_id`),
  ADD UNIQUE KEY `order_number` (`order_number`),
  ADD KEY `idx_buyer_id` (`buyer_id`),
  ADD KEY `idx_order_status` (`order_status`),
  ADD KEY `idx_payment_status` (`payment_status`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `shop_order_items`
--
ALTER TABLE `shop_order_items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `idx_order_id` (`order_id`),
  ADD KEY `idx_product_id` (`product_id`),
  ADD KEY `idx_seller_id` (`seller_id`),
  ADD KEY `idx_shop_orders_seller` (`seller_id`);

--
-- Indexes for table `shop_otp_codes`
--
ALTER TABLE `shop_otp_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_email_purpose` (`email`,`purpose`);

--
-- Indexes for table `shop_settings`
--
ALTER TABLE `shop_settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- Indexes for table `sms_settings`
--
ALTER TABLE `sms_settings`
  ADD PRIMARY KEY (`setting_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `system_logs`
--
ALTER TABLE `system_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_action` (`action`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `system_metrics`
--
ALTER TABLE `system_metrics`
  ADD PRIMARY KEY (`metric_id`),
  ADD KEY `idx_type_time` (`metric_type`,`recorded_at`),
  ADD KEY `idx_recorded` (`recorded_at`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_updated_by` (`updated_by`);

--
-- Indexes for table `task_execution_logs`
--
ALTER TABLE `task_execution_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_task` (`task_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_started` (`started_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_phone` (`phone`),
  ADD KEY `idx_role` (`role`),
  ADD KEY `idx_is_active` (`is_active`),
  ADD KEY `idx_users_role` (`role`);

--
-- Indexes for table `user_bans`
--
ALTER TABLE `user_bans`
  ADD PRIMARY KEY (`ban_id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_active` (`is_active`),
  ADD KEY `idx_type` (`ban_type`),
  ADD KEY `idx_ip` (`ip_address`);

--
-- Indexes for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `idx_user_notifications` (`user_id`,`user_type`),
  ADD KEY `idx_unread` (`user_id`,`user_type`,`is_read`),
  ADD KEY `idx_created` (`created_at`);

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_expires_at` (`expires_at`);

--
-- Indexes for table `user_warnings`
--
ALTER TABLE `user_warnings`
  ADD PRIMARY KEY (`warning_id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_type` (`warning_type`),
  ADD KEY `idx_expires` (`expires_at`);

--
-- Indexes for table `video_content`
--
ALTER TABLE `video_content`
  ADD PRIMARY KEY (`video_id`),
  ADD KEY `uploaded_by` (`uploaded_by`),
  ADD KEY `idx_category` (`category`),
  ADD KEY `idx_is_featured` (`is_featured`);

--
-- Indexes for table `weather_alerts`
--
ALTER TABLE `weather_alerts`
  ADD PRIMARY KEY (`alert_id`),
  ADD KEY `idx_region` (`region`),
  ADD KEY `idx_is_active` (`is_active`),
  ADD KEY `idx_severity` (`severity`);

--
-- Indexes for table `weather_data`
--
ALTER TABLE `weather_data`
  ADD PRIMARY KEY (`weather_id`),
  ADD KEY `idx_location` (`location`),
  ADD KEY `idx_recorded_date` (`recorded_date`),
  ADD KEY `idx_forecast_date` (`forecast_date`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_2fa_backup_codes`
--
ALTER TABLE `admin_2fa_backup_codes`
  MODIFY `code_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_2fa_tokens`
--
ALTER TABLE `admin_2fa_tokens`
  MODIFY `token_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_activity_logs`
--
ALTER TABLE `admin_activity_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `admin_ip_rules`
--
ALTER TABLE `admin_ip_rules`
  MODIFY `rule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `admin_login_attempts`
--
ALTER TABLE `admin_login_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_profiles`
--
ALTER TABLE `admin_profiles`
  MODIFY `profile_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_settings`
--
ALTER TABLE `admin_settings`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `admin_trusted_devices`
--
ALTER TABLE `admin_trusted_devices`
  MODIFY `device_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `advisories`
--
ALTER TABLE `advisories`
  MODIFY `advisory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `agent_conversations`
--
ALTER TABLE `agent_conversations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `agent_messages`
--
ALTER TABLE `agent_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `agent_user_memory`
--
ALTER TABLE `agent_user_memory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `ai_chat_logs`
--
ALTER TABLE `ai_chat_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ai_recommendations`
--
ALTER TABLE `ai_recommendations`
  MODIFY `recommendation_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ai_usage_logs`
--
ALTER TABLE `ai_usage_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `alerts`
--
ALTER TABLE `alerts`
  MODIFY `alert_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `api_request_logs`
--
ALTER TABLE `api_request_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `article_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `audit_trail`
--
ALTER TABLE `audit_trail`
  MODIFY `audit_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `backup_records`
--
ALTER TABLE `backup_records`
  MODIFY `backup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comment_likes`
--
ALTER TABLE `comment_likes`
  MODIFY `like_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `community_posts`
--
ALTER TABLE `community_posts`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `content_reports`
--
ALTER TABLE `content_reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `course_pricing_history`
--
ALTER TABLE `course_pricing_history`
  MODIFY `history_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `crop_activities`
--
ALTER TABLE `crop_activities`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `crop_data`
--
ALTER TABLE `crop_data`
  MODIFY `crop_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `dashboard_widgets`
--
ALTER TABLE `dashboard_widgets`
  MODIFY `widget_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `disease_library`
--
ALTER TABLE `disease_library`
  MODIFY `disease_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `disease_reports`
--
ALTER TABLE `disease_reports`
  MODIFY `detection_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `disease_report_responses`
--
ALTER TABLE `disease_report_responses`
  MODIFY `response_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `email_queue`
--
ALTER TABLE `email_queue`
  MODIFY `queue_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `error_logs`
--
ALTER TABLE `error_logs`
  MODIFY `error_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `farmer_profiles`
--
ALTER TABLE `farmer_profiles`
  MODIFY `profile_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `farm_tasks`
--
ALTER TABLE `farm_tasks`
  MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `fertilizer_recommendations`
--
ALTER TABLE `fertilizer_recommendations`
  MODIFY `recommendation_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `field_visits`
--
ALTER TABLE `field_visits`
  MODIFY `visit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `file_uploads`
--
ALTER TABLE `file_uploads`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `general_users`
--
ALTER TABLE `general_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `generated_reports`
--
ALTER TABLE `generated_reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `honeypot_logs`
--
ALTER TABLE `honeypot_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `learn_categories`
--
ALTER TABLE `learn_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `learn_certificates`
--
ALTER TABLE `learn_certificates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `learn_content`
--
ALTER TABLE `learn_content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `learn_paths`
--
ALTER TABLE `learn_paths`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `learn_path_items`
--
ALTER TABLE `learn_path_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `learn_playlist_items`
--
ALTER TABLE `learn_playlist_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `learn_progress`
--
ALTER TABLE `learn_progress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `learn_quiz_attempts`
--
ALTER TABLE `learn_quiz_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `learn_quiz_options`
--
ALTER TABLE `learn_quiz_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `learn_quiz_questions`
--
ALTER TABLE `learn_quiz_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `marketplace_orders`
--
ALTER TABLE `marketplace_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `marketplace_products`
--
ALTER TABLE `marketplace_products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `market_prices`
--
ALTER TABLE `market_prices`
  MODIFY `price_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `notification_preferences`
--
ALTER TABLE `notification_preferences`
  MODIFY `preference_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `officer_profiles`
--
ALTER TABLE `officer_profiles`
  MODIFY `profile_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `password_history`
--
ALTER TABLE `password_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `post_bookmarks`
--
ALTER TABLE `post_bookmarks`
  MODIFY `bookmark_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `post_comments`
--
ALTER TABLE `post_comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `post_helpfulness`
--
ALTER TABLE `post_helpfulness`
  MODIFY `helpfulness_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `post_likes`
--
ALTER TABLE `post_likes`
  MODIFY `like_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT for table `post_reports`
--
ALTER TABLE `post_reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `post_shares`
--
ALTER TABLE `post_shares`
  MODIFY `share_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product_comparisons`
--
ALTER TABLE `product_comparisons`
  MODIFY `comparison_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_inquiries`
--
ALTER TABLE `product_inquiries`
  MODIFY `inquiry_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_offers`
--
ALTER TABLE `product_offers`
  MODIFY `offer_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_reports`
--
ALTER TABLE `product_reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product_reviews`
--
ALTER TABLE `product_reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product_wishlist`
--
ALTER TABLE `product_wishlist`
  MODIFY `wishlist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `rate_limits`
--
ALTER TABLE `rate_limits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `recently_viewed`
--
ALTER TABLE `recently_viewed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `restore_logs`
--
ALTER TABLE `restore_logs`
  MODIFY `restore_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `review_helpfulness`
--
ALTER TABLE `review_helpfulness`
  MODIFY `vote_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `review_likes`
--
ALTER TABLE `review_likes`
  MODIFY `like_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `scheduled_reports`
--
ALTER TABLE `scheduled_reports`
  MODIFY `schedule_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scheduled_tasks`
--
ALTER TABLE `scheduled_tasks`
  MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `security_events`
--
ALTER TABLE `security_events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shop_cart`
--
ALTER TABLE `shop_cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `shop_conversations`
--
ALTER TABLE `shop_conversations`
  MODIFY `conversation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shop_messages`
--
ALTER TABLE `shop_messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `shop_orders`
--
ALTER TABLE `shop_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shop_order_items`
--
ALTER TABLE `shop_order_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shop_otp_codes`
--
ALTER TABLE `shop_otp_codes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sms_settings`
--
ALTER TABLE `sms_settings`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_logs`
--
ALTER TABLE `system_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_metrics`
--
ALTER TABLE `system_metrics`
  MODIFY `metric_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `task_execution_logs`
--
ALTER TABLE `task_execution_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `user_bans`
--
ALTER TABLE `user_bans`
  MODIFY `ban_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_notifications`
--
ALTER TABLE `user_notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_warnings`
--
ALTER TABLE `user_warnings`
  MODIFY `warning_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `video_content`
--
ALTER TABLE `video_content`
  MODIFY `video_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `weather_alerts`
--
ALTER TABLE `weather_alerts`
  MODIFY `alert_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `weather_data`
--
ALTER TABLE `weather_data`
  MODIFY `weather_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_sessions`
--
ALTER TABLE `admin_sessions`
  ADD CONSTRAINT `admin_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `advisories`
--
ALTER TABLE `advisories`
  ADD CONSTRAINT `advisories_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `ai_chat_logs`
--
ALTER TABLE `ai_chat_logs`
  ADD CONSTRAINT `ai_chat_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `ai_recommendations`
--
ALTER TABLE `ai_recommendations`
  ADD CONSTRAINT `ai_recommendations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ai_recommendations_ibfk_2` FOREIGN KEY (`crop_id`) REFERENCES `crop_data` (`crop_id`) ON DELETE CASCADE;

--
-- Constraints for table `alerts`
--
ALTER TABLE `alerts`
  ADD CONSTRAINT `alerts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `alerts_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `articles_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `comment_likes`
--
ALTER TABLE `comment_likes`
  ADD CONSTRAINT `comment_likes_ibfk_1` FOREIGN KEY (`comment_id`) REFERENCES `post_comments` (`comment_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comment_likes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `community_posts`
--
ALTER TABLE `community_posts`
  ADD CONSTRAINT `community_posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `community_posts_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `crop_activities`
--
ALTER TABLE `crop_activities`
  ADD CONSTRAINT `crop_activities_ibfk_1` FOREIGN KEY (`crop_id`) REFERENCES `crop_data` (`crop_id`) ON DELETE CASCADE;

--
-- Constraints for table `crop_data`
--
ALTER TABLE `crop_data`
  ADD CONSTRAINT `crop_data_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `disease_reports`
--
ALTER TABLE `disease_reports`
  ADD CONSTRAINT `disease_reports_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `disease_reports_ibfk_2` FOREIGN KEY (`crop_id`) REFERENCES `crop_data` (`crop_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `disease_reports_ibfk_3` FOREIGN KEY (`verified_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `disease_report_responses`
--
ALTER TABLE `disease_report_responses`
  ADD CONSTRAINT `fk_response_officer` FOREIGN KEY (`officer_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_response_report` FOREIGN KEY (`report_id`) REFERENCES `disease_reports` (`detection_id`) ON DELETE CASCADE;

--
-- Constraints for table `farmer_profiles`
--
ALTER TABLE `farmer_profiles`
  ADD CONSTRAINT `farmer_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `farm_tasks`
--
ALTER TABLE `farm_tasks`
  ADD CONSTRAINT `farm_tasks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `fertilizer_recommendations`
--
ALTER TABLE `fertilizer_recommendations`
  ADD CONSTRAINT `fertilizer_recommendations_ibfk_1` FOREIGN KEY (`crop_id`) REFERENCES `crop_data` (`crop_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fertilizer_recommendations_ibfk_2` FOREIGN KEY (`recommended_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `field_visits`
--
ALTER TABLE `field_visits`
  ADD CONSTRAINT `field_visits_ibfk_1` FOREIGN KEY (`officer_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `field_visits_ibfk_2` FOREIGN KEY (`farmer_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `file_uploads`
--
ALTER TABLE `file_uploads`
  ADD CONSTRAINT `file_uploads_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `learn_certificates`
--
ALTER TABLE `learn_certificates`
  ADD CONSTRAINT `learn_certificates_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `learn_certificates_ibfk_2` FOREIGN KEY (`content_id`) REFERENCES `learn_content` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `learn_likes`
--
ALTER TABLE `learn_likes`
  ADD CONSTRAINT `learn_likes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `learn_likes_ibfk_2` FOREIGN KEY (`content_id`) REFERENCES `learn_content` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `learn_paths`
--
ALTER TABLE `learn_paths`
  ADD CONSTRAINT `learn_paths_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `learn_path_items`
--
ALTER TABLE `learn_path_items`
  ADD CONSTRAINT `learn_path_items_ibfk_1` FOREIGN KEY (`path_id`) REFERENCES `learn_paths` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `learn_path_items_ibfk_2` FOREIGN KEY (`content_id`) REFERENCES `learn_content` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `learn_playlist_items`
--
ALTER TABLE `learn_playlist_items`
  ADD CONSTRAINT `learn_playlist_items_ibfk_1` FOREIGN KEY (`content_id`) REFERENCES `learn_content` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `learn_progress`
--
ALTER TABLE `learn_progress`
  ADD CONSTRAINT `learn_progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `learn_progress_ibfk_2` FOREIGN KEY (`content_id`) REFERENCES `learn_content` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `learn_quiz_attempts`
--
ALTER TABLE `learn_quiz_attempts`
  ADD CONSTRAINT `learn_quiz_attempts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `learn_quiz_attempts_ibfk_2` FOREIGN KEY (`content_id`) REFERENCES `learn_content` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `learn_quiz_options`
--
ALTER TABLE `learn_quiz_options`
  ADD CONSTRAINT `learn_quiz_options_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `learn_quiz_questions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `learn_quiz_questions`
--
ALTER TABLE `learn_quiz_questions`
  ADD CONSTRAINT `learn_quiz_questions_ibfk_1` FOREIGN KEY (`content_id`) REFERENCES `learn_content` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `marketplace_orders`
--
ALTER TABLE `marketplace_orders`
  ADD CONSTRAINT `marketplace_orders_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `marketplace_products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `marketplace_orders_ibfk_2` FOREIGN KEY (`seller_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `marketplace_orders_ibfk_3` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `marketplace_products`
--
ALTER TABLE `marketplace_products`
  ADD CONSTRAINT `marketplace_products_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `marketplace_products_ibfk_2` FOREIGN KEY (`verified_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `notification_preferences`
--
ALTER TABLE `notification_preferences`
  ADD CONSTRAINT `notification_preferences_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `officer_profiles`
--
ALTER TABLE `officer_profiles`
  ADD CONSTRAINT `officer_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `post_comments`
--
ALTER TABLE `post_comments`
  ADD CONSTRAINT `fk_post` FOREIGN KEY (`post_id`) REFERENCES `community_posts` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD CONSTRAINT `post_likes_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `community_posts` (`post_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `post_likes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `product_comparisons`
--
ALTER TABLE `product_comparisons`
  ADD CONSTRAINT `fk_comparison_product` FOREIGN KEY (`product_id`) REFERENCES `marketplace_products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_comparison_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `product_inquiries`
--
ALTER TABLE `product_inquiries`
  ADD CONSTRAINT `product_inquiries_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `marketplace_products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_inquiries_ibfk_2` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `product_offers`
--
ALTER TABLE `product_offers`
  ADD CONSTRAINT `fk_offer_buyer` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_offer_product` FOREIGN KEY (`product_id`) REFERENCES `marketplace_products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_offer_seller` FOREIGN KEY (`seller_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `product_reports`
--
ALTER TABLE `product_reports`
  ADD CONSTRAINT `fk_report_product` FOREIGN KEY (`product_id`) REFERENCES `marketplace_products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_report_user` FOREIGN KEY (`reporter_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `product_reviews`
--
ALTER TABLE `product_reviews`
  ADD CONSTRAINT `fk_review_parent` FOREIGN KEY (`parent_review_id`) REFERENCES `product_reviews` (`review_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_review_product` FOREIGN KEY (`product_id`) REFERENCES `marketplace_products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_review_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `product_wishlist`
--
ALTER TABLE `product_wishlist`
  ADD CONSTRAINT `fk_wishlist_product` FOREIGN KEY (`product_id`) REFERENCES `marketplace_products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_wishlist_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `recently_viewed`
--
ALTER TABLE `recently_viewed`
  ADD CONSTRAINT `fk_viewed_product` FOREIGN KEY (`product_id`) REFERENCES `marketplace_products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_viewed_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `review_helpfulness`
--
ALTER TABLE `review_helpfulness`
  ADD CONSTRAINT `fk_vote_review` FOREIGN KEY (`review_id`) REFERENCES `product_reviews` (`review_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_vote_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `review_likes`
--
ALTER TABLE `review_likes`
  ADD CONSTRAINT `fk_like_review` FOREIGN KEY (`review_id`) REFERENCES `product_reviews` (`review_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_like_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `seller_stats`
--
ALTER TABLE `seller_stats`
  ADD CONSTRAINT `fk_stats_seller` FOREIGN KEY (`seller_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `shop_cart`
--
ALTER TABLE `shop_cart`
  ADD CONSTRAINT `fk_shop_cart_product` FOREIGN KEY (`product_id`) REFERENCES `marketplace_products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_shop_cart_user` FOREIGN KEY (`user_id`) REFERENCES `general_users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `shop_messages`
--
ALTER TABLE `shop_messages`
  ADD CONSTRAINT `fk_message_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `shop_conversations` (`conversation_id`) ON DELETE CASCADE;

--
-- Constraints for table `shop_orders`
--
ALTER TABLE `shop_orders`
  ADD CONSTRAINT `fk_shop_orders_buyer` FOREIGN KEY (`buyer_id`) REFERENCES `general_users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `shop_order_items`
--
ALTER TABLE `shop_order_items`
  ADD CONSTRAINT `fk_shop_order_items_order` FOREIGN KEY (`order_id`) REFERENCES `shop_orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_shop_order_items_product` FOREIGN KEY (`product_id`) REFERENCES `marketplace_products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_shop_order_items_seller` FOREIGN KEY (`seller_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `sms_settings`
--
ALTER TABLE `sms_settings`
  ADD CONSTRAINT `sms_settings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `system_logs`
--
ALTER TABLE `system_logs`
  ADD CONSTRAINT `system_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `task_execution_logs`
--
ALTER TABLE `task_execution_logs`
  ADD CONSTRAINT `task_execution_logs_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `scheduled_tasks` (`task_id`) ON DELETE CASCADE;

--
-- Constraints for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD CONSTRAINT `user_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `video_content`
--
ALTER TABLE `video_content`
  ADD CONSTRAINT `video_content_ibfk_1` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
